"use client"

import { useEffect, useRef } from "react"
import { usePathname } from "next/navigation"

export function AdScript() {
  const scriptRef = useRef<HTMLScriptElement | null>(null)
  const pathname = usePathname()

  useEffect(() => {
    // Don't load ad script in admin pages
    if (pathname.startsWith("/admin")) {
      return
    }

    // Create script element if it doesn't exist
    if (!scriptRef.current) {
      const script = document.createElement("script")
      script.type = "text/javascript"
      script.async = true
      script.src = "//placeholderadserver.com/global.js" // Replace with actual ad server URL

      // Append to document body
      document.body.appendChild(script)
      scriptRef.current = script
    }

    // Cleanup function
    return () => {
      if (scriptRef.current && document.body.contains(scriptRef.current)) {
        document.body.removeChild(scriptRef.current)
        scriptRef.current = null
      }
    }
  }, [pathname])

  return null
}
