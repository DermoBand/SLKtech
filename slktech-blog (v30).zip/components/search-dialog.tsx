"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

// Mock search results data
const searchData = [
  {
    id: "1",
    title: "The Future of Foldable Smartphones: What to Expect in 2025",
    category: "Smartphones",
    excerpt: "Explore the next generation of foldable technology and how it's reshaping the smartphone industry.",
  },
  {
    id: "2",
    title: "AI-Powered Wearables: The Next Evolution in Health Monitoring",
    category: "Wearables",
    excerpt: "How artificial intelligence is transforming wearable devices into powerful health companions.",
  },
  {
    id: "3",
    title: "Quantum Computing: Breaking Down the Latest Breakthroughs",
    category: "Computing",
    excerpt:
      "Understanding the recent advancements in quantum computing and what they mean for the future of technology.",
  },
  {
    id: "4",
    title: "Apple's New M3 MacBook Pro: A Performance Beast",
    category: "Laptops",
    excerpt: "A detailed review of Apple's latest MacBook Pro with the M3 chip and its impressive performance gains.",
  },
  {
    id: "5",
    title: "Samsung Galaxy S24 Ultra Review: The Ultimate Android Experience",
    category: "Smartphones",
    excerpt: "Our comprehensive review of Samsung's flagship smartphone and its cutting-edge features.",
  },
  {
    id: "6",
    title: "The Best Noise-Cancelling Headphones of 2025",
    category: "Accessories",
    excerpt: "A comparison of the top noise-cancelling headphones on the market and which ones are worth your money.",
  },
]

interface SearchDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function SearchDialog({ open, onOpenChange }: SearchDialogProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [results, setResults] = useState<typeof searchData>([])
  const [isSearching, setIsSearching] = useState(false)
  const [selectedIndex, setSelectedIndex] = useState(-1)
  const router = useRouter()

  // Handle search input changes
  useEffect(() => {
    if (searchQuery.length > 1) {
      setIsSearching(true)
      // Simulate search delay
      const timer = setTimeout(() => {
        const filteredResults = searchData.filter(
          (item) =>
            item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.category.toLowerCase().includes(searchQuery.toLowerCase()),
        )
        setResults(filteredResults)
        setIsSearching(false)
        setSelectedIndex(-1) // Reset selection when results change
      }, 300)

      return () => clearTimeout(timer)
    } else {
      setResults([])
      setSelectedIndex(-1)
    }
  }, [searchQuery])

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Close on escape
      if (e.key === "Escape") {
        onOpenChange(false)
      }

      // Open on Ctrl+K or Command+K
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault()
        onOpenChange(true)
      }

      if (open) {
        // Navigate results with arrow keys
        if (e.key === "ArrowDown") {
          e.preventDefault()
          setSelectedIndex((prev) => (prev < results.length - 1 ? prev + 1 : prev))
        } else if (e.key === "ArrowUp") {
          e.preventDefault()
          setSelectedIndex((prev) => (prev > 0 ? prev - 1 : prev))
        } else if (e.key === "Enter" && selectedIndex >= 0) {
          e.preventDefault()
          handleResultClick(results[selectedIndex].id)
        }
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    return () => document.removeEventListener("keydown", handleKeyDown)
  }, [open, onOpenChange, results, selectedIndex])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim() && results.length > 0) {
      router.push(`/search?q=${encodeURIComponent(searchQuery)}`)
      onOpenChange(false)
    }
  }

  const handleResultClick = (id: string) => {
    router.push(`/article/${id}`)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] p-0">
        <DialogHeader className="p-4 border-b">
          <DialogTitle className="text-center">Search SLKtech</DialogTitle>
        </DialogHeader>
        <div className="p-4">
          <form onSubmit={handleSearch} className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              type="search"
              placeholder="Search articles, topics, or keywords..."
              className="pl-10 pr-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoFocus
            />
            {searchQuery && (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1 h-8 w-8"
                onClick={() => setSearchQuery("")}
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </form>

          <div className="mt-4 max-h-[60vh] overflow-y-auto">
            {isSearching ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : (
              <AnimatePresence>
                {searchQuery.length > 1 && (
                  <div className="space-y-1">
                    {results.length > 0 ? (
                      <>
                        <div className="text-sm text-gray-500 mb-2">
                          {results.length} {results.length === 1 ? "result" : "results"} found
                        </div>
                        {results.map((result, index) => (
                          <motion.div
                            key={result.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, y: -10 }}
                            transition={{ duration: 0.2, delay: index * 0.05 }}
                          >
                            <button
                              className={`block w-full text-left p-3 rounded-md transition-colors ${
                                selectedIndex === index ? "bg-gray-100" : "hover:bg-gray-100"
                              }`}
                              onClick={() => handleResultClick(result.id)}
                            >
                              <div className="flex items-start">
                                <div className="flex-1">
                                  <h4 className="font-medium line-clamp-1">{result.title}</h4>
                                  <div className="flex items-center mt-1">
                                    <span className="text-xs px-2 py-0.5 bg-gray-200 rounded-full text-gray-700">
                                      {result.category}
                                    </span>
                                  </div>
                                  <p className="text-sm text-gray-600 mt-1 line-clamp-2">{result.excerpt}</p>
                                </div>
                              </div>
                            </button>
                          </motion.div>
                        ))}
                      </>
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-gray-500">No results found for "{searchQuery}"</p>
                        <p className="text-sm text-gray-400 mt-1">Try different keywords or check your spelling</p>
                      </div>
                    )}
                  </div>
                )}
              </AnimatePresence>
            )}
          </div>

          <div className="mt-4 pt-4 border-t text-xs text-gray-500 flex justify-between">
            <div>Press ESC to close</div>
            <div className="flex space-x-4">
              <span>
                <kbd className="px-1.5 py-0.5 bg-gray-100 rounded border">↑</kbd>{" "}
                <kbd className="px-1.5 py-0.5 bg-gray-100 rounded border">↓</kbd> to navigate
              </span>
              <span>
                <kbd className="px-1.5 py-0.5 bg-gray-100 rounded border">Enter</kbd> to select
              </span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
