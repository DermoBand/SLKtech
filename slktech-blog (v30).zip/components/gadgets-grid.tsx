import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function GadgetsGrid() {
  const categories = [
    {
      id: 1,
      name: "Smartphones",
      description: "The latest and greatest mobile devices",
      image: "/placeholder.svg?height=300&width=400",
      slug: "smartphones",
    },
    {
      id: 2,
      name: "Laptops",
      description: "Powerful portable computers for work and play",
      image: "/placeholder.svg?height=300&width=400",
      slug: "laptops",
    },
    {
      id: 3,
      name: "Wearables",
      description: "Smart watches, fitness trackers, and more",
      image: "/placeholder.svg?height=300&width=400",
      slug: "wearables",
    },
    {
      id: 4,
      name: "Headphones",
      description: "Immersive audio experiences for every budget",
      image: "/placeholder.svg?height=300&width=400",
      slug: "headphones",
    },
    {
      id: 5,
      name: "Cameras",
      description: "Capture your world in stunning detail",
      image: "/placeholder.svg?height=300&width=400",
      slug: "cameras",
    },
    {
      id: 6,
      name: "Smart Home",
      description: "Make your home smarter and more efficient",
      image: "/placeholder.svg?height=300&width=400",
      slug: "smart-home",
    },
  ]

  const featuredGadgets = [
    {
      id: 1,
      name: "iPhone 14 Pro",
      description: "Apple's flagship smartphone with advanced camera system",
      price: "$999",
      image: "/placeholder.svg?height=400&width=400",
      category: "Smartphones",
      slug: "iphone-14-pro",
    },
    {
      id: 2,
      name: "Samsung Galaxy S23 Ultra",
      description: "Powerful Android flagship with S Pen support",
      price: "$1,199",
      image: "/placeholder.svg?height=400&width=400",
      category: "Smartphones",
      slug: "samsung-galaxy-s23-ultra",
    },
    {
      id: 3,
      name: "MacBook Air M2",
      description: "Thin and light laptop with incredible performance",
      price: "$1,199",
      image: "/placeholder.svg?height=400&width=400",
      category: "Laptops",
      slug: "macbook-air-m2",
    },
    {
      id: 4,
      name: "Sony WH-1000XM5",
      description: "Industry-leading noise cancellation headphones",
      price: "$399",
      image: "/placeholder.svg?height=400&width=400",
      category: "Headphones",
      slug: "sony-wh-1000xm5",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Categories */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold mb-6">Browse by Category</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {categories.map((category) => (
            <Link key={category.id} href={`/gadgets/${category.slug}`} className="block group">
              <Card className="overflow-hidden h-full hover:shadow-lg transition-shadow">
                <div className="aspect-video relative">
                  <img
                    src={category.image || "/placeholder.svg"}
                    alt={category.name}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                    <div className="p-4 text-white">
                      <h3 className="text-xl font-bold">{category.name}</h3>
                      <p className="text-sm text-gray-200">{category.description}</p>
                    </div>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </div>

      {/* Featured Gadgets */}
      <div>
        <h2 className="text-2xl font-bold mb-6">Featured Gadgets</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredGadgets.map((gadget) => (
            <Card key={gadget.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-4">
                <div className="aspect-square mb-4 overflow-hidden rounded-md">
                  <img
                    src={gadget.image || "/placeholder.svg"}
                    alt={gadget.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="text-sm text-primary font-medium mb-1">{gadget.category}</div>
                <h3 className="text-lg font-bold mb-1">{gadget.name}</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-2">{gadget.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold">{gadget.price}</span>
                  <Button asChild size="sm">
                    <Link href={`/gadgets/${gadget.slug}`}>View Details</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
