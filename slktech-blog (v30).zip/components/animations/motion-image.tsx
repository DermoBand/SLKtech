"use client"

import { motion, type MotionProps } from "framer-motion"
import Image, { type ImageProps } from "next/image"
import { forwardRef } from "react"

export interface MotionImageProps extends Omit<ImageProps, "ref">, MotionProps {
  delay?: number
  duration?: number
  once?: boolean
  animation?: "fadeIn" | "fadeInUp" | "fadeInDown" | "fadeInLeft" | "fadeInRight" | "zoomIn" | "none"
}

const animations = {
  fadeIn: {
    hidden: { opacity: 0 },
    visible: { opacity: 1 },
  },
  fadeInUp: {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  },
  fadeInDown: {
    hidden: { opacity: 0, y: -20 },
    visible: { opacity: 1, y: 0 },
  },
  fadeInLeft: {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0 },
  },
  fadeInRight: {
    hidden: { opacity: 0, x: 20 },
    visible: { opacity: 1, x: 0 },
  },
  zoomIn: {
    hidden: { opacity: 0, scale: 0.95 },
    visible: { opacity: 1, scale: 1 },
  },
  none: {
    hidden: {},
    visible: {},
  },
}

const MotionImage = forwardRef<HTMLImageElement, MotionImageProps>(
  ({ src, alt, className, delay = 0, duration = 0.5, once = true, animation = "fadeIn", ...props }, ref) => {
    const selectedAnimation = animations[animation]

    return (
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once }}
        variants={selectedAnimation}
        transition={{ duration, delay, ease: "easeOut" }}
        className={className}
      >
        <Image ref={ref} src={src || "/placeholder.svg"} alt={alt} {...props} />
      </motion.div>
    )
  },
)

MotionImage.displayName = "MotionImage"

export { MotionImage }
