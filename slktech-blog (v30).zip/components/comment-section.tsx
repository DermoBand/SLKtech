"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ThumbsUp, Reply, Flag } from "lucide-react"

export function CommentSection() {
  const [comment, setComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [comments, setComments] = useState([
    {
      id: 1,
      author: "Jane Smith",
      avatar: "/placeholder.svg?height=50&width=50",
      content:
        "This is a really insightful article! I've been following this technology for a while and your analysis is spot on.",
      date: "2 days ago",
      likes: 12,
      replies: [
        {
          id: 101,
          author: "John Doe",
          avatar: "/placeholder.svg?height=50&width=50",
          content: "Thanks for your comment, Jane! I'm glad you found the article helpful.",
          date: "1 day ago",
          likes: 3,
        },
      ],
    },
    {
      id: 2,
      author: "Mike Johnson",
      avatar: "/placeholder.svg?height=50&width=50",
      content:
        "I disagree with some points in the article. The technology still has a long way to go before it becomes mainstream.",
      date: "3 days ago",
      likes: 5,
      replies: [],
    },
  ])

  const handleSubmitComment = (e) => {
    e.preventDefault()
    if (!comment.trim()) return

    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      const newComment = {
        id: comments.length + 1,
        author: "Guest User",
        avatar: "/placeholder.svg?height=50&width=50",
        content: comment,
        date: "Just now",
        likes: 0,
        replies: [],
      }

      setComments([newComment, ...comments])
      setComment("")
      setIsSubmitting(false)
    }, 1000)
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-6">Comments ({comments.length})</h2>

        {/* Comment Form */}
        <div className="mb-8">
          <form onSubmit={handleSubmitComment}>
            <Textarea
              placeholder="Join the discussion..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="mb-3"
              rows={4}
            />
            <Button type="submit" disabled={isSubmitting || !comment.trim()}>
              {isSubmitting ? "Posting..." : "Post Comment"}
            </Button>
          </form>
        </div>

        {/* Comments List */}
        <div className="space-y-6">
          {comments.map((comment) => (
            <div key={comment.id} className="border-b pb-6 last:border-b-0">
              <div className="flex gap-4">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={comment.avatar} alt={comment.author} />
                  <AvatarFallback>{comment.author[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex justify-between mb-1">
                    <h4 className="font-medium">{comment.author}</h4>
                    <span className="text-sm text-gray-500">{comment.date}</span>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 mb-3">{comment.content}</p>
                  <div className="flex gap-4">
                    <button className="text-gray-500 hover:text-primary text-sm flex items-center">
                      <ThumbsUp className="h-4 w-4 mr-1" />
                      {comment.likes} Likes
                    </button>
                    <button className="text-gray-500 hover:text-primary text-sm flex items-center">
                      <Reply className="h-4 w-4 mr-1" />
                      Reply
                    </button>
                    <button className="text-gray-500 hover:text-red-500 text-sm flex items-center">
                      <Flag className="h-4 w-4 mr-1" />
                      Report
                    </button>
                  </div>

                  {/* Replies */}
                  {comment.replies.length > 0 && (
                    <div className="mt-4 pl-4 border-l-2 border-gray-100 dark:border-gray-800 space-y-4">
                      {comment.replies.map((reply) => (
                        <div key={reply.id} className="flex gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={reply.avatar} alt={reply.author} />
                            <AvatarFallback>{reply.author[0]}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex justify-between mb-1">
                              <h5 className="font-medium text-sm">{reply.author}</h5>
                              <span className="text-xs text-gray-500">{reply.date}</span>
                            </div>
                            <p className="text-gray-700 dark:text-gray-300 text-sm mb-2">{reply.content}</p>
                            <div className="flex gap-3">
                              <button className="text-gray-500 hover:text-primary text-xs flex items-center">
                                <ThumbsUp className="h-3 w-3 mr-1" />
                                {reply.likes} Likes
                              </button>
                              <button className="text-gray-500 hover:text-red-500 text-xs flex items-center">
                                <Flag className="h-3 w-3 mr-1" />
                                Report
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
