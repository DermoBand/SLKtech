import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, ArrowRight } from "lucide-react"

export function NewsGrid() {
  const newsArticles = [
    {
      id: 1,
      title: "Apple Unveils New MacBook Pro with M3 Chip",
      excerpt:
        "Apple has announced its latest MacBook Pro lineup featuring the new M3 chip, promising significant performance improvements and better battery life.",
      category: "Hardware",
      date: "October 30, 2023",
      readTime: "4 min read",
      image: "/placeholder.svg?height=400&width=600",
      slug: "apple-unveils-new-macbook-pro-m3",
    },
    {
      id: 2,
      title: "Google Announces Major AI Advancements at Annual Conference",
      excerpt:
        "At its annual developer conference, Google revealed several breakthroughs in artificial intelligence that will power its next generation of products and services.",
      category: "AI",
      date: "October 28, 2023",
      readTime: "5 min read",
      image: "/placeholder.svg?height=400&width=600",
      slug: "google-ai-advancements-conference",
    },
    {
      id: 3,
      title: "Samsung to Release New Foldable Smartphones Next Month",
      excerpt:
        "Samsung has confirmed that its next generation of foldable smartphones will be unveiled at an upcoming Galaxy Unpacked event next month.",
      category: "Smartphones",
      date: "October 25, 2023",
      readTime: "3 min read",
      image: "/placeholder.svg?height=400&width=600",
      slug: "samsung-new-foldable-smartphones",
    },
    {
      id: 4,
      title: "Microsoft Expands Cloud Services with New Data Centers",
      excerpt:
        "Microsoft has announced plans to open several new data centers across Europe and Asia to expand its cloud computing capabilities and reduce latency for users in those regions.",
      category: "Cloud",
      date: "October 23, 2023",
      readTime: "4 min read",
      image: "/placeholder.svg?height=400&width=600",
      slug: "microsoft-expands-cloud-data-centers",
    },
    {
      id: 5,
      title: "Tesla Achieves Record Quarterly Deliveries Despite Supply Chain Challenges",
      excerpt:
        "Tesla has reported record vehicle deliveries in the third quarter of 2023, overcoming persistent supply chain issues that have affected the automotive industry.",
      category: "Automotive",
      date: "October 20, 2023",
      readTime: "3 min read",
      image: "/placeholder.svg?height=400&width=600",
      slug: "tesla-record-quarterly-deliveries",
    },
    {
      id: 6,
      title: "New Cybersecurity Threats Targeting Remote Workers",
      excerpt:
        "Security researchers have identified a new wave of sophisticated phishing attacks specifically targeting remote workers and home office setups.",
      category: "Security",
      date: "October 18, 2023",
      readTime: "6 min read",
      image: "/placeholder.svg?height=400&width=600",
      slug: "cybersecurity-threats-remote-workers",
    },
  ]

  const categories = [
    { name: "All", slug: "all" },
    { name: "Hardware", slug: "hardware" },
    { name: "Software", slug: "software" },
    { name: "AI", slug: "ai" },
    { name: "Smartphones", slug: "smartphones" },
    { name: "Security", slug: "security" },
    { name: "Cloud", slug: "cloud" },
  ]

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Categories Filter */}
      <div className="mb-8 overflow-x-auto">
        <div className="flex space-x-2 min-w-max">
          {categories.map((category) => (
            <Link
              key={category.slug}
              href={category.slug === "all" ? "/news" : `/news/category/${category.slug}`}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                category.slug === "all"
                  ? "bg-primary text-white"
                  : "bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700"
              }`}
            >
              {category.name}
            </Link>
          ))}
        </div>
      </div>

      {/* News Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {newsArticles.map((article) => (
          <Card key={article.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <Link href={`/news/${article.slug}`} className="block">
              <div className="aspect-video relative">
                <img
                  src={article.image || "/placeholder.svg"}
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform hover:scale-105 duration-500"
                />
                <div className="absolute top-2 left-2">
                  <Badge className="bg-primary hover:bg-primary/90">{article.category}</Badge>
                </div>
              </div>
            </Link>
            <CardContent className="p-4">
              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-2">
                <Calendar className="h-4 w-4 mr-1" />
                <span className="mr-3">{article.date}</span>
                <Clock className="h-4 w-4 mr-1" />
                <span>{article.readTime}</span>
              </div>
              <Link href={`/news/${article.slug}`} className="block group">
                <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                  {article.title}
                </h3>
              </Link>
              <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3">{article.excerpt}</p>
              <Link
                href={`/news/${article.slug}`}
                className="text-primary flex items-center hover:underline font-medium"
              >
                Read More <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Pagination */}
      <div className="flex justify-center mt-12">
        <div className="flex space-x-1">
          <Link
            href="#"
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium bg-white hover:bg-gray-50"
          >
            Previous
          </Link>
          <Link
            href="#"
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium bg-primary text-white"
          >
            1
          </Link>
          <Link
            href="#"
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium bg-white hover:bg-gray-50"
          >
            2
          </Link>
          <Link
            href="#"
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium bg-white hover:bg-gray-50"
          >
            3
          </Link>
          <Link
            href="#"
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium bg-white hover:bg-gray-50"
          >
            Next
          </Link>
        </div>
      </div>
    </div>
  )
}
