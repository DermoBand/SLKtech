"use client"

import { useState, useEffect } from "react"
import { AnimatedButton } from "@/components/ui/button-animations"
import { X } from "lucide-react"

export function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Check if user has already accepted cookies
    const hasAccepted = localStorage.getItem("cookieConsent") === "accepted"
    if (!hasAccepted) {
      // Show banner after a short delay
      const timer = setTimeout(() => {
        setIsVisible(true)
      }, 1000)
      return () => clearTimeout(timer)
    }
  }, [])

  const acceptCookies = () => {
    localStorage.setItem("cookieConsent", "accepted")
    setIsVisible(false)
  }

  if (!isVisible) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50 p-4 animate-slideUp">
      <div className="container mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex-1">
          <p className="text-sm text-gray-700">
            We use cookies to ensure you get the best experience on our website. By continuing to browse, you agree to
            our use of cookies.
          </p>
        </div>
        <div className="flex gap-2">
          <AnimatedButton size="sm" onClick={acceptCookies}>
            Accept
          </AnimatedButton>
          <AnimatedButton size="sm" variant="outline" onClick={() => setIsVisible(false)}>
            <X className="h-4 w-4" />
          </AnimatedButton>
        </div>
      </div>
    </div>
  )
}
