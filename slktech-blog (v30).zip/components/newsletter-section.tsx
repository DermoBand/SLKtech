"use client"

import type React from "react"

import { useState } from "react"
import { MotionDiv } from "@/components/animations/motion-div"
import { Input } from "@/components/ui/input"
import { AnimatedButton } from "@/components/ui/button-animations"
import { CheckCircle2 } from "lucide-react"
import { motion } from "framer-motion"

export function NewsletterSection() {
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      // Here you would typically send the email to your API
      setIsSubmitted(true)
      setEmail("")

      // Reset after 5 seconds
      setTimeout(() => {
        setIsSubmitted(false)
      }, 5000)
    }
  }

  return (
    <section className="py-16 bg-black text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <MotionDiv animation="fadeInUp" className="mb-6">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Stay Ahead of the <span className="gradient-text">Tech Curve</span>
            </h2>
            <p className="text-gray-400 mb-8">
              Subscribe to our newsletter and never miss the latest tech news, reviews, and deals.
            </p>
          </MotionDiv>

          <MotionDiv animation="fadeInUp" delay={0.2}>
            {isSubmitted ? (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-primary/10 rounded-lg p-6 flex items-center justify-center"
              >
                <CheckCircle2 className="text-primary mr-2 h-5 w-5" />
                <span>Thank you for subscribing!</span>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-white/10 border-white/20 text-white placeholder:text-gray-400 flex-1"
                />
                <AnimatedButton type="submit" className="w-full sm:w-auto">
                  Subscribe
                </AnimatedButton>
              </form>
            )}
            <p className="text-xs text-gray-500 mt-4">We respect your privacy. Unsubscribe at any time.</p>
          </MotionDiv>
        </div>
      </div>
    </section>
  )
}
