"use client"

import { Facebook, Twitter, Instagram, Youtube, Linkedin, Globe } from "lucide-react"
import Link from "next/link"
import { useState, useEffect } from "react"

// This would typically come from your database or API
// For now, we'll use a static list that matches what's in the admin panel
const defaultSocialLinks = [
  { id: "1", platform: "Twitter", url: "https://twitter.com/slktech", icon: Twitter },
  { id: "2", platform: "Facebook", url: "https://facebook.com/slktech", icon: Facebook },
  { id: "3", platform: "Instagram", url: "https://instagram.com/slktech", icon: Instagram },
  { id: "4", platform: "LinkedIn", url: "https://linkedin.com/company/slktech", icon: Linkedin },
  { id: "5", platform: "YouTube", url: "https://youtube.com/slktech", icon: Youtube },
]

interface SocialMediaLinksProps {
  className?: string
  iconClassName?: string
}

export function SocialMediaLinks({ className = "", iconClassName = "h-5 w-5" }: SocialMediaLinksProps) {
  const [socialLinks, setSocialLinks] = useState(defaultSocialLinks)

  // In a real app, you would fetch this data from your API
  useEffect(() => {
    // Simulating an API call
    const fetchSocialLinks = async () => {
      // This would be replaced with an actual API call
      // const response = await fetch('/api/social-links')
      // const data = await response.json()
      // setSocialLinks(data)
    }

    fetchSocialLinks()
  }, [])

  const getIconComponent = (platform: string) => {
    const link = socialLinks.find((link) => link.platform.toLowerCase() === platform.toLowerCase())
    return link?.icon || Globe
  }

  return (
    <div className={`flex space-x-4 ${className}`}>
      {socialLinks.map((link) => {
        const IconComponent = link.icon
        return (
          <Link
            key={link.id}
            href={link.url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-400 hover:text-primary transition-colors"
            aria-label={link.platform}
          >
            <IconComponent className={iconClassName} />
          </Link>
        )
      })}
    </div>
  )
}
