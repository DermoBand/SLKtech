"use client"

import { useState, useEffect } from "react"
import { MotionDiv } from "@/components/animations/motion-div"
import { MotionImage } from "@/components/animations/motion-image"
import { AnimatedButton } from "@/components/ui/button-animations"
import { Badge } from "@/components/ui/badge"
import { ArrowRight } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { useSwipeable } from "@/lib/swipeable"

interface HeroSlide {
  id: string
  title: string
  excerpt: string
  category: string
  image: string
}

const heroSlides: HeroSlide[] = [
  {
    id: "1",
    title: "The Future of Foldable Smartphones: What to Expect in 2025",
    excerpt: "Explore the next generation of foldable technology and how it's reshaping the smartphone industry.",
    category: "Smartphones",
    image: "/placeholder.svg?height=600&width=1200",
  },
  {
    id: "2",
    title: "AI-Powered Wearables: The Next Evolution in Health Monitoring",
    excerpt: "How artificial intelligence is transforming wearable devices into powerful health companions.",
    category: "Wearables",
    image: "/placeholder.svg?height=600&width=1200",
  },
  {
    id: "3",
    title: "Quantum Computing: Breaking Down the Latest Breakthroughs",
    excerpt:
      "Understanding the recent advancements in quantum computing and what they mean for the future of technology.",
    category: "Computing",
    image: "/placeholder.svg?height=600&width=1200",
  },
]

export function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length)
    }, 6000)

    return () => clearInterval(interval)
  }, [])

  // Add swipe handlers
  const handlers = useSwipeable({
    onSwipeLeft: () => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length)
    },
    onSwipeRight: () => {
      setCurrentSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length)
    },
    trackMouse: true,
  })

  return (
    <section
      className="relative h-[70vh] md:h-[80vh] overflow-hidden touch-none"
      ref={handlers.ref}
      onTouchStart={handlers.onTouchStart}
      onTouchEnd={handlers.onTouchEnd}
      onMouseDown={handlers.onMouseDown}
    >
      <AnimatePresence mode="wait">
        {heroSlides.map(
          (slide, index) =>
            index === currentSlide && (
              <motion.div
                key={slide.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1 }}
                className="absolute inset-0"
              >
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/10 z-10" />
                <MotionImage src={slide.image} alt={slide.title} fill className="object-cover" priority />

                <div className="relative z-20 h-full flex items-end">
                  <div className="container mx-auto px-4 pb-16 md:pb-24">
                    <MotionDiv animation="fadeInUp" className="max-w-3xl">
                      <Badge className="mb-4 bg-primary hover:bg-primary/90">{slide.category}</Badge>
                      <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">{slide.title}</h1>
                      <p className="text-gray-200 text-lg mb-6">{slide.excerpt}</p>
                      <AnimatedButton className="group" hoverScale ripple>
                        Read Article
                        <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                      </AnimatedButton>
                    </MotionDiv>
                  </div>
                </div>
              </motion.div>
            ),
        )}
      </AnimatePresence>

      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 z-30 flex space-x-2">
        {heroSlides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide ? "bg-primary w-8" : "bg-white/50 hover:bg-white/80"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  )
}
