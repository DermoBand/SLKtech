import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { MotionDiv } from "@/components/animations/motion-div"
import { MotionImage } from "@/components/animations/motion-image"

export function Hero() {
  return (
    <section className="relative bg-white dark:bg-black overflow-hidden">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <MotionDiv animation="fadeInLeft" delay={0.2}>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
                Discover the Future of <span className="gradient-text">Technology</span>
              </h1>
            </MotionDiv>
            <MotionDiv animation="fadeInLeft" delay={0.4}>
              <p className="text-lg text-gray-600 dark:text-gray-400">
                Stay updated with the latest tech gadgets, devices, and news. SLKtech brings you cutting-edge
                innovations and in-depth reviews.
              </p>
            </MotionDiv>
            <MotionDiv animation="fadeInUp" delay={0.6} className="flex flex-col sm:flex-row gap-4">
              <Button asChild size="lg" className="animate-pulse">
                <Link href="/gadgets">
                  Explore Gadgets
                  <ArrowRight className="ml-2 h-4 w-4 animate-bounce" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/news">Latest News</Link>
              </Button>
            </MotionDiv>
          </div>
          <MotionDiv animation="fadeInRight" delay={0.4} className="relative">
            <div className="aspect-video rounded-lg overflow-hidden shadow-xl">
              <MotionImage
                src="/placeholder.svg?height=600&width=800"
                alt="Latest technology gadgets"
                width={800}
                height={600}
                className="w-full h-full object-cover"
                animation="zoomIn"
                duration={0.8}
              />
            </div>
            <MotionDiv
              animation="fadeInUp"
              delay={0.8}
              className="absolute -bottom-4 -right-4 bg-white dark:bg-gray-900 p-4 rounded-lg shadow-lg"
            >
              <p className="text-sm font-medium">Featured Today</p>
              <h3 className="text-lg font-bold gradient-text">New AI-Powered Devices</h3>
            </MotionDiv>
          </MotionDiv>
        </div>
      </div>
    </section>
  )
}
