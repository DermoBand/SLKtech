"use client"

import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"
import { MotionDiv } from "@/components/animations/motion-div"

export function TrendingGadgets() {
  const gadgets = [
    {
      id: 1,
      title: "Apple Watch Series 9",
      excerpt: "The latest smartwatch from Apple with advanced health features.",
      image: "/placeholder.svg?height=300&width=400",
      slug: "apple-watch-series-9",
    },
    {
      id: 2,
      title: "Samsung Galaxy Buds 3",
      excerpt: "The next generation wireless earbuds from Samsung with improved sound quality.",
      image: "/placeholder.svg?height=300&width=400",
      slug: "samsung-galaxy-buds-3",
    },
    {
      id: 3,
      title: "DJI Mavic Air 4",
      excerpt: "The new drone from DJI with enhanced camera and flight capabilities.",
      image: "/placeholder.svg?height=300&width=400",
      slug: "dji-mavic-air-4",
    },
  ]

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">Trending Gadgets</h2>
          <Link href="/gadgets" className="text-primary flex items-center hover:underline font-medium">
            View All <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {gadgets.map((gadget) => (
            <MotionDiv key={gadget.id} animation="fadeInUp" className="group">
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-video relative">
                  <img
                    src={gadget.image || "/placeholder.svg"}
                    alt={gadget.title}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-500"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                    {gadget.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3">{gadget.excerpt}</p>
                  <Link
                    href={`/gadgets/${gadget.slug}`}
                    className="text-primary flex items-center hover:underline font-medium"
                  >
                    Read More <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </CardContent>
              </Card>
            </MotionDiv>
          ))}
        </div>
      </div>
    </section>
  )
}
