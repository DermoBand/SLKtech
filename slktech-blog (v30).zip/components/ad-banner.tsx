"use client"

import { useEffect, useRef, useState } from "react"
import { usePathname } from "next/navigation"

export function AdBanner() {
  const containerRef = useRef<HTMLDivElement>(null)
  const pathname = usePathname()
  const [showAd, setShowAd] = useState(true)

  useEffect(() => {
    // Don't show ads in admin pages
    setShowAd(!pathname.startsWith("/admin"))
  }, [pathname])

  useEffect(() => {
    if (!showAd || !containerRef.current) return

    // Create a script element for the ad
    const script = document.createElement("script")
    script.async = true
    script.setAttribute("data-cfasync", "false")
    script.src = "//placeholderadserver.com/banner.js" // Replace with actual ad server URL

    // Add the script to the container
    containerRef.current.appendChild(script)

    return () => {
      // Clean up
      if (containerRef.current && containerRef.current.contains(script)) {
        containerRef.current.removeChild(script)
      }
    }
  }, [showAd])

  if (!showAd) return null

  return (
    <div className="w-full py-4 bg-gray-50 border-t border-b">
      <div className="container mx-auto px-4">
        <div
          id="ad-container"
          ref={containerRef}
          className="flex justify-center items-center min-h-[90px] bg-gray-100 rounded text-center"
        >
          <p className="text-gray-400 text-sm">Advertisement</p>
        </div>
      </div>
    </div>
  )
}
