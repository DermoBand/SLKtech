"use client"

import { Button } from "@/components/ui/button"
import { Facebook, Twitter, Linkedin, LinkIcon } from "lucide-react"

interface ArticleContentProps {
  content: string
}

export function ArticleContent({ content }: ArticleContentProps) {
  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href)
    alert("Link copied to clipboard!")
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        {/* Social Share */}
        <div className="flex justify-center mb-8">
          <div className="flex space-x-2">
            <Button variant="outline" size="icon" className="rounded-full">
              <Facebook className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" className="rounded-full">
              <Twitter className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" className="rounded-full">
              <Linkedin className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" className="rounded-full" onClick={handleCopyLink}>
              <LinkIcon className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none dark:prose-invert" dangerouslySetInnerHTML={{ __html: content }} />

        {/* Tags */}
        <div className="mt-8 pt-6 border-t">
          <div className="flex flex-wrap gap-2">
            <span className="text-sm font-medium">Tags:</span>
            <a href="#" className="text-sm text-primary hover:underline">
              Technology
            </a>
            <a href="#" className="text-sm text-primary hover:underline">
              AI
            </a>
            <a href="#" className="text-sm text-primary hover:underline">
              Future
            </a>
          </div>
        </div>

        {/* Author Bio */}
        <div className="mt-8 pt-6 border-t">
          <div className="flex items-center">
            <img src="/placeholder.svg?height=100&width=100" alt="Author" className="w-16 h-16 rounded-full mr-4" />
            <div>
              <h3 className="font-bold text-lg">John Doe</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Tech journalist with over 10 years of experience covering the latest innovations and trends in
                technology.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
