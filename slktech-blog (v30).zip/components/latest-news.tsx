import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

export function LatestNews() {
  const news = [
    {
      id: 1,
      title: "Apple Announces New MacBook Pro with M3 Chip",
      excerpt: "The latest MacBook Pro features the new M3 chip with improved performance and battery life.",
      date: "March 20, 2023",
      slug: "apple-announces-new-macbook-pro",
    },
    {
      id: 2,
      title: "Google Unveils Next-Generation AI Assistant",
      excerpt: "Google's new AI assistant can understand context better and perform more complex tasks.",
      date: "March 18, 2023",
      slug: "google-unveils-next-generation-ai-assistant",
    },
    {
      id: 3,
      title: "Samsung to Release Foldable Smartphone with Improved Durability",
      excerpt: "The new foldable phone from Samsung features a more durable screen and improved hinge mechanism.",
      date: "March 15, 2023",
      slug: "samsung-to-release-foldable-smartphone",
    },
    {
      id: 4,
      title: "Tesla Announces New Electric Vehicle with 500-Mile Range",
      excerpt: "Tesla's newest electric vehicle can travel up to 500 miles on a single charge.",
      date: "March 12, 2023",
      slug: "tesla-announces-new-electric-vehicle",
    },
  ]

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">Latest News</h2>
          <Link href="/news" className="text-primary flex items-center hover:underline font-medium">
            View All <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {news.map((item) => (
            <Card key={item.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">{item.date}</div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">{item.excerpt}</p>
                <Link
                  href={`/news/${item.slug}`}
                  className="text-primary flex items-center hover:underline font-medium"
                >
                  Read More <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
