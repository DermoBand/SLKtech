import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { MotionDiv } from "@/components/animations/motion-div"

export function Footer() {
  return (
    <footer className="bg-black text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <MotionDiv animation="fadeInUp" delay={0.1} className="space-y-4">
            <h3 className="text-2xl font-bold gradient-text">
              SLK<span className="text-white">tech</span>
            </h3>
            <p className="text-gray-400">
              Your source for the latest tech gadgets, devices, and news. Stay updated with the future of technology.
            </p>
          </MotionDiv>

          <MotionDiv animation="fadeInUp" delay={0.2} className="space-y-4">
            <h4 className="text-lg font-semibold">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-400 hover:text-primary transition-colors flex items-center group">
                  <ArrowRight className="h-3 w-3 mr-2 transition-transform group-hover:translate-x-1" />
                  Home
                </Link>
              </li>
              <li>
                <Link
                  href="/news"
                  className="text-gray-400 hover:text-primary transition-colors flex items-center group"
                >
                  <ArrowRight className="h-3 w-3 mr-2 transition-transform group-hover:translate-x-1" />
                  News
                </Link>
              </li>
              <li>
                <Link
                  href="/gadgets"
                  className="text-gray-400 hover:text-primary transition-colors flex items-center group"
                >
                  <ArrowRight className="h-3 w-3 mr-2 transition-transform group-hover:translate-x-1" />
                  Gadgets
                </Link>
              </li>
              <li>
                <Link
                  href="/reviews"
                  className="text-gray-400 hover:text-primary transition-colors flex items-center group"
                >
                  <ArrowRight className="h-3 w-3 mr-2 transition-transform group-hover:translate-x-1" />
                  Reviews
                </Link>
              </li>
              <li>
                <Link
                  href="/about"
                  className="text-gray-400 hover:text-primary transition-colors flex items-center group"
                >
                  <ArrowRight className="h-3 w-3 mr-2 transition-transform group-hover:translate-x-1" />
                  About
                </Link>
              </li>
            </ul>
          </MotionDiv>

          <MotionDiv animation="fadeInUp" delay={0.3} className="space-y-4">
            <h4 className="text-lg font-semibold">Categories</h4>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/gadgets/smartphones"
                  className="text-gray-400 hover:text-primary transition-colors flex items-center group"
                >
                  <ArrowRight className="h-3 w-3 mr-2 transition-transform group-hover:translate-x-1" />
                  Smartphones
                </Link>
              </li>
              <li>
                <Link
                  href="/gadgets/laptops"
                  className="text-gray-400 hover:text-primary transition-colors flex items-center group"
                >
                  <ArrowRight className="h-3 w-3 mr-2 transition-transform group-hover:translate-x-1" />
                  Laptops
                </Link>
              </li>
              <li>
                <Link
                  href="/gadgets/wearables"
                  className="text-gray-400 hover:text-primary transition-colors flex items-center group"
                >
                  <ArrowRight className="h-3 w-3 mr-2 transition-transform group-hover:translate-x-1" />
                  Wearables
                </Link>
              </li>
              <li>
                <Link
                  href="/gadgets/accessories"
                  className="text-gray-400 hover:text-primary transition-colors flex items-center group"
                >
                  <ArrowRight className="h-3 w-3 mr-2 transition-transform group-hover:translate-x-1" />
                  Accessories
                </Link>
              </li>
              <li>
                <Link
                  href="/news/reviews"
                  className="text-gray-400 hover:text-primary transition-colors flex items-center group"
                >
                  <ArrowRight className="h-3 w-3 mr-2 transition-transform group-hover:translate-x-1" />
                  Tech Reviews
                </Link>
              </li>
            </ul>
          </MotionDiv>

          <MotionDiv animation="fadeInUp" delay={0.4} className="space-y-4">
            <h4 className="text-lg font-semibold">Newsletter</h4>
            <p className="text-gray-400">Subscribe to our newsletter for the latest updates and tech news.</p>
            <div className="flex space-x-2">
              <Input type="email" placeholder="Your email" className="bg-gray-800 border-gray-700 text-white" />
              <Button className="animate-pulse">Subscribe</Button>
            </div>
          </MotionDiv>
        </div>

        <MotionDiv animation="fadeInUp" delay={0.5} className="mt-12 pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">© {new Date().getFullYear()} SLKtech. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="/privacy" className="text-gray-400 hover:text-primary text-sm transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-gray-400 hover:text-primary text-sm transition-colors">
                Terms of Service
              </Link>
              <Link href="/contact" className="text-gray-400 hover:text-primary text-sm transition-colors">
                Contact Us
              </Link>
            </div>
          </div>
        </MotionDiv>
      </div>
    </footer>
  )
}
