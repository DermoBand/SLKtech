"use client"

import { useState } from "react"
import { ProductShowcase } from "@/components/product-showcase"

// Sample products that can be embedded in articles
const embeddableProducts = [
  {
    id: "sony-wh-1000xm5",
    slug: "sony-wh-1000xm5",
    title: "Sony WH-1000XM5",
    description:
      "Premium noise-cancelling headphones with exceptional sound quality and industry-leading noise cancellation technology.",
    category: "headphones",
    categoryName: "Headphones",
    brand: "Sony",
    image: "/placeholder.svg?height=300&width=300",
    price: 349.99,
    oldPrice: 399.99,
    rating: 4.8,
    reviewCount: 1245,
    features: [
      "Industry-leading noise cancellation",
      "Up to 30-hour battery life",
      "Crystal clear hands-free calling",
      "Multi-point connection",
    ],
  },
  {
    id: "apple-watch-series-8",
    slug: "apple-watch-series-8",
    title: "Apple Watch Series 8",
    description: "Advanced health features and always-on display in a sleek design.",
    category: "wearables",
    categoryName: "Wearables",
    brand: "Apple",
    image: "/placeholder.svg?height=300&width=300",
    price: 399.99,
    oldPrice: 429.99,
    rating: 4.7,
    reviewCount: 982,
    features: [
      "Advanced health features",
      "Crash Detection",
      "Enhanced Workout app",
      "Sleep tracking",
      "Always-On Retina display",
    ],
  },
  {
    id: "samsung-galaxy-z-fold-4",
    slug: "samsung-galaxy-z-fold-4",
    title: "Samsung Galaxy Z Fold 4",
    description: "Foldable smartphone with a large internal display for productivity.",
    category: "smartphones",
    categoryName: "Smartphones",
    brand: "Samsung",
    image: "/placeholder.svg?height=300&width=300",
    price: 1799.99,
    oldPrice: 1899.99,
    rating: 4.6,
    reviewCount: 756,
    features: [
      "Foldable 7.6-inch main display",
      "Snapdragon 8+ Gen 1 processor",
      "Triple camera system",
      "S Pen compatibility",
      "IPX8 water resistance",
    ],
  },
  {
    id: "dji-mini-3-pro",
    slug: "dji-mini-3-pro",
    title: "DJI Mini 3 Pro",
    description: "Compact drone with professional-grade camera and obstacle avoidance.",
    category: "drones",
    categoryName: "Drones",
    brand: "DJI",
    image: "/placeholder.svg?height=300&width=300",
    price: 759.99,
    oldPrice: 799.99,
    rating: 4.9,
    reviewCount: 432,
    features: [
      "4K/60fps video",
      "48MP photos",
      "Tri-directional obstacle sensing",
      "34 minutes of flight time",
      "Weighs less than 249g",
    ],
  },
]

interface ArticleProductEmbedProps {
  productId: string
  variant?: "compact" | "full"
  className?: string
}

export function ArticleProductEmbed({ productId, variant = "compact", className = "" }: ArticleProductEmbedProps) {
  const [product] = useState(() => embeddableProducts.find((p) => p.id === productId) || embeddableProducts[0])

  return <ProductShowcase product={product} variant={variant} className={className} />
}
