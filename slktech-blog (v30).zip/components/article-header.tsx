import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, User } from "lucide-react"

interface ArticleHeaderProps {
  title: string
  date: string
  author: string
  category: string
  image: string
  readTime?: string
}

export function ArticleHeader({ title, date, author, category, image, readTime = "5 min read" }: ArticleHeaderProps) {
  return (
    <div className="relative">
      {/* Hero Image */}
      <div className="h-[40vh] md:h-[50vh] relative">
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/10 z-10" />
        <img src={image || "/placeholder.svg"} alt={title} className="w-full h-full object-cover" />
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-20 -mt-32">
        <div className="max-w-3xl mx-auto bg-white dark:bg-gray-900 p-6 md:p-8 rounded-lg shadow-lg">
          <Badge className="mb-4 bg-primary hover:bg-primary/90">{category}</Badge>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{title}</h1>

          <div className="flex flex-wrap items-center text-gray-500 dark:text-gray-400 gap-4 mb-6">
            <div className="flex items-center">
              <User className="h-4 w-4 mr-2" />
              {author}
            </div>
            <div className="flex items-center">
              <Calendar className="h-4 w-4 mr-2" />
              {date}
            </div>
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              {readTime}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
