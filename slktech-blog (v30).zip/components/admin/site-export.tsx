"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, Check, Loader2, Archive, FileText, Settings, Globe } from "lucide-react"
import { MotionDiv } from "@/components/animations/motion-div"

export function SiteExport() {
  const [isExporting, setIsExporting] = useState(false)
  const [isComplete, setIsComplete] = useState(false)
  const [exportType, setExportType] = useState("full")
  const [selectedOptions, setSelectedOptions] = useState({
    includeImages: true,
    includeArticles: true,
    includeSettings: true,
    optimizeForHosting: true,
    includeComments: true,
    includeUsers: false,
    includeAnalytics: false,
  })
  const [progress, setProgress] = useState(0)

  const handleExport = async () => {
    setIsExporting(true)
    setProgress(0)

    // Simulate export process with progress updates
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 5
      })
    }, 200)

    // Simulate export completion
    setTimeout(() => {
      clearInterval(interval)
      setProgress(100)

      setTimeout(() => {
        // Create a dummy zip file for demonstration
        const dummyContent = "This is a simulated export file for SLKtech website."
        const blob = new Blob([dummyContent], { type: "application/zip" })
        const url = URL.createObjectURL(blob)

        // Create a download link and trigger it
        const a = document.createElement("a")
        a.href = url
        a.download = `slktech-${exportType}-export.zip`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)

        // Clean up the URL object
        URL.revokeObjectURL(url)

        setIsExporting(false)
        setIsComplete(true)

        // Reset complete state after 3 seconds
        setTimeout(() => {
          setIsComplete(false)
        }, 3000)
      }, 500)
    }, 4000)
  }

  const handleOptionChange = (option: keyof typeof selectedOptions) => {
    setSelectedOptions({
      ...selectedOptions,
      [option]: !selectedOptions[option],
    })
  }

  return (
    <MotionDiv animation="fadeInUp">
      <Card>
        <CardHeader>
          <CardTitle>Export Website</CardTitle>
          <CardDescription>Export your website files for deployment to your hosting provider.</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="full" value={exportType} onValueChange={setExportType} className="mb-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="full" className="flex items-center justify-center">
                <Archive className="mr-2 h-4 w-4" />
                Full Site
              </TabsTrigger>
              <TabsTrigger value="content" className="flex items-center justify-center">
                <FileText className="mr-2 h-4 w-4" />
                Content Only
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex items-center justify-center">
                <Settings className="mr-2 h-4 w-4" />
                Settings Only
              </TabsTrigger>
            </TabsList>

            <TabsContent value="full">
              <div className="text-sm text-gray-500 mb-4">
                Export the complete website including all content, media, and settings.
              </div>
            </TabsContent>

            <TabsContent value="content">
              <div className="text-sm text-gray-500 mb-4">
                Export only the content (articles, media, comments) without system settings.
              </div>
            </TabsContent>

            <TabsContent value="settings">
              <div className="text-sm text-gray-500 mb-4">
                Export only the system settings and configurations without content.
              </div>
            </TabsContent>
          </Tabs>

          <div className="space-y-4">
            {exportType === "full" && (
              <>
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="optimizeForHosting"
                    checked={selectedOptions.optimizeForHosting}
                    onCheckedChange={() => handleOptionChange("optimizeForHosting")}
                  />
                  <div className="grid gap-1.5">
                    <Label htmlFor="optimizeForHosting" className="font-medium">
                      Optimize for Hosting
                    </Label>
                    <p className="text-sm text-gray-500">Compress and optimize files for web hosting</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="includeUsers"
                    checked={selectedOptions.includeUsers}
                    onCheckedChange={() => handleOptionChange("includeUsers")}
                  />
                  <div className="grid gap-1.5">
                    <Label htmlFor="includeUsers" className="font-medium">
                      Include User Data
                    </Label>
                    <p className="text-sm text-gray-500">Export user accounts and profiles (excluding passwords)</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="includeAnalytics"
                    checked={selectedOptions.includeAnalytics}
                    onCheckedChange={() => handleOptionChange("includeAnalytics")}
                  />
                  <div className="grid gap-1.5">
                    <Label htmlFor="includeAnalytics" className="font-medium">
                      Include Analytics Data
                    </Label>
                    <p className="text-sm text-gray-500">Export analytics and site statistics</p>
                  </div>
                </div>
              </>
            )}

            {(exportType === "full" || exportType === "content") && (
              <>
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="includeImages"
                    checked={selectedOptions.includeImages}
                    onCheckedChange={() => handleOptionChange("includeImages")}
                  />
                  <div className="grid gap-1.5">
                    <Label htmlFor="includeImages" className="font-medium">
                      Include Images
                    </Label>
                    <p className="text-sm text-gray-500">Export all images and media files</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="includeArticles"
                    checked={selectedOptions.includeArticles}
                    onCheckedChange={() => handleOptionChange("includeArticles")}
                  />
                  <div className="grid gap-1.5">
                    <Label htmlFor="includeArticles" className="font-medium">
                      Include Articles
                    </Label>
                    <p className="text-sm text-gray-500">Export all article content and metadata</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="includeComments"
                    checked={selectedOptions.includeComments}
                    onCheckedChange={() => handleOptionChange("includeComments")}
                  />
                  <div className="grid gap-1.5">
                    <Label htmlFor="includeComments" className="font-medium">
                      Include Comments
                    </Label>
                    <p className="text-sm text-gray-500">Export user comments on articles</p>
                  </div>
                </div>
              </>
            )}

            {(exportType === "full" || exportType === "settings") && (
              <div className="flex items-start space-x-3">
                <Checkbox
                  id="includeSettings"
                  checked={selectedOptions.includeSettings}
                  onCheckedChange={() => handleOptionChange("includeSettings")}
                />
                <div className="grid gap-1.5">
                  <Label htmlFor="includeSettings" className="font-medium">
                    Include Settings
                  </Label>
                  <p className="text-sm text-gray-500">Export site configuration and settings</p>
                </div>
              </div>
            )}
          </div>

          {isExporting && (
            <div className="mt-6">
              <div className="flex justify-between text-sm mb-1">
                <span>Exporting...</span>
                <span>{progress}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="bg-primary h-2.5 rounded-full transition-all duration-300 ease-in-out"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <div className="text-xs text-gray-500 mt-2">
                {progress < 30 && "Preparing files..."}
                {progress >= 30 && progress < 60 && "Processing content..."}
                {progress >= 60 && progress < 90 && "Optimizing for export..."}
                {progress >= 90 && "Finalizing export..."}
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={handleExport} disabled={isExporting || isComplete} className="w-full">
            {isExporting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Exporting...
              </>
            ) : isComplete ? (
              <>
                <Check className="mr-2 h-4 w-4" />
                Export Complete
              </>
            ) : (
              <>
                <Download className="mr-2 h-4 w-4" />
                Export Website
              </>
            )}
          </Button>
        </CardFooter>
      </Card>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Deployment Guide</CardTitle>
          <CardDescription>Follow these steps to deploy your exported site</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="font-medium flex items-center">
                <Globe className="mr-2 h-4 w-4 text-primary" />
                Deployment Options
              </h3>
              <ul className="mt-2 space-y-2 text-sm">
                <li className="flex">
                  <span className="text-primary mr-2">1.</span>
                  <span>Extract the downloaded ZIP file to your local machine</span>
                </li>
                <li className="flex">
                  <span className="text-primary mr-2">2.</span>
                  <span>Upload the files to your web hosting provider using FTP or their file manager</span>
                </li>
                <li className="flex">
                  <span className="text-primary mr-2">3.</span>
                  <span>Configure your domain to point to the hosting provider</span>
                </li>
                <li className="flex">
                  <span className="text-primary mr-2">4.</span>
                  <span>Set up any required environment variables as specified in the included README file</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-medium">Recommended Hosting Providers</h3>
              <ul className="mt-2 space-y-1 text-sm">
                <li>• Vercel - Optimized for Next.js applications</li>
                <li>• Netlify - Great for static sites and JAMstack applications</li>
                <li>• DigitalOcean - Flexible cloud hosting options</li>
                <li>• AWS Amplify - Scalable hosting with AWS integration</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </MotionDiv>
  )
}
