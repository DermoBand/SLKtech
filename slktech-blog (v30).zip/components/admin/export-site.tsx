"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Download, Check, Loader2 } from "lucide-react"

export function ExportSite() {
  const [isExporting, setIsExporting] = useState(false)
  const [isComplete, setIsComplete] = useState(false)
  const [selectedOptions, setSelectedOptions] = useState({
    includeImages: true,
    includeArticles: true,
    includeSettings: true,
    optimizeForHosting: true,
  })

  const handleExport = async () => {
    setIsExporting(true)

    // Simulate export process
    await new Promise((resolve) => setTimeout(resolve, 3000))

    // Create a dummy zip file for demonstration
    const dummyContent = "This is a simulated export file for SLKtech website."
    const blob = new Blob([dummyContent], { type: "application/zip" })
    const url = URL.createObjectURL(blob)

    // Create a download link and trigger it
    const a = document.createElement("a")
    a.href = url
    a.download = "slktech-export.zip"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)

    // Clean up the URL object
    URL.revokeObjectURL(url)

    setIsExporting(false)
    setIsComplete(true)

    // Reset complete state after 3 seconds
    setTimeout(() => {
      setIsComplete(false)
    }, 3000)
  }

  const handleOptionChange = (option: keyof typeof selectedOptions) => {
    setSelectedOptions({
      ...selectedOptions,
      [option]: !selectedOptions[option],
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Export Website</CardTitle>
        <CardDescription>Export your website files for deployment to your hosting provider.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-start space-x-3">
            <Checkbox
              id="includeImages"
              checked={selectedOptions.includeImages}
              onCheckedChange={() => handleOptionChange("includeImages")}
            />
            <div className="grid gap-1.5">
              <Label htmlFor="includeImages" className="font-medium">
                Include Images
              </Label>
              <p className="text-sm text-gray-500">Export all images and media files</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <Checkbox
              id="includeArticles"
              checked={selectedOptions.includeArticles}
              onCheckedChange={() => handleOptionChange("includeArticles")}
            />
            <div className="grid gap-1.5">
              <Label htmlFor="includeArticles" className="font-medium">
                Include Articles
              </Label>
              <p className="text-sm text-gray-500">Export all article content and metadata</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <Checkbox
              id="includeSettings"
              checked={selectedOptions.includeSettings}
              onCheckedChange={() => handleOptionChange("includeSettings")}
            />
            <div className="grid gap-1.5">
              <Label htmlFor="includeSettings" className="font-medium">
                Include Settings
              </Label>
              <p className="text-sm text-gray-500">Export site configuration and settings</p>
            </div>
          </div>

          <div className="flex items-start space-x-3">
            <Checkbox
              id="optimizeForHosting"
              checked={selectedOptions.optimizeForHosting}
              onCheckedChange={() => handleOptionChange("optimizeForHosting")}
            />
            <div className="grid gap-1.5">
              <Label htmlFor="optimizeForHosting" className="font-medium">
                Optimize for Hosting
              </Label>
              <p className="text-sm text-gray-500">Compress and optimize files for web hosting</p>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleExport} disabled={isExporting || isComplete} className="w-full">
          {isExporting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Exporting...
            </>
          ) : isComplete ? (
            <>
              <Check className="mr-2 h-4 w-4" />
              Export Complete
            </>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Export Website
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
