"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AnimatedButton } from "@/components/ui/button-animations"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Save,
  ImageIcon,
  ArrowLeft,
  Calendar,
  Tag,
  Eye,
  FileText,
  Code,
  Heading1,
  Heading2,
  ListOrdered,
  ListChecks,
  Bold,
  Italic,
  LinkIcon,
  Quote,
  Undo,
  Redo,
  Loader2,
} from "lucide-react"

// Mock categories data
const categories = [
  { value: "smartphones", label: "Smartphones" },
  { value: "laptops", label: "Laptops" },
  { value: "wearables", label: "Wearables" },
  { value: "accessories", label: "Accessories" },
  { value: "smart-home", label: "Smart Home" },
  { value: "computing", label: "Computing" },
]

interface ArticleEditorProps {
  articleId?: string // If provided, we're editing an existing article
  onSave?: (data: any, status: "draft" | "published") => void
  onCancel?: () => void
  isSubmitting?: boolean
}

export function ArticleEditor({ articleId, onSave, onCancel, isSubmitting = false }: ArticleEditorProps) {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("write")
  const [isSaving, setIsSaving] = useState(false)
  const [previewHtml, setPreviewHtml] = useState("")
  const [articleData, setArticleData] = useState({
    title: "",
    slug: "",
    excerpt: "",
    content: "",
    category: "",
    tags: "",
    featuredImage: "",
    status: "draft",
    publishDate: new Date().toISOString().split("T")[0], // Today's date
    allowComments: true,
    seoTitle: "",
    seoDescription: "",
  })

  // If articleId is provided, fetch the article data
  useEffect(() => {
    if (articleId) {
      // In a real app, this would be an API call
      // For now, we'll simulate loading existing article data
      setIsSaving(true)
      setTimeout(() => {
        setArticleData({
          title: "The Future of Foldable Smartphones: What to Expect in 2025",
          slug: "future-of-foldable-smartphones-2025",
          excerpt:
            "Explore the next generation of foldable technology and how it's reshaping the smartphone industry with innovative designs and improved durability.",
          content:
            "The foldable smartphone market has evolved significantly since the first devices hit the shelves. As we look ahead to 2025, several exciting developments are on the horizon that promise to revolutionize how we interact with our mobile devices.\n\n## Improved Durability and Design\n\nOne of the biggest challenges for early foldable phones was durability. The delicate folding mechanisms and screens were prone to damage. However, manufacturers have made significant strides in addressing these issues.\n\n## Enhanced Performance and Battery Life\n\nAs foldable phones become more mainstream, we're seeing dedicated processors and components designed specifically for these unique form factors.",
          category: "smartphones",
          tags: "foldable phones, smartphone technology, future tech",
          featuredImage: "/placeholder.svg?height=400&width=600",
          status: "published",
          publishDate: "2025-04-05",
          allowComments: true,
          seoTitle: "Future of Foldable Smartphones in 2025 | SLKtech",
          seoDescription:
            "Discover what's next for foldable smartphones in 2025, including improved durability, better performance, and new innovative designs.",
        })
        setIsSaving(false)
      }, 1000)
    }
  }, [articleId])

  // Generate preview HTML from markdown content
  useEffect(() => {
    if (activeTab === "preview") {
      // In a real app, this would use a markdown parser
      // For now, we'll do a simple conversion for demonstration
      const html = articleData.content
        .replace(/^## (.*$)/gim, "<h2>$1</h2>")
        .replace(/^# (.*$)/gim, "<h1>$1</h1>")
        .replace(/\*\*(.*)\*\*/gim, "<strong>$1</strong>")
        .replace(/\*(.*)\*/gim, "<em>$1</em>")
        .replace(/\n/gim, "<br />")

      setPreviewHtml(html)
    }
  }, [activeTab, articleData.content])

  const handleChange = (field: keyof typeof articleData, value: string | boolean) => {
    setArticleData({
      ...articleData,
      [field]: value,
    })

    // Auto-generate slug from title if slug is empty
    if (field === "title" && !articleData.slug) {
      const slug = (value as string)
        .toLowerCase()
        .replace(/[^\w\s]/gi, "")
        .replace(/\s+/g, "-")
      setArticleData((prev) => ({ ...prev, slug }))
    }
  }

  const handleSave = (status: "draft" | "published") => {
    // Use the external isSubmitting state if provided
    if (isSubmitting) return

    // Otherwise use internal state
    setIsSaving(true)

    // Update the status
    const updatedData = { ...articleData, status }

    // In a real app, this would be an API call
    if (onSave) {
      onSave(updatedData, status)
    } else {
      setTimeout(() => {
        setIsSaving(false)
        router.push("/admin/articles")
      }, 1500)
    }
  }

  const handleCancel = () => {
    if (onCancel) {
      onCancel()
    } else {
      router.push("/admin/articles")
    }
  }

  const insertTextAtCursor = (textBefore: string, textAfter = "") => {
    const textarea = document.getElementById("content") as HTMLTextAreaElement
    if (!textarea) return

    const start = textarea.selectionStart
    const end = textarea.selectionEnd
    const selectedText = textarea.value.substring(start, end)
    const newText =
      textarea.value.substring(0, start) + textBefore + selectedText + textAfter + textarea.value.substring(end)

    setArticleData({ ...articleData, content: newText })

    // Set cursor position after the inserted text
    setTimeout(() => {
      textarea.focus()
      const newCursorPos = start + textBefore.length + selectedText.length
      textarea.setSelectionRange(newCursorPos, newCursorPos)
    }, 0)
  }

  const handleToolbarAction = (action: string) => {
    switch (action) {
      case "h1":
        insertTextAtCursor("# ", "\n")
        break
      case "h2":
        insertTextAtCursor("## ", "\n")
        break
      case "bold":
        insertTextAtCursor("**", "**")
        break
      case "italic":
        insertTextAtCursor("*", "*")
        break
      case "link":
        insertTextAtCursor("[", "](https://example.com)")
        break
      case "quote":
        insertTextAtCursor("> ", "\n")
        break
      case "code":
        insertTextAtCursor("```\n", "\n```")
        break
      case "ul":
        insertTextAtCursor("- ", "\n")
        break
      case "ol":
        insertTextAtCursor("1. ", "\n")
        break
      default:
        break
    }
  }

  // Use either the external isSubmitting prop or the internal isSaving state
  const isProcessing = isSubmitting || isSaving

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <Button variant="ghost" size="sm" onClick={handleCancel} className="mb-2">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Articles
          </Button>
          <h1 className="text-2xl font-bold">{articleId ? "Edit Article" : "Create New Article"}</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => handleSave("draft")} disabled={isProcessing}>
            Save Draft
          </Button>
          <AnimatedButton size="sm" onClick={() => handleSave("published")} disabled={isProcessing}>
            {isProcessing ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                {articleId ? "Update" : "Publish"}
              </>
            )}
          </AnimatedButton>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Article Content</CardTitle>
              <CardDescription>Write your article content here</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  placeholder="Article title"
                  value={articleData.title}
                  onChange={(e) => handleChange("title", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="slug">Slug</Label>
                <Input
                  id="slug"
                  placeholder="article-slug"
                  value={articleData.slug}
                  onChange={(e) => handleChange("slug", e.target.value)}
                />
                <p className="text-xs text-gray-500">
                  The "slug" is the URL-friendly version of the title. It is usually all lowercase and contains only
                  letters, numbers, and hyphens.
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="excerpt">Excerpt</Label>
                <Textarea
                  id="excerpt"
                  placeholder="Brief summary of the article"
                  rows={3}
                  value={articleData.excerpt}
                  onChange={(e) => handleChange("excerpt", e.target.value)}
                />
              </div>

              <Tabs defaultValue="write" value={activeTab} onValueChange={setActiveTab}>
                <div className="flex justify-between items-center mb-2">
                  <TabsList>
                    <TabsTrigger value="write" className="flex items-center gap-1">
                      <FileText className="h-4 w-4" />
                      Write
                    </TabsTrigger>
                    <TabsTrigger value="preview" className="flex items-center gap-1">
                      <Eye className="h-4 w-4" />
                      Preview
                    </TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="write" className="mt-0">
                  <div className="bg-gray-100 p-1 rounded-md mb-2 flex flex-wrap gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2"
                      onClick={() => handleToolbarAction("h1")}
                      title="Heading 1"
                    >
                      <Heading1 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2"
                      onClick={() => handleToolbarAction("h2")}
                      title="Heading 2"
                    >
                      <Heading2 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2"
                      onClick={() => handleToolbarAction("bold")}
                      title="Bold"
                    >
                      <Bold className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2"
                      onClick={() => handleToolbarAction("italic")}
                      title="Italic"
                    >
                      <Italic className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2"
                      onClick={() => handleToolbarAction("link")}
                      title="Link"
                    >
                      <LinkIcon className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2"
                      onClick={() => handleToolbarAction("quote")}
                      title="Quote"
                    >
                      <Quote className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2"
                      onClick={() => handleToolbarAction("code")}
                      title="Code Block"
                    >
                      <Code className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2"
                      onClick={() => handleToolbarAction("ul")}
                      title="Bullet List"
                    >
                      <ListChecks className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2"
                      onClick={() => handleToolbarAction("ol")}
                      title="Numbered List"
                    >
                      <ListOrdered className="h-4 w-4" />
                    </Button>
                    <div className="ml-auto flex">
                      <Button variant="ghost" size="sm" className="h-8 px-2" title="Undo">
                        <Undo className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="h-8 px-2" title="Redo">
                        <Redo className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <Textarea
                    id="content"
                    placeholder="Write your article content here using Markdown..."
                    rows={15}
                    value={articleData.content}
                    onChange={(e) => handleChange("content", e.target.value)}
                    className="font-mono"
                  />
                  <p className="text-xs text-gray-500 mt-2">
                    Use Markdown to format your content. You can use # for headings, ** for bold, * for italic, etc.
                  </p>
                </TabsContent>

                <TabsContent value="preview" className="mt-0">
                  <div className="border rounded-md p-4 min-h-[400px] prose max-w-none">
                    <h1 className="text-2xl font-bold mb-4">{articleData.title}</h1>
                    <div dangerouslySetInnerHTML={{ __html: previewHtml }} />
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Featured Image</CardTitle>
              <CardDescription>Add a featured image for your article</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed rounded-lg p-6 text-center">
                {articleData.featuredImage ? (
                  <div className="relative">
                    <img
                      src={articleData.featuredImage || "/placeholder.svg"}
                      alt="Featured"
                      className="max-h-[300px] mx-auto rounded-lg"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={() => handleChange("featuredImage", "")}
                    >
                      Remove
                    </Button>
                  </div>
                ) : (
                  <div>
                    <ImageIcon className="h-10 w-10 mx-auto mb-3 text-gray-400" />
                    <div className="text-sm text-gray-500 mb-3">
                      Drag and drop an image here, or click to select a file
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => handleChange("featuredImage", "/placeholder.svg?height=400&width=600")}
                    >
                      Select Image
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Publish Settings</CardTitle>
              <CardDescription>Configure your article settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select value={articleData.status} onValueChange={(value) => handleChange("status", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="published">Published</SelectItem>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="publishDate">Publish Date</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                  <Input
                    id="publishDate"
                    type="date"
                    className="pl-9"
                    value={articleData.publishDate}
                    onChange={(e) => handleChange("publishDate", e.target.value)}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="allowComments">Allow Comments</Label>
                  <p className="text-xs text-gray-500">Enable comments on this article</p>
                </div>
                <Switch
                  id="allowComments"
                  checked={articleData.allowComments}
                  onCheckedChange={(checked) => handleChange("allowComments", checked)}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Categories & Tags</CardTitle>
              <CardDescription>Organize your article</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select value={articleData.category} onValueChange={(value) => handleChange("category", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="tags">Tags</Label>
                <div className="relative">
                  <Tag className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                  <Input
                    id="tags"
                    placeholder="Enter tags separated by commas"
                    className="pl-9"
                    value={articleData.tags}
                    onChange={(e) => handleChange("tags", e.target.value)}
                  />
                </div>
                <p className="text-xs text-gray-500">
                  Tags help users find related content. Add multiple tags separated by commas.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>SEO Settings</CardTitle>
              <CardDescription>Optimize for search engines</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="seoTitle">SEO Title</Label>
                <Input
                  id="seoTitle"
                  placeholder="SEO optimized title (optional)"
                  value={articleData.seoTitle}
                  onChange={(e) => handleChange("seoTitle", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="seoDescription">Meta Description</Label>
                <Textarea
                  id="seoDescription"
                  placeholder="Brief description for search engines"
                  rows={3}
                  value={articleData.seoDescription}
                  onChange={(e) => handleChange("seoDescription", e.target.value)}
                />
                <p className="text-xs text-gray-500">
                  Recommended length: 150-160 characters. This appears in search engine results.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
