"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { CheckCircle2, AlertCircle } from "lucide-react"

interface ChecklistItem {
  id: string
  title: string
  description: string
  checked: boolean
  critical: boolean
}

export function LaunchChecklist() {
  const [checklist, setChecklist] = useState<ChecklistItem[]>([
    {
      id: "1",
      title: "Content Ready",
      description: "Ensure all pages have proper content and there are no placeholder texts.",
      checked: true,
      critical: true,
    },
    {
      id: "2",
      title: "Mobile Responsiveness",
      description: "Test the site on various mobile devices to ensure it's fully responsive.",
      checked: true,
      critical: true,
    },
    {
      id: "3",
      title: "Browser Compatibility",
      description: "Test the site in different browsers (Chrome, Firefox, Safari, Edge).",
      checked: true,
      critical: true,
    },
    {
      id: "4",
      title: "Performance Optimization",
      description: "Ensure images are optimized and code is minified for faster loading.",
      checked: true,
      critical: false,
    },
    {
      id: "5",
      title: "SEO Setup",
      description: "Verify meta tags, sitemap, and robots.txt are properly configured.",
      checked: true,
      critical: true,
    },
    {
      id: "6",
      title: "Analytics Integration",
      description: "Set up analytics to track visitor behavior.",
      checked: false,
      critical: false,
    },
    {
      id: "7",
      title: "Ad Implementation",
      description: "Ensure ads are properly implemented and displaying correctly.",
      checked: true,
      critical: true,
    },
    {
      id: "8",
      title: "Form Validation",
      description: "Test all forms to ensure they validate inputs correctly.",
      checked: true,
      critical: true,
    },
    {
      id: "9",
      title: "Error Pages",
      description: "Verify custom 404 and error pages are working properly.",
      checked: true,
      critical: true,
    },
    {
      id: "10",
      title: "Security Measures",
      description: "Implement basic security measures like HTTPS and form protection.",
      checked: true,
      critical: true,
    },
  ])

  const handleToggleItem = (id: string) => {
    setChecklist(checklist.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item)))
  }

  const getProgress = () => {
    const completed = checklist.filter((item) => item.checked).length
    const total = checklist.length
    return {
      percentage: Math.round((completed / total) * 100),
      completed,
      total,
    }
  }

  const criticalItemsCompleted = checklist.filter((item) => item.critical).every((item) => item.checked)

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle>Launch Readiness</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="relative h-16 w-16">
              <svg className="h-16 w-16" viewBox="0 0 100 100">
                <circle
                  className="text-gray-200"
                  strokeWidth="8"
                  stroke="currentColor"
                  fill="transparent"
                  r="42"
                  cx="50"
                  cy="50"
                />
                <circle
                  className="text-primary"
                  strokeWidth="8"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="transparent"
                  r="42"
                  cx="50"
                  cy="50"
                  strokeDasharray={264}
                  strokeDashoffset={264 - (264 * getProgress().percentage) / 100}
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xl font-bold">{getProgress().percentage}%</span>
              </div>
            </div>
            <div>
              <p className="text-lg font-medium">
                {getProgress().completed} of {getProgress().total} tasks completed
              </p>
              <p className="text-sm text-gray-500">
                {criticalItemsCompleted ? "All critical items completed!" : "Some critical items still need attention"}
              </p>
            </div>
          </div>
          <Button disabled={!criticalItemsCompleted}>Launch Site</Button>
        </div>

        <div className="space-y-4">
          {checklist.map((item) => (
            <div key={item.id} className="flex items-start space-x-3">
              <Checkbox
                id={`item-${item.id}`}
                checked={item.checked}
                onCheckedChange={() => handleToggleItem(item.id)}
              />
              <div className="grid gap-1.5">
                <div className="flex items-center">
                  <Label htmlFor={`item-${item.id}`} className="font-medium">
                    {item.title}
                  </Label>
                  {item.critical && (
                    <span className="ml-2 text-xs bg-red-100 text-red-800 px-1.5 py-0.5 rounded">Critical</span>
                  )}
                </div>
                <p className="text-sm text-gray-500">{item.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 space-y-4">
          {criticalItemsCompleted ? (
            <div className="p-4 bg-green-50 rounded-lg border border-green-200 flex gap-3">
              <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium text-green-800">Your site is ready for launch!</h3>
                <p className="text-sm text-green-700 mt-1">
                  All critical components have been implemented. You can now deploy your site.
                </p>
              </div>
            </div>
          ) : (
            <div className="p-4 bg-amber-50 rounded-lg border border-amber-200 flex gap-3">
              <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium text-amber-800">Some critical items need attention</h3>
                <p className="text-sm text-amber-700 mt-1">
                  Please complete all critical items before launching your site.
                </p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
