"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AnimatedButton } from "@/components/ui/button-animations"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Save, Loader2, Check, Trash2, Plus } from "lucide-react"
import { motion } from "framer-motion"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type SocialLink = {
  id: string
  platform: string
  url: string
}

const platformOptions = [
  { value: "twitter", label: "Twitter" },
  { value: "facebook", label: "Facebook" },
  { value: "instagram", label: "Instagram" },
  { value: "linkedin", label: "LinkedIn" },
  { value: "youtube", label: "YouTube" },
  { value: "pinterest", label: "Pinterest" },
  { value: "tiktok", label: "TikTok" },
  { value: "reddit", label: "Reddit" },
  { value: "discord", label: "Discord" },
  { value: "github", label: "GitHub" },
  { value: "other", label: "Other" },
]

export function SocialLinks() {
  const [isSaving, setIsSaving] = useState(false)
  const [isComplete, setIsComplete] = useState(false)
  const [socialLinks, setSocialLinks] = useState<SocialLink[]>([
    { id: "1", platform: "twitter", url: "https://twitter.com/slktech" },
    { id: "2", platform: "facebook", url: "https://facebook.com/slktech" },
    { id: "3", platform: "instagram", url: "https://instagram.com/slktech" },
    { id: "4", platform: "linkedin", url: "https://linkedin.com/company/slktech" },
  ])

  const handleSave = async () => {
    setIsSaving(true)

    // Simulate saving to database
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSaving(false)
    setIsComplete(true)

    // Reset complete state after 2 seconds
    setTimeout(() => {
      setIsComplete(false)
    }, 2000)
  }

  const handleAddLink = () => {
    const newId = (Math.max(0, ...socialLinks.map((link) => Number.parseInt(link.id))) + 1).toString()
    setSocialLinks([...socialLinks, { id: newId, platform: "", url: "" }])
  }

  const handleRemoveLink = (id: string) => {
    setSocialLinks(socialLinks.filter((link) => link.id !== id))
  }

  const handleUpdateLink = (id: string, field: "platform" | "url", value: string) => {
    setSocialLinks(socialLinks.map((link) => (link.id === id ? { ...link, [field]: value } : link)))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Social Media Links</CardTitle>
        <CardDescription>Manage your social media profiles that appear on your website.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {socialLinks.map((link, index) => (
            <motion.div
              key={link.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="grid grid-cols-[1fr_2fr_auto] gap-4 items-end"
            >
              <div>
                <Label htmlFor={`platform-${link.id}`} className="mb-2 block">
                  Platform
                </Label>
                <Select value={link.platform} onValueChange={(value) => handleUpdateLink(link.id, "platform", value)}>
                  <SelectTrigger id={`platform-${link.id}`}>
                    <SelectValue placeholder="Select platform" />
                  </SelectTrigger>
                  <SelectContent>
                    {platformOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor={`url-${link.id}`} className="mb-2 block">
                  URL
                </Label>
                <Input
                  id={`url-${link.id}`}
                  value={link.url}
                  onChange={(e) => handleUpdateLink(link.id, "url", e.target.value)}
                  placeholder="https://..."
                />
              </div>
              <AnimatedButton
                variant="outline"
                size="icon"
                onClick={() => handleRemoveLink(link.id)}
                className="h-10 w-10 shrink-0"
              >
                <Trash2 className="h-4 w-4" />
                <span className="sr-only">Remove</span>
              </AnimatedButton>
            </motion.div>
          ))}

          <AnimatedButton variant="outline" onClick={handleAddLink} className="w-full mt-2">
            <Plus className="h-4 w-4 mr-2" />
            Add Social Link
          </AnimatedButton>
        </div>
      </CardContent>
      <CardFooter>
        <AnimatedButton onClick={handleSave} disabled={isSaving || isComplete} className="w-full">
          {isSaving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : isComplete ? (
            <>
              <Check className="mr-2 h-4 w-4" />
              Saved Successfully
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Save Social Links
            </>
          )}
        </AnimatedButton>
      </CardFooter>
    </Card>
  )
}
