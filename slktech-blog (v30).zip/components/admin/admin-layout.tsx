"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { AnimatedButton } from "@/components/ui/button-animations"
import { Button } from "@/components/ui/button"
import {
  BarChart3,
  Users,
  FileText,
  MessageSquare,
  Settings,
  LogOut,
  Menu,
  X,
  Globe,
  ImageIcon,
  Tag,
  Rocket,
  Download,
  ExternalLink,
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface AdminLayoutProps {
  children: React.ReactNode
}

export function AdminLayout({ children }: AdminLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [mounted, setMounted] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    setMounted(true)
  }, [])

  // Close sidebar when route changes (mobile)
  useEffect(() => {
    setSidebarOpen(false)
  }, [pathname])

  if (!mounted) return null

  const navItems = [
    {
      title: "Main",
      items: [
        {
          name: "Dashboard",
          href: "/admin/dashboard",
          icon: BarChart3,
          active: pathname === "/admin/dashboard",
        },
        {
          name: "Articles",
          href: "/admin/articles",
          icon: FileText,
          active: pathname.startsWith("/admin/articles"),
        },
        {
          name: "Comments",
          href: "/admin/comments",
          icon: MessageSquare,
          active: pathname.startsWith("/admin/comments"),
        },
        {
          name: "Media",
          href: "/admin/media",
          icon: ImageIcon,
          active: pathname.startsWith("/admin/media"),
        },
        {
          name: "Categories",
          href: "/admin/categories",
          icon: Tag,
          active: pathname.startsWith("/admin/categories"),
        },
        {
          name: "Users",
          href: "/admin/users",
          icon: Users,
          active: pathname.startsWith("/admin/users"),
        },
      ],
    },
    {
      title: "Settings",
      items: [
        {
          name: "Site Settings",
          href: "/admin/site",
          icon: Globe,
          active: pathname === "/admin/site",
        },
        {
          name: "Launch Checklist",
          href: "/admin/launch-checklist",
          icon: Rocket,
          active: pathname === "/admin/launch-checklist",
        },
        {
          name: "Export Site",
          href: "/admin/export",
          icon: Download,
          active: pathname === "/admin/export",
        },
        {
          name: "Account Settings",
          href: "/admin/settings",
          icon: Settings,
          active: pathname === "/admin/settings",
        },
      ],
    },
  ]

  const handleLogout = () => {
    // In a real app, you would clear auth tokens/cookies here
    window.location.href = "/admin"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 z-40 bg-white border-b h-16 flex items-center px-4">
        <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(!sidebarOpen)}>
          <Menu className="h-5 w-5" />
        </Button>
        <div className="ml-4">
          <h2 className="text-xl font-bold">
            <span className="gradient-text">SLK</span>tech CMS
          </h2>
        </div>
      </header>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        initial={{ x: -280 }}
        animate={{ x: sidebarOpen ? 0 : -280 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="fixed top-0 left-0 z-50 h-full bg-white shadow-md lg:translate-x-0 w-64"
      >
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="flex items-center justify-between p-4 border-b h-16"
        >
          <h2 className="text-xl font-bold">
            <span className="gradient-text">SLK</span>tech CMS
          </h2>
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(false)}>
            <X className="h-5 w-5" />
          </Button>
        </motion.div>

        <div className="overflow-y-auto h-[calc(100vh-4rem)]">
          <nav className="p-2">
            {navItems.map((section, sectionIndex) => (
              <motion.div
                key={section.title}
                className="mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + sectionIndex * 0.1 }}
              >
                <div className="px-3 py-2 text-xs font-semibold text-gray-400 uppercase">{section.title}</div>
                {section.items.map((item, itemIndex) => (
                  <motion.div
                    key={item.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 + sectionIndex * 0.1 + itemIndex * 0.05 }}
                    whileHover={{ x: 5 }}
                  >
                    <Link
                      href={item.href}
                      className={`flex items-center px-3 py-2 my-1 text-sm font-medium rounded-md transition-colors ${
                        item.active
                          ? "bg-gray-100 text-primary border-r-4 border-primary"
                          : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                      }`}
                    >
                      <item.icon className="w-5 h-5 mr-3" />
                      {item.name}
                    </Link>
                  </motion.div>
                ))}
              </motion.div>
            ))}

            <motion.div
              className="px-3 pt-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              <AnimatedButton onClick={handleLogout} variant="outline" className="w-full justify-start text-gray-600">
                <LogOut className="w-5 h-5 mr-3" />
                Logout
              </AnimatedButton>
            </motion.div>

            <motion.div
              className="px-3 pt-4 pb-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
            >
              <Link
                href="/"
                target="_blank"
                className="flex items-center text-sm text-gray-500 hover:text-primary transition-colors"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                View Site
              </Link>
            </motion.div>
          </nav>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="pt-16 lg:pt-0 lg:pl-64 min-h-screen">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="p-4 md:p-6 lg:p-8"
        >
          {children}
        </motion.div>
      </main>
    </div>
  )
}
