"use client"

import { useEffect, useState } from "react"
import { useMobileDetector } from "@/hooks/use-mobile-detector"

export function MobileDetector() {
  const isMobile = useMobileDetector()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="fixed bottom-4 right-4 z-50 bg-black/80 text-white text-xs px-2 py-1 rounded-full pointer-events-none">
      {isMobile ? "Mobile View" : "Desktop View"}
    </div>
  )
}
