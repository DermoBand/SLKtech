"use client"

import { useState } from "react"
import Link from "next/link"
import { MotionDiv } from "@/components/animations/motion-div"
import { MotionImage } from "@/components/animations/motion-image"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight } from "lucide-react"

interface TrendingArticle {
  id: string
  title: string
  category: string
  image: string
  date: string
}

const trendingCategories = [
  { value: "all", label: "All" },
  { value: "smartphones", label: "Smartphones" },
  { value: "laptops", label: "Laptops" },
  { value: "wearables", label: "Wearables" },
  { value: "accessories", label: "Accessories" },
]

const trendingArticles: Record<string, TrendingArticle[]> = {
  all: [
    {
      id: "1",
      title: "Apple's New M3 MacBook Pro: A Performance Beast",
      category: "Laptops",
      image: "/placeholder.svg?height=300&width=500",
      date: "2 days ago",
    },
    {
      id: "2",
      title: "Samsung Galaxy S24 Ultra Review: The Ultimate Android Experience",
      category: "Smartphones",
      image: "/placeholder.svg?height=300&width=500",
      date: "3 days ago",
    },
    {
      id: "3",
      title: "Apple Watch Series 9 vs. Google Pixel Watch 2: Which Should You Buy?",
      category: "Wearables",
      image: "/placeholder.svg?height=300&width=500",
      date: "5 days ago",
    },
    {
      id: "4",
      title: "The Best Noise-Cancelling Headphones of 2025",
      category: "Accessories",
      image: "/placeholder.svg?height=300&width=500",
      date: "1 week ago",
    },
  ],
  smartphones: [
    {
      id: "2",
      title: "Samsung Galaxy S24 Ultra Review: The Ultimate Android Experience",
      category: "Smartphones",
      image: "/placeholder.svg?height=300&width=500",
      date: "3 days ago",
    },
    {
      id: "5",
      title: "iPhone 16 Pro: Everything We Know So Far",
      category: "Smartphones",
      image: "/placeholder.svg?height=300&width=500",
      date: "1 week ago",
    },
    {
      id: "6",
      title: "Google Pixel 8 Pro: Six Months Later",
      category: "Smartphones",
      image: "/placeholder.svg?height=300&width=500",
      date: "2 weeks ago",
    },
    {
      id: "7",
      title: "The Rise of Foldable Phones: Are They Worth It?",
      category: "Smartphones",
      image: "/placeholder.svg?height=300&width=500",
      date: "3 weeks ago",
    },
  ],
  laptops: [
    {
      id: "1",
      title: "Apple's New M3 MacBook Pro: A Performance Beast",
      category: "Laptops",
      image: "/placeholder.svg?height=300&width=500",
      date: "2 days ago",
    },
    {
      id: "8",
      title: "Dell XPS 13 (2025): The Perfect Ultrabook?",
      category: "Laptops",
      image: "/placeholder.svg?height=300&width=500",
      date: "1 week ago",
    },
    {
      id: "9",
      title: "Gaming Laptops vs. Desktop PCs: Which Is Better in 2025?",
      category: "Laptops",
      image: "/placeholder.svg?height=300&width=500",
      date: "2 weeks ago",
    },
    {
      id: "10",
      title: "The Best Budget Laptops for Students",
      category: "Laptops",
      image: "/placeholder.svg?height=300&width=500",
      date: "3 weeks ago",
    },
  ],
  wearables: [
    {
      id: "3",
      title: "Apple Watch Series 9 vs. Google Pixel Watch 2: Which Should You Buy?",
      category: "Wearables",
      image: "/placeholder.svg?height=300&width=500",
      date: "5 days ago",
    },
    {
      id: "11",
      title: "The Future of Health Tracking: Beyond Step Counting",
      category: "Wearables",
      image: "/placeholder.svg?height=300&width=500",
      date: "1 week ago",
    },
    {
      id: "12",
      title: "Smart Rings: The Next Big Thing in Wearable Tech?",
      category: "Wearables",
      image: "/placeholder.svg?height=300&width=500",
      date: "2 weeks ago",
    },
    {
      id: "13",
      title: "Fitness Trackers: Finding the Right One for Your Workout",
      category: "Wearables",
      image: "/placeholder.svg?height=300&width=500",
      date: "3 weeks ago",
    },
  ],
  accessories: [
    {
      id: "4",
      title: "The Best Noise-Cancelling Headphones of 2025",
      category: "Accessories",
      image: "/placeholder.svg?height=300&width=500",
      date: "1 week ago",
    },
    {
      id: "14",
      title: "Wireless Chargers: Speed vs. Convenience",
      category: "Accessories",
      image: "/placeholder.svg?height=300&width=500",
      date: "2 weeks ago",
    },
    {
      id: "15",
      title: "Must-Have Smartphone Accessories in 2025",
      category: "Accessories",
      image: "/placeholder.svg?height=300&width=500",
      date: "3 weeks ago",
    },
    {
      id: "16",
      title: "The Ultimate Tech Backpack for Digital Nomads",
      category: "Accessories",
      image: "/placeholder.svg?height=300&width=500",
      date: "4 weeks ago",
    },
  ],
}

export function TrendingSection() {
  const [activeTab, setActiveTab] = useState("all")

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <MotionDiv
          animation="fadeInUp"
          className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8"
        >
          <div>
            <h2 className="text-3xl font-bold mb-2">Trending Now</h2>
            <p className="text-gray-600">Stay updated with the hottest tech stories</p>
          </div>

          <Link href="/trending" className="flex items-center text-primary hover:underline mt-4 md:mt-0">
            View All
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </MotionDiv>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <MotionDiv animation="fadeInDown" className="mb-8">
            <TabsList className="bg-muted/50 p-1 w-full overflow-x-auto flex flex-nowrap max-w-full">
              {trendingCategories.map((category) => (
                <TabsTrigger
                  key={category.value}
                  value={category.value}
                  className="data-[state=active]:bg-white data-[state=active]:text-primary data-[state=active]:shadow-sm flex-shrink-0"
                >
                  {category.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </MotionDiv>

          {trendingCategories.map((category) => (
            <TabsContent key={category.value} value={category.value} className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {trendingArticles[category.value].map((article, index) => (
                  <MotionDiv key={article.id} animation="fadeInUp" delay={index * 0.1} className="group">
                    <Link href={`/article/${article.id}`} className="block">
                      <div className="relative overflow-hidden rounded-lg mb-3">
                        <MotionImage
                          src={article.image}
                          alt={article.title}
                          width={500}
                          height={300}
                          className="w-full aspect-[4/3] object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                        <div className="absolute top-3 left-3">
                          <Badge className="bg-primary hover:bg-primary/90">{article.category}</Badge>
                        </div>
                      </div>
                      <h3 className="font-semibold text-lg mb-1 group-hover:text-primary transition-colors">
                        {article.title}
                      </h3>
                      <p className="text-gray-500 text-sm">{article.date}</p>
                    </Link>
                  </MotionDiv>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  )
}
