import Link from "next/link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

export function FeaturedArticles() {
  const articles = [
    {
      id: 1,
      title: "The Future of AI in Consumer Electronics",
      excerpt: "How artificial intelligence is revolutionizing our everyday devices.",
      image: "/placeholder.svg?height=400&width=600",
      category: "Artificial Intelligence",
      date: "March 15, 2023",
      slug: "future-of-ai-in-consumer-electronics",
    },
    {
      id: 2,
      title: "Review: The Latest Flagship Smartphones",
      excerpt: "We compare the top smartphones of 2023 to help you choose the best.",
      image: "/placeholder.svg?height=400&width=600",
      category: "Smartphones",
      date: "March 10, 2023",
      slug: "review-latest-flagship-smartphones",
    },
    {
      id: 3,
      title: "Smart Home Devices That Actually Save You Money",
      excerpt: "These smart home gadgets pay for themselves through energy savings.",
      image: "/placeholder.svg?height=400&width=600",
      category: "Smart Home",
      date: "March 5, 2023",
      slug: "smart-home-devices-that-save-money",
    },
  ]

  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">Featured Articles</h2>
          <Link href="/articles" className="text-primary flex items-center hover:underline font-medium">
            View All <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {articles.map((article) => (
            <Card key={article.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="aspect-video relative overflow-hidden">
                <img
                  src={article.image || "/placeholder.svg"}
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform hover:scale-105 duration-500"
                />
                <div className="absolute top-2 left-2 bg-primary text-white text-xs px-2 py-1 rounded">
                  {article.category}
                </div>
              </div>
              <CardContent className="pt-4">
                <div className="text-sm text-gray-500 dark:text-gray-400 mb-2">{article.date}</div>
                <h3 className="text-xl font-bold mb-2 line-clamp-2">{article.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 line-clamp-3">{article.excerpt}</p>
              </CardContent>
              <CardFooter>
                <Link
                  href={`/article/${article.slug}`}
                  className="text-primary flex items-center hover:underline font-medium"
                >
                  Read More <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
