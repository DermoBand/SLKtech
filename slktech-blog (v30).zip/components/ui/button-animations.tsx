"use client"

import type React from "react"

import { cn } from "@/lib/utils"
import { Button, type ButtonProps } from "@/components/ui/button"
import { forwardRef, useState } from "react"

export interface AnimatedButtonProps extends ButtonProps {
  hoverScale?: boolean
  ripple?: boolean
  glint?: boolean
}

export const AnimatedButton = forwardRef<HTMLButtonElement, AnimatedButtonProps>(
  ({ className, hoverScale = true, ripple = true, glint = true, children, ...props }, ref) => {
    const [ripples, setRipples] = useState<{ x: number; y: number; size: number; id: number }[]>([])
    const [isHovered, setIsHovered] = useState(false)

    const handleMouseDown = (e: React.MouseEvent<HTMLButtonElement>) => {
      if (!ripple) return

      const button = e.currentTarget
      const rect = button.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top
      const size = Math.max(rect.width, rect.height) * 2

      const newRipple = {
        x,
        y,
        size,
        id: Date.now(),
      }

      setRipples([...ripples, newRipple])

      setTimeout(() => {
        setRipples((ripples) => ripples.filter((r) => r.id !== newRipple.id))
      }, 1000)
    }

    return (
      <Button
        ref={ref}
        className={cn(
          "relative overflow-hidden transition-all duration-300",
          hoverScale && "hover:scale-105 active:scale-95",
          isHovered &&
            glint &&
            "after:absolute after:top-0 after:right-0 after:w-12 after:h-full after:bg-white/20 after:blur-md after:transform after:rotate-12 after:translate-x-32 after:transition-transform after:duration-1000",
          className,
        )}
        onMouseDown={handleMouseDown}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        {...props}
      >
        {ripples.map((ripple) => (
          <span
            key={ripple.id}
            className="absolute rounded-full bg-white/30 animate-ripple pointer-events-none"
            style={{
              left: ripple.x - ripple.size / 2,
              top: ripple.y - ripple.size / 2,
              width: ripple.size,
              height: ripple.size,
              animation: "ripple 1s linear forwards",
            }}
          />
        ))}
        {children}

        <style jsx>{`
          @keyframes ripple {
            to {
              transform: scale(2);
              opacity: 0;
            }
          }
        `}</style>
      </Button>
    )
  },
)

AnimatedButton.displayName = "AnimatedButton"
