"use client"

import { useState } from "react"
import Link from "next/link"
import { MotionImage } from "@/components/animations/motion-image"
import { MotionDiv } from "@/components/animations/motion-div"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, MessageSquare, Share2, Bookmark } from "lucide-react"
import { motion } from "framer-motion"

export interface ArticleCardProps {
  id: string
  title: string
  excerpt: string
  category: string
  image: string
  author: {
    name: string
    avatar: string
  }
  date: string
  readTime: string
  commentCount: number
  featured?: boolean
  index?: number
}

export function ArticleCard({
  id,
  title,
  excerpt,
  category,
  image,
  author,
  date,
  readTime,
  commentCount,
  featured = false,
  index = 0,
}: ArticleCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <MotionDiv
      animation="fadeInUp"
      delay={index * 0.1}
      className={`group ${featured ? "col-span-full md:col-span-2" : ""}`}
    >
      <Card
        className="overflow-hidden border-none shadow-sm hover:shadow-lg transition-shadow duration-300"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <CardContent className="p-0">
          <div className={`grid ${featured ? "md:grid-cols-2" : "grid-cols-1"} gap-4`}>
            <div className="relative overflow-hidden">
              <Link href={`/article/${id}`}>
                <MotionImage
                  src={image}
                  alt={title}
                  width={800}
                  height={450}
                  className="w-full aspect-video object-cover transition-transform duration-500"
                  style={{
                    transform: isHovered ? "scale(1.05)" : "scale(1)",
                  }}
                  animation="fadeIn"
                />
              </Link>
              <motion.div
                className="absolute top-4 left-4"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Badge className="bg-primary hover:bg-primary/90">{category}</Badge>
              </motion.div>
            </div>

            <div className="p-4 flex flex-col">
              <motion.div
                className="flex items-center space-x-2 mb-3"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <img src={author.avatar || "/placeholder.svg"} alt={author.name} className="w-6 h-6 rounded-full" />
                <span className="text-xs text-gray-500">{author.name}</span>
                <span className="text-xs text-gray-400">•</span>
                <span className="text-xs text-gray-500">{date}</span>
              </motion.div>

              <Link href={`/article/${id}`} className="group-hover:text-primary transition-colors">
                <motion.h3
                  className="text-xl font-bold mb-2 line-clamp-2"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                >
                  {title}
                </motion.h3>
              </Link>

              <motion.p
                className="text-gray-600 text-sm mb-4 line-clamp-2 md:line-clamp-3"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                {excerpt}
              </motion.p>

              <motion.div
                className="mt-auto flex items-center justify-between"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                <div className="flex items-center space-x-4">
                  <div className="flex items-center text-xs text-gray-500">
                    <Clock className="h-3 w-3 mr-1" />
                    {readTime}
                  </div>
                  <div className="flex items-center text-xs text-gray-500">
                    <MessageSquare className="h-3 w-3 mr-1" />
                    {commentCount}
                  </div>
                </div>

                <div className="flex space-x-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="text-gray-400 hover:text-primary transition-colors"
                  >
                    <Share2 className="h-4 w-4" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="text-gray-400 hover:text-primary transition-colors"
                  >
                    <Bookmark className="h-4 w-4" />
                  </motion.button>
                </div>
              </motion.div>
            </div>
          </div>
        </CardContent>
      </Card>
    </MotionDiv>
  )
}
