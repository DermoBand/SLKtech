"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MotionDiv } from "@/components/animations/motion-div"
import { motion } from "framer-motion"

export function Newsletter() {
  return (
    <section className="bg-gray-50 dark:bg-gray-900 py-16">
      <div className="container mx-auto px-4">
        <MotionDiv animation="fadeInUp" className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold mb-4">
              Stay Updated with <span className="gradient-text">SLKtech</span>
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-8">
              Subscribe to our newsletter and never miss the latest tech news, reviews, and deals.
            </p>
          </motion.div>

          <motion.form
            className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <Input type="email" placeholder="Enter your email" className="flex-1" required />
            <Button type="submit" className="animate-pulse">
              Subscribe
            </Button>
          </motion.form>

          <motion.p
            className="text-xs text-gray-500 mt-4"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            By subscribing, you agree to our Privacy Policy and consent to receive updates from our company.
          </motion.p>
        </MotionDiv>
      </div>
    </section>
  )
}
