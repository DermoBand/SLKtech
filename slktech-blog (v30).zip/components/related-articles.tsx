import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

export function RelatedArticles() {
  const articles = [
    {
      id: 1,
      title: "The Future of AI in Consumer Electronics",
      excerpt:
        "How artificial intelligence is revolutionizing our everyday devices and changing the way we interact with technology.",
      image: "/placeholder.svg?height=300&width=500",
      slug: "future-of-ai-consumer-electronics",
    },
    {
      id: 2,
      title: "Top 5 Smartphones of 2023",
      excerpt:
        "Our comprehensive review of the best smartphones released this year, comparing features, performance, and value.",
      image: "/placeholder.svg?height=300&width=500",
      slug: "top-5-smartphones-2023",
    },
    {
      id: 3,
      title: "The Rise of Foldable Devices",
      excerpt:
        "Exploring the growing trend of foldable smartphones and tablets and what it means for the future of mobile computing.",
      image: "/placeholder.svg?height=300&width=500",
      slug: "rise-of-foldable-devices",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-6">Related Articles</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {articles.map((article) => (
            <Card key={article.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <Link href={`/article/${article.slug}`} className="block">
                  <div className="aspect-video mb-3 overflow-hidden rounded-md">
                    <img
                      src={article.image || "/placeholder.svg"}
                      alt={article.title}
                      className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                    />
                  </div>
                  <h3 className="font-bold mb-2 hover:text-primary transition-colors line-clamp-2">{article.title}</h3>
                </Link>
                <p className="text-gray-600 dark:text-gray-400 text-sm mb-3 line-clamp-2">{article.excerpt}</p>
                <Link
                  href={`/article/${article.slug}`}
                  className="text-primary flex items-center text-sm hover:underline"
                >
                  Read More <ArrowRight className="ml-1 h-3 w-3" />
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
