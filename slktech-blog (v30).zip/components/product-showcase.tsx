"use client"

import { useState } from "react"
import Link from "next/link"
import { MotionDiv } from "@/components/animations/motion-div"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, ShoppingCart, ExternalLink } from "lucide-react"
import { motion } from "framer-motion"

interface ProductShowcaseProps {
  product: {
    id: string
    slug: string
    title: string
    description: string
    category: string
    categoryName: string
    brand: string
    image: string
    price: number
    oldPrice?: number | null
    rating: number
    reviewCount: number
    features?: string[]
  }
  variant?: "compact" | "full"
  className?: string
}

export function ProductShowcase({ product, variant = "full", className = "" }: ProductShowcaseProps) {
  const [isAddingToCart, setIsAddingToCart] = useState(false)
  const [isAddedToCart, setIsAddedToCart] = useState(false)

  const handleAddToCart = () => {
    setIsAddingToCart(true)
    // Simulate API call
    setTimeout(() => {
      setIsAddingToCart(false)
      setIsAddedToCart(true)
      setTimeout(() => {
        setIsAddedToCart(false)
      }, 3000)
    }, 1000)
  }

  if (variant === "compact") {
    return (
      <MotionDiv
        animation="fadeInUp"
        className={`border rounded-lg overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow ${className}`}
      >
        <div className="flex flex-col sm:flex-row">
          <div className="sm:w-1/3 p-4">
            <img
              src={product.image || "/placeholder.svg"}
              alt={product.title}
              className="w-full h-auto object-contain aspect-square"
            />
          </div>
          <div className="sm:w-2/3 p-4 flex flex-col">
            <div className="flex items-center mb-1">
              <Badge variant="outline" className="text-xs">
                {product.brand}
              </Badge>
              <span className="mx-2 text-xs text-gray-400">•</span>
              <span className="text-xs text-gray-500">{product.categoryName}</span>
            </div>
            <h3 className="text-lg font-medium mb-1">{product.title}</h3>
            <div className="flex items-center mb-2">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="ml-1 text-xs text-gray-500">({product.reviewCount})</span>
            </div>
            <p className="text-sm text-gray-600 mb-3 line-clamp-2">{product.description}</p>
            <div className="flex items-baseline mb-3">
              <span className="text-lg font-bold text-primary">${product.price.toFixed(2)}</span>
              {product.oldPrice && (
                <span className="ml-2 text-sm text-gray-500 line-through">${product.oldPrice.toFixed(2)}</span>
              )}
            </div>
            <div className="flex gap-2 mt-auto">
              <Button size="sm" asChild className="flex-1">
                <Link href={`/gadgets/${product.slug}`}>
                  <ExternalLink className="w-4 h-4 mr-1" />
                  View Details
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </MotionDiv>
    )
  }

  return (
    <MotionDiv
      animation="fadeInUp"
      className={`border rounded-lg overflow-hidden bg-white shadow hover:shadow-lg transition-shadow ${className}`}
    >
      <div className="p-6">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="md:w-1/3">
            <img
              src={product.image || "/placeholder.svg"}
              alt={product.title}
              className="w-full h-auto object-contain aspect-square"
            />
          </div>
          <div className="md:w-2/3 flex flex-col">
            <div className="flex items-center mb-2">
              <Badge variant="outline" className="mr-2">
                {product.brand}
              </Badge>
              <Badge className="bg-primary/10 text-primary hover:bg-primary/20">{product.categoryName}</Badge>
            </div>
            <h3 className="text-2xl font-bold mb-2">{product.title}</h3>
            <div className="flex items-center mb-4">
              <div className="flex mr-2">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-500">({product.reviewCount} reviews)</span>
            </div>
            <p className="text-gray-700 mb-4">{product.description}</p>

            {product.features && (
              <div className="mb-4">
                <h4 className="font-medium mb-2">Key Features:</h4>
                <ul className="space-y-1">
                  {product.features.map((feature, index) => (
                    <motion.li
                      key={index}
                      className="flex items-start text-sm"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 * index }}
                    >
                      <span className="text-green-500 mr-2">✓</span>
                      {feature}
                    </motion.li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex items-baseline mb-6">
              <span className="text-3xl font-bold text-primary">${product.price.toFixed(2)}</span>
              {product.oldPrice && (
                <>
                  <span className="ml-3 text-lg text-gray-500 line-through">${product.oldPrice.toFixed(2)}</span>
                  <span className="ml-3 bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded">
                    Save ${(product.oldPrice - product.price).toFixed(2)}
                  </span>
                </>
              )}
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                className="flex-1 gap-2"
                size="lg"
                onClick={handleAddToCart}
                disabled={isAddingToCart || isAddedToCart}
              >
                {isAddingToCart ? (
                  <>
                    <motion.div
                      className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                    />
                    Adding...
                  </>
                ) : isAddedToCart ? (
                  <>
                    <span className="text-white">✓</span>
                    Added to Cart
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-5 h-5" />
                    Add to Cart
                  </>
                )}
              </Button>
              <Button variant="outline" size="lg" asChild className="flex-1">
                <Link href={`/gadgets/${product.slug}`}>
                  <ExternalLink className="w-5 h-5 mr-2" />
                  View Full Details
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </MotionDiv>
  )
}
