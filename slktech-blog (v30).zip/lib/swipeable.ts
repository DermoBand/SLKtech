"use client"

import type React from "react"

import { useState, useRef, useCallback } from "react"

interface SwipeableConfig {
  onSwipeLeft?: () => void
  onSwipeRight?: () => void
  onSwipeUp?: () => void
  onSwipeDown?: () => void
  trackMouse?: boolean
  preventScrollOnSwipe?: boolean
}

interface SwipeableHandlers {
  ref: React.RefObject<HTMLDivElement>
  onTouchStart: (e: React.TouchEvent) => void
  onTouchEnd: (e: React.TouchEvent) => void
  onMouseDown?: (e: React.MouseEvent) => void
}

export function useSwipeable(config: SwipeableConfig): SwipeableHandlers {
  const targetRef = useRef<HTMLDivElement>(null)
  const [touchStart, setTouchStart] = useState({ x: 0, y: 0, time: 0 })

  const minSwipeDistance = 50
  const maxSwipeTime = 300

  const handleTouchStart = useCallback(
    (e: React.TouchEvent) => {
      const touch = e.touches[0]
      setTouchStart({
        x: touch.clientX,
        y: touch.clientY,
        time: Date.now(),
      })

      if (config.preventScrollOnSwipe) {
        e.preventDefault()
      }
    },
    [config.preventScrollOnSwipe],
  )

  const handleTouchEnd = useCallback(
    (e: React.TouchEvent) => {
      const touch = e.changedTouches[0]
      const deltaX = touch.clientX - touchStart.x
      const deltaY = touch.clientY - touchStart.y
      const deltaTime = Date.now() - touchStart.time

      if (deltaTime < maxSwipeTime) {
        if (Math.abs(deltaX) > minSwipeDistance && Math.abs(deltaX) > Math.abs(deltaY)) {
          if (deltaX > 0 && config.onSwipeRight) {
            config.onSwipeRight()
          } else if (deltaX < 0 && config.onSwipeLeft) {
            config.onSwipeLeft()
          }
        } else if (Math.abs(deltaY) > minSwipeDistance && Math.abs(deltaY) > Math.abs(deltaX)) {
          if (deltaY > 0 && config.onSwipeDown) {
            config.onSwipeDown()
          } else if (deltaY < 0 && config.onSwipeUp) {
            config.onSwipeUp()
          }
        }
      }
    },
    [touchStart, config],
  )

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      if (!config.trackMouse) return

      setTouchStart({
        x: e.clientX,
        y: e.clientY,
        time: Date.now(),
      })

      const handleMouseUp = (e: MouseEvent) => {
        const deltaX = e.clientX - touchStart.x
        const deltaY = e.clientY - touchStart.y
        const deltaTime = Date.now() - touchStart.time

        if (deltaTime < maxSwipeTime) {
          if (Math.abs(deltaX) > minSwipeDistance && Math.abs(deltaX) > Math.abs(deltaY)) {
            if (deltaX > 0 && config.onSwipeRight) {
              config.onSwipeRight()
            } else if (deltaX < 0 && config.onSwipeLeft) {
              config.onSwipeLeft()
            }
          } else if (Math.abs(deltaY) > minSwipeDistance && Math.abs(deltaY) > Math.abs(deltaX)) {
            if (deltaY > 0 && config.onSwipeDown) {
              config.onSwipeDown()
            } else if (deltaY < 0 && config.onSwipeUp) {
              config.onSwipeUp()
            }
          }
        }

        document.removeEventListener("mouseup", handleMouseUp)
      }

      document.addEventListener("mouseup", handleMouseUp)
    },
    [touchStart, config],
  )

  return {
    ref: targetRef,
    onTouchStart: handleTouchStart,
    onTouchEnd: handleTouchEnd,
    ...(config.trackMouse ? { onMouseDown: handleMouseDown } : {}),
  }
}
