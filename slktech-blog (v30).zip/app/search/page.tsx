"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import PublicLayout from "@/components/public-layout"
import { MotionDiv } from "@/components/animations/motion-div"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Filter, SlidersHorizontal } from "lucide-react"

// Mock search results data
const allResults = [
  {
    id: "1",
    title: "The Future of Foldable Smartphones: What to Expect in 2025",
    excerpt:
      "Explore the next generation of foldable technology and how it's reshaping the smartphone industry with innovative designs and improved durability.",
    category: "Smartphones",
    image: "/placeholder.svg?height=200&width=300",
    date: "April 5, 2025",
    type: "article",
  },
  {
    id: "2",
    title: "AI-Powered Wearables: The Next Evolution in Health Monitoring",
    excerpt:
      "How artificial intelligence is transforming wearable devices into powerful health companions that can predict and prevent health issues.",
    category: "Wearables",
    image: "/placeholder.svg?height=200&width=300",
    date: "April 3, 2025",
    type: "article",
  },
  {
    id: "3",
    title: "Quantum Computing: Breaking Down the Latest Breakthroughs",
    excerpt:
      "Understanding the recent advancements in quantum computing and what they mean for the future of technology and computational power.",
    category: "Computing",
    image: "/placeholder.svg?height=200&width=300",
    date: "April 1, 2025",
    type: "article",
  },
  {
    id: "4",
    title: "The Best Budget Gaming Laptops of 2025",
    excerpt:
      "Our comprehensive guide to the most powerful and affordable gaming laptops that won't break the bank but still deliver impressive performance.",
    category: "Laptops",
    image: "/placeholder.svg?height=200&width=300",
    date: "March 28, 2025",
    type: "article",
  },
  {
    id: "5",
    title: "Smart Home Gadgets That Actually Improve Your Life",
    excerpt:
      "From intelligent thermostats to AI-powered security systems, these are the smart home devices that provide genuine value and convenience.",
    category: "Smart Home",
    image: "/placeholder.svg?height=200&width=300",
    date: "March 25, 2025",
    type: "article",
  },
  {
    id: "6",
    title: "About SLKtech",
    excerpt: "Learn more about our tech blog and our mission to bring you the latest in technology news and reviews.",
    category: "Pages",
    image: "/placeholder.svg?height=200&width=300",
    date: "January 1, 2025",
    type: "page",
  },
  {
    id: "7",
    title: "Contact Us",
    excerpt: "Get in touch with our team for inquiries, feedback, or collaboration opportunities.",
    category: "Pages",
    image: "/placeholder.svg?height=200&width=300",
    date: "January 1, 2025",
    type: "page",
  },
]

export default function SearchPage() {
  const searchParams = useSearchParams()
  const query = searchParams.get("q") || ""
  const [searchQuery, setSearchQuery] = useState(query)
  const [activeTab, setActiveTab] = useState("all")
  const [results, setResults] = useState<typeof allResults>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    setSearchQuery(query)
    performSearch(query)
  }, [query])

  const performSearch = (searchTerm: string) => {
    setIsLoading(true)

    // Simulate API call delay
    setTimeout(() => {
      if (!searchTerm.trim()) {
        setResults([])
        setIsLoading(false)
        return
      }

      const filtered = allResults.filter(
        (item) =>
          item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.category.toLowerCase().includes(searchTerm.toLowerCase()),
      )
      setResults(filtered)
      setIsLoading(false)
    }, 500)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Update URL with search query
    const url = new URL(window.location.href)
    url.searchParams.set("q", searchQuery)
    window.history.pushState({}, "", url.toString())
    performSearch(searchQuery)
  }

  const getFilteredResults = () => {
    if (activeTab === "all") return results
    return results.filter((result) => result.type === activeTab)
  }

  const filteredResults = getFilteredResults()

  return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-8">
        <MotionDiv animation="fadeInUp" className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Search Results</h1>
          <p className="text-gray-600">
            {query ? (
              <>
                Showing results for <span className="font-medium">"{query}"</span>
              </>
            ) : (
              "Enter a search term to find articles, pages, and more"
            )}
          </p>
        </MotionDiv>

        <div className="mb-8">
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                type="search"
                placeholder="Search for articles, topics, or keywords..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button type="submit">Search</Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2"
            >
              <Filter className="h-4 w-4" />
              <span className="hidden sm:inline">Filters</span>
            </Button>
          </form>
        </div>

        {showFilters && (
          <MotionDiv
            animation="fadeInDown"
            className="mb-8 p-4 border rounded-lg bg-gray-50 flex flex-col sm:flex-row gap-4 items-start"
          >
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4 text-gray-500" />
              <span className="font-medium">Filter Results:</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full">
              <div>
                <label className="text-sm font-medium mb-1 block">Categories</label>
                <select className="w-full rounded-md border border-gray-300 p-2 text-sm">
                  <option value="">All Categories</option>
                  <option value="smartphones">Smartphones</option>
                  <option value="laptops">Laptops</option>
                  <option value="wearables">Wearables</option>
                  <option value="smart-home">Smart Home</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Date Range</label>
                <select className="w-full rounded-md border border-gray-300 p-2 text-sm">
                  <option value="">Any Time</option>
                  <option value="day">Past 24 Hours</option>
                  <option value="week">Past Week</option>
                  <option value="month">Past Month</option>
                  <option value="year">Past Year</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">Sort By</label>
                <select className="w-full rounded-md border border-gray-300 p-2 text-sm">
                  <option value="relevance">Relevance</option>
                  <option value="date-desc">Newest First</option>
                  <option value="date-asc">Oldest First</option>
                  <option value="title-asc">Title (A-Z)</option>
                </select>
              </div>
            </div>
          </MotionDiv>
        )}

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="all">All Results ({results.length})</TabsTrigger>
            <TabsTrigger value="article">Articles ({results.filter((r) => r.type === "article").length})</TabsTrigger>
            <TabsTrigger value="page">Pages ({results.filter((r) => r.type === "page").length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-0">
            {isLoading ? (
              <div className="space-y-6">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="animate-pulse flex gap-4">
                    <div className="bg-gray-200 rounded w-1/4 h-32"></div>
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                      <div className="h-3 bg-gray-200 rounded"></div>
                      <div className="h-3 bg-gray-200 rounded"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredResults.length > 0 ? (
              <div className="space-y-6">
                {filteredResults.map((result) => (
                  <MotionDiv key={result.id} animation="fadeInUp" className="flex flex-col sm:flex-row gap-4">
                    <div className="sm:w-1/4 flex-shrink-0">
                      <Link href={result.type === "article" ? `/article/${result.id}` : `/${result.id}`}>
                        <img
                          src={result.image || "/placeholder.svg"}
                          alt={result.title}
                          className="w-full h-40 sm:h-32 object-cover rounded-lg"
                        />
                      </Link>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-primary hover:bg-primary/90">{result.category}</Badge>
                        <span className="text-xs text-gray-500">{result.date}</span>
                      </div>
                      <Link
                        href={result.type === "article" ? `/article/${result.id}` : `/${result.id}`}
                        className="block group"
                      >
                        <h2 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                          {result.title}
                        </h2>
                      </Link>
                      <p className="text-gray-600 mb-3 line-clamp-2">{result.excerpt}</p>
                      <Link
                        href={result.type === "article" ? `/article/${result.id}` : `/${result.id}`}
                        className="text-primary hover:underline text-sm font-medium"
                      >
                        Read more
                      </Link>
                    </div>
                  </MotionDiv>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Search className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                <h3 className="text-xl font-bold mb-2">No results found</h3>
                <p className="text-gray-600 mb-6">
                  We couldn't find any matches for "{query}". Please try another search term.
                </p>
                <div className="max-w-md mx-auto">
                  <h4 className="font-medium mb-2">Search tips:</h4>
                  <ul className="text-sm text-gray-600 text-left list-disc pl-5 space-y-1">
                    <li>Check your spelling</li>
                    <li>Try more general keywords</li>
                    <li>Try different keywords</li>
                    <li>Try fewer keywords</li>
                  </ul>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="article" className="mt-0">
            {/* Same structure as "all" tab but filtered for articles */}
            {isLoading ? (
              <div className="animate-pulse space-y-6">
                {[1, 2].map((i) => (
                  <div key={i} className="flex gap-4">
                    <div className="bg-gray-200 rounded w-1/4 h-32"></div>
                    <div className="flex-1 space-y-2">
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                      <div className="h-3 bg-gray-200 rounded"></div>
                      <div className="h-3 bg-gray-200 rounded"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredResults.length > 0 ? (
              <div className="space-y-6">
                {filteredResults.map((result) => (
                  <MotionDiv key={result.id} animation="fadeInUp" className="flex flex-col sm:flex-row gap-4">
                    <div className="sm:w-1/4 flex-shrink-0">
                      <Link href={`/article/${result.id}`}>
                        <img
                          src={result.image || "/placeholder.svg"}
                          alt={result.title}
                          className="w-full h-40 sm:h-32 object-cover rounded-lg"
                        />
                      </Link>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-primary hover:bg-primary/90">{result.category}</Badge>
                        <span className="text-xs text-gray-500">{result.date}</span>
                      </div>
                      <Link href={`/article/${result.id}`} className="block group">
                        <h2 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                          {result.title}
                        </h2>
                      </Link>
                      <p className="text-gray-600 mb-3 line-clamp-2">{result.excerpt}</p>
                      <Link href={`/article/${result.id}`} className="text-primary hover:underline text-sm font-medium">
                        Read more
                      </Link>
                    </div>
                  </MotionDiv>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-xl font-bold mb-2">No articles found</h3>
                <p className="text-gray-600">Try adjusting your search terms or browse our categories.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="page" className="mt-0">
            {/* Same structure as "all" tab but filtered for pages */}
            {isLoading ? (
              <div className="animate-pulse space-y-6">
                <div className="flex gap-4">
                  <div className="bg-gray-200 rounded w-1/4 h-32"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                    <div className="h-3 bg-gray-200 rounded"></div>
                  </div>
                </div>
              </div>
            ) : filteredResults.length > 0 ? (
              <div className="space-y-6">
                {filteredResults.map((result) => (
                  <MotionDiv key={result.id} animation="fadeInUp" className="flex flex-col sm:flex-row gap-4">
                    <div className="sm:w-1/4 flex-shrink-0">
                      <Link href={`/${result.id}`}>
                        <img
                          src={result.image || "/placeholder.svg"}
                          alt={result.title}
                          className="w-full h-40 sm:h-32 object-cover rounded-lg"
                        />
                      </Link>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-gray-200 text-gray-800 hover:bg-gray-300">{result.category}</Badge>
                      </div>
                      <Link href={`/${result.id}`} className="block group">
                        <h2 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                          {result.title}
                        </h2>
                      </Link>
                      <p className="text-gray-600 mb-3">{result.excerpt}</p>
                      <Link href={`/${result.id}`} className="text-primary hover:underline text-sm font-medium">
                        Visit page
                      </Link>
                    </div>
                  </MotionDiv>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-xl font-bold mb-2">No pages found</h3>
                <p className="text-gray-600">Try adjusting your search terms.</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </PublicLayout>
  )
}
