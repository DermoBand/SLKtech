"use client"

import { useState } from "react"
import { AdminLayout } from "@/components/admin/admin-layout"
import { MotionDiv } from "@/components/animations/motion-div"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AnimatedButton } from "@/components/ui/button-animations"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { PlusCircle, Trash2, Edit, Save } from "lucide-react"

// Mock categories data
const initialCategories = [
  {
    id: "1",
    name: "Smartphones",
    slug: "smartphones",
    description: "Latest news and reviews about smartphones",
    count: 24,
  },
  {
    id: "2",
    name: "Laptops",
    slug: "laptops",
    description: "Everything about laptops and notebooks",
    count: 18,
  },
  {
    id: "3",
    name: "Wearables",
    slug: "wearables",
    description: "Smartwatches, fitness trackers, and other wearable technology",
    count: 15,
  },
  {
    id: "4",
    name: "Accessories",
    slug: "accessories",
    description: "Tech accessories for all your devices",
    count: 32,
  },
  {
    id: "5",
    name: "Gaming",
    slug: "gaming",
    description: "Gaming hardware, consoles, and peripherals",
    count: 27,
  },
]

export default function CategoriesPage() {
  const [categories, setCategories] = useState(initialCategories)
  const [editingCategory, setEditingCategory] = useState<string | null>(null)
  const [newCategory, setNewCategory] = useState({
    name: "",
    slug: "",
    description: "",
  })
  const [editForm, setEditForm] = useState({
    name: "",
    slug: "",
    description: "",
  })
  const [isAddingNew, setIsAddingNew] = useState(false)

  const handleAddNew = () => {
    setIsAddingNew(true)
    setNewCategory({
      name: "",
      slug: "",
      description: "",
    })
  }

  const handleCancelAdd = () => {
    setIsAddingNew(false)
  }

  const handleSaveNew = () => {
    if (newCategory.name.trim() === "") return

    const newId = (Number.parseInt(categories[categories.length - 1]?.id || "0") + 1).toString()
    setCategories([
      ...categories,
      {
        id: newId,
        name: newCategory.name,
        slug: newCategory.slug || newCategory.name.toLowerCase().replace(/\s+/g, "-"),
        description: newCategory.description,
        count: 0,
      },
    ])
    setIsAddingNew(false)
  }

  const handleEdit = (id: string) => {
    const category = categories.find((cat) => cat.id === id)
    if (category) {
      setEditForm({
        name: category.name,
        slug: category.slug,
        description: category.description,
      })
      setEditingCategory(id)
    }
  }

  const handleCancelEdit = () => {
    setEditingCategory(null)
  }

  const handleSaveEdit = () => {
    if (editForm.name.trim() === "" || !editingCategory) return

    setCategories(
      categories.map((cat) =>
        cat.id === editingCategory
          ? {
              ...cat,
              name: editForm.name,
              slug: editForm.slug || editForm.name.toLowerCase().replace(/\s+/g, "-"),
              description: editForm.description,
            }
          : cat,
      ),
    )
    setEditingCategory(null)
  }

  const handleDelete = (id: string) => {
    setCategories(categories.filter((cat) => cat.id !== id))
  }

  return (
    <AdminLayout>
      <MotionDiv animation="fadeInDown" className="mb-6">
        <h1 className="text-2xl font-bold">Categories</h1>
        <p className="text-gray-600">Manage your article categories.</p>
      </MotionDiv>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>All Categories</CardTitle>
            <AnimatedButton size="sm" onClick={handleAddNew}>
              <PlusCircle className="h-4 w-4 mr-2" />
              Add Category
            </AnimatedButton>
          </div>
          <CardDescription>Organize your content with categories</CardDescription>
        </CardHeader>
        <CardContent>
          {isAddingNew && (
            <div className="mb-6 p-4 border rounded-lg bg-gray-50">
              <h3 className="text-lg font-medium mb-4">Add New Category</h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="new-name">Name</Label>
                  <Input
                    id="new-name"
                    value={newCategory.name}
                    onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                    placeholder="Category name"
                  />
                </div>
                <div>
                  <Label htmlFor="new-slug">Slug</Label>
                  <Input
                    id="new-slug"
                    value={newCategory.slug}
                    onChange={(e) => setNewCategory({ ...newCategory, slug: e.target.value })}
                    placeholder="category-slug"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    The "slug" is the URL-friendly version of the name. It is usually all lowercase and contains only
                    letters, numbers, and hyphens.
                  </p>
                </div>
                <div>
                  <Label htmlFor="new-description">Description</Label>
                  <Textarea
                    id="new-description"
                    value={newCategory.description}
                    onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                    placeholder="Category description (optional)"
                    rows={3}
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={handleCancelAdd}>
                    Cancel
                  </Button>
                  <AnimatedButton onClick={handleSaveNew}>
                    <Save className="h-4 w-4 mr-2" />
                    Save Category
                  </AnimatedButton>
                </div>
              </div>
            </div>
          )}

          <div className="divide-y">
            {categories.map((category) => (
              <div key={category.id} className="py-4">
                {editingCategory === category.id ? (
                  <div className="p-4 border rounded-lg bg-gray-50">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor={`edit-name-${category.id}`}>Name</Label>
                        <Input
                          id={`edit-name-${category.id}`}
                          value={editForm.name}
                          onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-slug-${category.id}`}>Slug</Label>
                        <Input
                          id={`edit-slug-${category.id}`}
                          value={editForm.slug}
                          onChange={(e) => setEditForm({ ...editForm, slug: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-description-${category.id}`}>Description</Label>
                        <Textarea
                          id={`edit-description-${category.id}`}
                          value={editForm.description}
                          onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                          rows={3}
                        />
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={handleCancelEdit}>
                          Cancel
                        </Button>
                        <AnimatedButton onClick={handleSaveEdit}>
                          <Save className="h-4 w-4 mr-2" />
                          Save Changes
                        </AnimatedButton>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                    <div>
                      <h3 className="text-lg font-medium">{category.name}</h3>
                      <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-sm text-gray-500 mt-1">
                        <span>Slug: {category.slug}</span>
                        <span className="hidden sm:inline">•</span>
                        <span>{category.count} articles</span>
                      </div>
                      {category.description && <p className="mt-2 text-gray-600">{category.description}</p>}
                    </div>
                    <div className="flex space-x-2 mt-3 sm:mt-0">
                      <Button variant="outline" size="sm" onClick={() => handleEdit(category.id)}>
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-500 hover:text-red-700"
                        onClick={() => handleDelete(category.id)}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </AdminLayout>
  )
}
