"use client"

import { useState } from "react"
import { AdminLayout } from "@/components/admin/admin-layout"
import { MotionDiv } from "@/components/animations/motion-div"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AnimatedButton } from "@/components/ui/button-animations"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { UploadCloud, Search, Grid, List, Filter, Trash2, Edit, Eye, Download } from "lucide-react"
import { motion } from "framer-motion"

// Mock media data
const mediaItems = [
  {
    id: "1",
    name: "hero-image-1.jpg",
    type: "image",
    size: "1.2 MB",
    dimensions: "1920x1080",
    url: "/placeholder.svg?height=400&width=600",
    uploadedAt: "2 days ago",
  },
  {
    id: "2",
    name: "product-thumbnail.png",
    type: "image",
    size: "850 KB",
    dimensions: "800x600",
    url: "/placeholder.svg?height=400&width=600",
    uploadedAt: "3 days ago",
  },
  {
    id: "3",
    name: "tech-background.jpg",
    type: "image",
    size: "2.4 MB",
    dimensions: "2560x1440",
    url: "/placeholder.svg?height=400&width=600",
    uploadedAt: "1 week ago",
  },
  {
    id: "4",
    name: "gadget-review.mp4",
    type: "video",
    size: "24.8 MB",
    dimensions: "1920x1080",
    url: "/placeholder.svg?height=400&width=600",
    uploadedAt: "2 weeks ago",
  },
  {
    id: "5",
    name: "company-logo.svg",
    type: "image",
    size: "45 KB",
    dimensions: "512x512",
    url: "/placeholder.svg?height=400&width=600",
    uploadedAt: "3 weeks ago",
  },
  {
    id: "6",
    name: "annual-report.pdf",
    type: "document",
    size: "3.5 MB",
    dimensions: "-",
    url: "/placeholder.svg?height=400&width=600",
    uploadedAt: "1 month ago",
  },
]

export default function MediaLibraryPage() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedItems, setSelectedItems] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isUploading, setIsUploading] = useState(false)

  const filteredItems = mediaItems.filter((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()))

  const handleItemSelect = (id: string) => {
    if (selectedItems.includes(id)) {
      setSelectedItems(selectedItems.filter((itemId) => itemId !== id))
    } else {
      setSelectedItems([...selectedItems, id])
    }
  }

  const handleUpload = () => {
    setIsUploading(true)
    // Simulate upload delay
    setTimeout(() => {
      setIsUploading(false)
    }, 2000)
  }

  const handleDeleteSelected = () => {
    // In a real app, this would delete the selected items
    setSelectedItems([])
  }

  return (
    <AdminLayout>
      <MotionDiv animation="fadeInDown" className="mb-6">
        <h1 className="text-2xl font-bold">Media Library</h1>
        <p className="text-gray-600">Manage your images, videos, and documents.</p>
      </MotionDiv>

      <Tabs defaultValue="all">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <TabsList>
            <TabsTrigger value="all">All Media</TabsTrigger>
            <TabsTrigger value="images">Images</TabsTrigger>
            <TabsTrigger value="videos">Videos</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
          </TabsList>

          <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              <Input
                type="search"
                placeholder="Search media..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                className={viewMode === "grid" ? "bg-gray-100" : ""}
                onClick={() => setViewMode("grid")}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className={viewMode === "list" ? "bg-gray-100" : ""}
                onClick={() => setViewMode("list")}
              >
                <List className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex justify-between items-center">
              <CardTitle>Media Files</CardTitle>
              <div className="flex gap-2">
                {selectedItems.length > 0 && (
                  <Button variant="outline" size="sm" onClick={handleDeleteSelected}>
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete Selected
                  </Button>
                )}
                <AnimatedButton size="sm" onClick={handleUpload} disabled={isUploading}>
                  {isUploading ? (
                    <>
                      <div className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <UploadCloud className="h-4 w-4 mr-2" />
                      Upload Files
                    </>
                  )}
                </AnimatedButton>
              </div>
            </div>
            <CardDescription>
              {filteredItems.length} {filteredItems.length === 1 ? "item" : "items"}
              {selectedItems.length > 0 && `, ${selectedItems.length} selected`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {viewMode === "grid" ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredItems.map((item) => (
                  <motion.div
                    key={item.id}
                    whileHover={{ y: -5 }}
                    className={`relative rounded-lg overflow-hidden border ${
                      selectedItems.includes(item.id) ? "ring-2 ring-primary" : ""
                    }`}
                  >
                    <div
                      className="aspect-square bg-gray-100 flex items-center justify-center cursor-pointer"
                      onClick={() => handleItemSelect(item.id)}
                    >
                      {item.type === "image" ? (
                        <img
                          src={item.url || "/placeholder.svg"}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      ) : item.type === "video" ? (
                        <div className="w-full h-full bg-gray-800 flex items-center justify-center text-white">
                          <span>Video</span>
                        </div>
                      ) : (
                        <div className="w-full h-full bg-gray-200 flex items-center justify-center text-gray-500">
                          <span>Document</span>
                        </div>
                      )}
                    </div>
                    <div className="p-3">
                      <h3 className="font-medium text-sm truncate" title={item.name}>
                        {item.name}
                      </h3>
                      <div className="flex justify-between items-center mt-1">
                        <span className="text-xs text-gray-500">{item.size}</span>
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7">
                            <Eye className="h-3.5 w-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7">
                            <Edit className="h-3.5 w-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7">
                            <Download className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="divide-y">
                {filteredItems.map((item) => (
                  <div
                    key={item.id}
                    className={`py-3 flex items-center hover:bg-gray-50 ${
                      selectedItems.includes(item.id) ? "bg-gray-50" : ""
                    }`}
                  >
                    <div className="flex-shrink-0 mr-3">
                      <input
                        type="checkbox"
                        checked={selectedItems.includes(item.id)}
                        onChange={() => handleItemSelect(item.id)}
                        className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      />
                    </div>
                    <div className="flex-shrink-0 w-12 h-12 mr-4 bg-gray-100 rounded overflow-hidden">
                      {item.type === "image" ? (
                        <img
                          src={item.url || "/placeholder.svg"}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      ) : item.type === "video" ? (
                        <div className="w-full h-full bg-gray-800 flex items-center justify-center text-white text-xs">
                          Video
                        </div>
                      ) : (
                        <div className="w-full h-full bg-gray-200 flex items-center justify-center text-gray-500 text-xs">
                          Doc
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.name}</p>
                      <p className="text-xs text-gray-500">
                        {item.size} • {item.dimensions} • {item.uploadedAt}
                      </p>
                    </div>
                    <div className="flex-shrink-0 flex space-x-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between border-t pt-6">
            <div className="text-sm text-gray-500">
              Showing {filteredItems.length} of {mediaItems.length} items
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" disabled>
                Previous
              </Button>
              <Button variant="outline" size="sm" disabled>
                Next
              </Button>
            </div>
          </CardFooter>
        </Card>
      </Tabs>
    </AdminLayout>
  )
}
