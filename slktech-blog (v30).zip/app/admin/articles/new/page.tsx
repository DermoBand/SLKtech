"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { AdminLayout } from "@/components/admin/admin-layout"
import { ArticleEditor } from "@/components/admin/article-editor"

export default function NewArticlePage() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSave = async (data: any, status: "draft" | "published") => {
    setIsSubmitting(true)

    try {
      // In a real app, this would save to a database or API
      console.log("Saving article:", data, "with status:", status)

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Redirect to articles list
      router.push("/admin/articles")
    } catch (error) {
      console.error("Error saving article:", error)
      alert("Failed to save article. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <AdminLayout>
      <ArticleEditor onSave={handleSave} isSubmitting={isSubmitting} />
    </AdminLayout>
  )
}
