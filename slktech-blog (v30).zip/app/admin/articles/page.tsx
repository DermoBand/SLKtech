"use client"

import { useState } from "react"
import Link from "next/link"
import { AdminLayout } from "@/components/admin/admin-layout"
import { MotionDiv } from "@/components/animations/motion-div"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PlusCircle, Search, Edit, Eye, MoreHorizontal, Filter, ArrowUpDown, Calendar, User } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Mock articles data
const articles = [
  {
    id: "1",
    title: "The Future of Foldable Smartphones: What to Expect in 2025",
    status: "published",
    category: "Smartphones",
    author: "John Smith",
    date: "April 5, 2025",
    views: 1245,
    comments: 24,
  },
  {
    id: "2",
    title: "AI-Powered Wearables: The Next Evolution in Health Monitoring",
    status: "published",
    category: "Wearables",
    author: "Sarah Johnson",
    date: "April 3, 2025",
    views: 982,
    comments: 18,
  },
  {
    id: "3",
    title: "Quantum Computing: Breaking Down the Latest Breakthroughs",
    status: "published",
    category: "Computing",
    author: "Michael Chen",
    date: "April 1, 2025",
    views: 1567,
    comments: 32,
  },
  {
    id: "4",
    title: "The Best Budget Gaming Laptops of 2025",
    status: "draft",
    category: "Laptops",
    author: "Emily Wilson",
    date: "March 28, 2025",
    views: 0,
    comments: 0,
  },
  {
    id: "5",
    title: "Smart Home Gadgets That Actually Improve Your Life",
    status: "scheduled",
    category: "Smart Home",
    author: "David Park",
    date: "April 10, 2025",
    views: 0,
    comments: 0,
  },
]

export default function ArticlesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedTab, setSelectedTab] = useState("all")
  const [isDeleting, setIsDeleting] = useState<string | null>(null)

  const filteredArticles = articles.filter((article) => {
    // Filter by search query
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase())

    // Filter by tab
    const matchesTab =
      selectedTab === "all" ||
      (selectedTab === "published" && article.status === "published") ||
      (selectedTab === "drafts" && article.status === "draft") ||
      (selectedTab === "scheduled" && article.status === "scheduled")

    return matchesSearch && matchesTab
  })

  const handleDeleteArticle = (id: string) => {
    setIsDeleting(id)
    // In a real app, this would be an API call
    setTimeout(() => {
      // Here we would remove the article from the database
      setIsDeleting(null)
      // For now, we'll just show an alert
      alert(`Article ${id} deleted successfully!`)
    }, 1000)
  }

  const handleDuplicateArticle = (id: string) => {
    // In a real app, this would be an API call
    alert(`Article ${id} duplicated successfully!`)
  }

  return (
    <AdminLayout>
      <MotionDiv animation="fadeInDown" className="mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Articles</h1>
            <p className="text-gray-600">Manage your blog articles</p>
          </div>
          <Link href="/admin/articles/new" passHref>
            <Button className="gap-2">
              <PlusCircle className="h-4 w-4" />
              New Article
            </Button>
          </Link>
        </div>
      </MotionDiv>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex-1 w-full sm:max-w-sm">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search articles..."
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
              <Button variant="outline" size="sm">
                <ArrowUpDown className="h-4 w-4 mr-2" />
                Sort
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all" value={selectedTab} onValueChange={setSelectedTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Articles</TabsTrigger>
              <TabsTrigger value="published">Published</TabsTrigger>
              <TabsTrigger value="drafts">Drafts</TabsTrigger>
              <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
            </TabsList>

            <div className="rounded-md border">
              <div className="relative w-full overflow-auto">
                <table className="w-full caption-bottom text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="h-12 px-4 text-left font-medium">Title</th>
                      <th className="h-12 px-4 text-left font-medium hidden md:table-cell">Category</th>
                      <th className="h-12 px-4 text-left font-medium hidden lg:table-cell">Author</th>
                      <th className="h-12 px-4 text-left font-medium hidden md:table-cell">Date</th>
                      <th className="h-12 px-4 text-left font-medium hidden lg:table-cell">Views</th>
                      <th className="h-12 px-4 text-left font-medium">Status</th>
                      <th className="h-12 px-4 text-left font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredArticles.length > 0 ? (
                      filteredArticles.map((article) => (
                        <tr key={article.id} className="border-b hover:bg-muted/50 transition-colors">
                          <td className="p-4 align-middle">
                            <div className="font-medium">{article.title}</div>
                          </td>
                          <td className="p-4 align-middle hidden md:table-cell">{article.category}</td>
                          <td className="p-4 align-middle hidden lg:table-cell">
                            <div className="flex items-center gap-2">
                              <User className="h-4 w-4 text-gray-400" />
                              {article.author}
                            </div>
                          </td>
                          <td className="p-4 align-middle hidden md:table-cell">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-gray-400" />
                              {article.date}
                            </div>
                          </td>
                          <td className="p-4 align-middle hidden lg:table-cell">{article.views}</td>
                          <td className="p-4 align-middle">
                            <div
                              className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                                article.status === "published"
                                  ? "bg-green-100 text-green-800"
                                  : article.status === "draft"
                                    ? "bg-yellow-100 text-yellow-800"
                                    : "bg-blue-100 text-blue-800"
                              }`}
                            >
                              {article.status}
                            </div>
                          </td>
                          <td className="p-4 align-middle">
                            <div className="flex items-center gap-2">
                              <Button variant="ghost" size="icon" asChild>
                                <Link href={`/article/${article.id}`}>
                                  <Eye className="h-4 w-4" />
                                </Link>
                              </Button>
                              <Button variant="ghost" size="icon" asChild>
                                <Link href={`/admin/articles/edit/${article.id}`}>
                                  <Edit className="h-4 w-4" />
                                </Link>
                              </Button>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem onClick={() => handleDuplicateArticle(article.id)}>
                                    Duplicate
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>Archive</DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    className="text-red-600"
                                    onClick={() => handleDeleteArticle(article.id)}
                                    disabled={isDeleting === article.id}
                                  >
                                    {isDeleting === article.id ? "Deleting..." : "Delete"}
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={7} className="p-4 text-center text-gray-500">
                          No articles found. Try adjusting your search or filters.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </AdminLayout>
  )
}
