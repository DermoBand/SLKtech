"use client"

import { AdminLayout } from "@/components/admin/admin-layout"
import { ArticleEditor } from "@/components/admin/article-editor"
import { useParams, useRouter } from "next/navigation"

export default function EditArticlePage() {
  const params = useParams()
  const router = useRouter()
  const articleId = params.id as string

  const handleSave = (data: any, status: "draft" | "published") => {
    // In a real app, this would save to a database or API
    console.log("Updating article:", data, "with status:", status)
    router.push("/admin/articles")
  }

  return (
    <AdminLayout>
      <ArticleEditor articleId={articleId} onSave={handleSave} />
    </AdminLayout>
  )
}
