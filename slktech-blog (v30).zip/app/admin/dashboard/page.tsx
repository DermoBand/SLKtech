"use client"
import Link from "next/link"
import { AdminLayout } from "@/components/admin/admin-layout"
import { MotionDiv } from "@/components/animations/motion-div"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AnimatedButton } from "@/components/ui/button-animations"
import { LaunchChecklist } from "@/components/admin/launch-checklist"
import { PlusCircle, Trash2, Edit, Eye, FileText, MessageSquare, Users, TrendingUp, ArrowUp } from "lucide-react"

// Mock data
const recentArticles = [
  { id: "1", title: "The Future of Foldable Smartphones", status: "Published", date: "2 hours ago" },
  { id: "2", title: "AI-Powered Wearables: Health Monitoring", status: "Draft", date: "5 hours ago" },
  { id: "3", title: "Quantum Computing Breakthroughs", status: "Published", date: "1 day ago" },
  { id: "4", title: "Apple's New M3 MacBook Pro Review", status: "Under Review", date: "2 days ago" },
]

const recentComments = [
  {
    id: "1",
    user: "John Doe",
    article: "The Future of Foldable Smartphones",
    comment: "Great insights! I'm looking forward to seeing how these technologies evolve.",
    date: "1 hour ago",
  },
  {
    id: "2",
    user: "Sarah Smith",
    article: "AI-Powered Wearables",
    comment: "I've been using a health monitoring wearable for months now, and it's been life-changing.",
    date: "3 hours ago",
  },
  {
    id: "3",
    user: "Mike Johnson",
    article: "Quantum Computing Breakthroughs",
    comment: "This explanation made quantum computing much more understandable. Thanks!",
    date: "1 day ago",
  },
  {
    id: "4",
    user: "Emily Wilson",
    article: "Apple's New M3 MacBook Pro",
    comment: "I'm considering upgrading. Would you recommend the base model or the higher spec?",
    date: "2 days ago",
  },
]

export default function AdminDashboardPage() {
  return (
    <AdminLayout>
      <MotionDiv animation="fadeInDown" className="mb-8">
        <h1 className="text-2xl font-bold">Welcome back, Vanin</h1>
        <p className="text-gray-600">Here's what's happening with your blog today.</p>
      </MotionDiv>

      {/* Launch Checklist */}
      <MotionDiv animation="fadeInUp" className="mb-8">
        <LaunchChecklist />
      </MotionDiv>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MotionDiv animation="fadeInUp" delay={0.1}>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Articles</p>
                  <h3 className="text-3xl font-bold">124</h3>
                </div>
                <div className="p-3 bg-primary/10 rounded-full">
                  <FileText className="w-6 h-6 text-primary" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-green-600">
                <ArrowUp className="h-4 w-4 mr-1" />
                <span>12% from last month</span>
              </div>
            </CardContent>
          </Card>
        </MotionDiv>

        <MotionDiv animation="fadeInUp" delay={0.2}>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Comments</p>
                  <h3 className="text-3xl font-bold">842</h3>
                </div>
                <div className="p-3 bg-blue-100 rounded-full">
                  <MessageSquare className="w-6 h-6 text-blue-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-green-600">
                <ArrowUp className="h-4 w-4 mr-1" />
                <span>18% from last month</span>
              </div>
            </CardContent>
          </Card>
        </MotionDiv>

        <MotionDiv animation="fadeInUp" delay={0.3}>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Users</p>
                  <h3 className="text-3xl font-bold">3,521</h3>
                </div>
                <div className="p-3 bg-purple-100 rounded-full">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-green-600">
                <ArrowUp className="h-4 w-4 mr-1" />
                <span>7% from last month</span>
              </div>
            </CardContent>
          </Card>
        </MotionDiv>

        <MotionDiv animation="fadeInUp" delay={0.4}>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Page Views</p>
                  <h3 className="text-3xl font-bold">28.3k</h3>
                </div>
                <div className="p-3 bg-green-100 rounded-full">
                  <Eye className="w-6 h-6 text-green-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm text-green-600">
                <ArrowUp className="h-4 w-4 mr-1" />
                <span>24% from last month</span>
              </div>
            </CardContent>
          </Card>
        </MotionDiv>
      </div>

      {/* Traffic Overview */}
      <MotionDiv animation="fadeInUp" delay={0.5} className="mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Traffic Overview</CardTitle>
            <CardDescription>Website traffic over the last 30 days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] flex items-center justify-center">
              <div className="text-center">
                <TrendingUp className="h-16 w-16 mx-auto text-primary/50 mb-4" />
                <p className="text-gray-500">Traffic visualization would appear here</p>
                <p className="text-sm text-gray-400">Showing data from last 30 days</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </MotionDiv>

      {/* Recent Activity */}
      <MotionDiv animation="fadeInUp" delay={0.6}>
        <Tabs defaultValue="articles">
          <div className="flex justify-between items-center mb-6">
            <TabsList>
              <TabsTrigger value="articles">Recent Articles</TabsTrigger>
              <TabsTrigger value="comments">Recent Comments</TabsTrigger>
            </TabsList>

            <AnimatedButton asChild>
              <Link href="/admin/articles/new">
                <PlusCircle className="w-4 h-4 mr-2" />
                New Article
              </Link>
            </AnimatedButton>
          </div>

          <TabsContent value="articles" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Recent Articles</CardTitle>
                <CardDescription>Your most recent articles and their status.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentArticles.map((article) => (
                    <div
                      key={article.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <div>
                        <h4 className="font-medium">{article.title}</h4>
                        <div className="flex items-center mt-1">
                          <span
                            className={`inline-block w-2 h-2 rounded-full mr-2 ${
                              article.status === "Published"
                                ? "bg-green-500"
                                : article.status === "Draft"
                                  ? "bg-yellow-500"
                                  : "bg-blue-500"
                            }`}
                          />
                          <span className="text-sm text-gray-500">{article.status}</span>
                          <span className="text-sm text-gray-400 mx-2">•</span>
                          <span className="text-sm text-gray-500">{article.date}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button className="p-1 text-gray-400 hover:text-gray-600">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-1 text-gray-400 hover:text-blue-600">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="p-1 text-gray-400 hover:text-red-600">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="comments" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Recent Comments</CardTitle>
                <CardDescription>The latest comments from your readers.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentComments.map((comment) => (
                    <div key={comment.id} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex justify-between mb-2">
                        <h4 className="font-medium">{comment.user}</h4>
                        <span className="text-sm text-gray-500">{comment.date}</span>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">"{comment.comment}"</p>
                      <p className="text-xs text-gray-500">On: {comment.article}</p>
                      <div className="flex space-x-2 mt-2">
                        <button className="text-xs text-blue-600 hover:underline">Reply</button>
                        <button className="text-xs text-red-600 hover:underline">Delete</button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </MotionDiv>
    </AdminLayout>
  )
}
