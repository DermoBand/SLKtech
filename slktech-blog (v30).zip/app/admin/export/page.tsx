"use client"

import { AdminLayout } from "@/components/admin/admin-layout"
import { SiteExport } from "@/components/admin/site-export"
import { MotionDiv } from "@/components/animations/motion-div"

export default function ExportPage() {
  return (
    <AdminLayout>
      <MotionDiv animation="fadeInDown" className="mb-8">
        <h1 className="text-2xl font-bold">Export Site</h1>
        <p className="text-gray-600">Export your website for deployment to your hosting provider.</p>
      </MotionDiv>

      <div className="max-w-4xl">
        <SiteExport />
      </div>
    </AdminLayout>
  )
}
