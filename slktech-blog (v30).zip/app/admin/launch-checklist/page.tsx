"use client"

import { useState } from "react"
import Link from "next/link"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ExportSite } from "@/components/admin/export-site"
import { CheckCircle2, Circle, ExternalLink } from "lucide-react"

export default function LaunchChecklistPage() {
  // Content section
  const [contentTasks, setContentTasks] = useState({
    homepage: true,
    about: true,
    contact: true,
    articles: true,
    categories: true,
  })

  // Design section
  const [designTasks, setDesignTasks] = useState({
    logo: true,
    colors: true,
    typography: true,
    responsive: true,
    favicon: true,
  })

  // Technical section
  const [technicalTasks, setTechnicalTasks] = useState({
    performance: true,
    seo: true,
    analytics: true,
    backups: true,
    security: true,
  })

  // Legal section
  const [legalTasks, setLegalTasks] = useState({
    privacy: true,
    terms: true,
    cookies: true,
    gdpr: true,
    accessibility: true,
  })

  // Calculate progress percentages
  const calculateProgress = (tasks: Record<string, boolean>) => {
    const total = Object.keys(tasks).length
    const completed = Object.values(tasks).filter(Boolean).length
    return (completed / total) * 100
  }

  const contentProgress = calculateProgress(contentTasks)
  const designProgress = calculateProgress(designTasks)
  const technicalProgress = calculateProgress(technicalTasks)
  const legalProgress = calculateProgress(legalTasks)
  const totalProgress = (contentProgress + designProgress + technicalProgress + legalProgress) / 4

  // Toggle task completion
  const toggleTask = (section: "contentTasks" | "designTasks" | "technicalTasks" | "legalTasks", task: string) => {
    switch (section) {
      case "contentTasks":
        setContentTasks({ ...contentTasks, [task]: !contentTasks[task as keyof typeof contentTasks] })
        break
      case "designTasks":
        setDesignTasks({ ...designTasks, [task]: !designTasks[task as keyof typeof designTasks] })
        break
      case "technicalTasks":
        setTechnicalTasks({ ...technicalTasks, [task]: !technicalTasks[task as keyof typeof technicalTasks] })
        break
      case "legalTasks":
        setLegalTasks({ ...legalTasks, [task]: !legalTasks[task as keyof typeof legalTasks] })
        break
    }
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">Launch Checklist</h1>
          <p className="text-gray-600">Track your progress toward launching your SLKtech website.</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Overall Progress</CardTitle>
            <CardDescription>Your website is {Math.round(totalProgress)}% ready to launch</CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={totalProgress} className="h-2" />
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
              <div>
                <p className="text-sm font-medium">Content</p>
                <Progress value={contentProgress} className="h-1 mt-1" />
                <p className="text-xs text-gray-500 mt-1">{Math.round(contentProgress)}%</p>
              </div>
              <div>
                <p className="text-sm font-medium">Design</p>
                <Progress value={designProgress} className="h-1 mt-1" />
                <p className="text-xs text-gray-500 mt-1">{Math.round(designProgress)}%</p>
              </div>
              <div>
                <p className="text-sm font-medium">Technical</p>
                <Progress value={technicalProgress} className="h-1 mt-1" />
                <p className="text-xs text-gray-500 mt-1">{Math.round(technicalProgress)}%</p>
              </div>
              <div>
                <p className="text-sm font-medium">Legal</p>
                <Progress value={legalProgress} className="h-1 mt-1" />
                <p className="text-xs text-gray-500 mt-1">{Math.round(legalProgress)}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="content">
          <TabsList className="grid grid-cols-4 mb-4">
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="design">Design</TabsTrigger>
            <TabsTrigger value="technical">Technical</TabsTrigger>
            <TabsTrigger value="legal">Legal</TabsTrigger>
          </TabsList>

          <TabsContent value="content" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Content Checklist</CardTitle>
                <CardDescription>Ensure all your content is ready for launch.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <button
                    onClick={() => toggleTask("contentTasks", "homepage")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {contentTasks.homepage ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Homepage content is complete</span>
                  </button>

                  <button
                    onClick={() => toggleTask("contentTasks", "about")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {contentTasks.about ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>About page content is complete</span>
                  </button>

                  <button
                    onClick={() => toggleTask("contentTasks", "contact")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {contentTasks.contact ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Contact page content is complete</span>
                  </button>

                  <button
                    onClick={() => toggleTask("contentTasks", "articles")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {contentTasks.articles ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Initial articles are published</span>
                  </button>

                  <button
                    onClick={() => toggleTask("contentTasks", "categories")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {contentTasks.categories ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Categories are set up</span>
                  </button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="design" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Design Checklist</CardTitle>
                <CardDescription>Ensure your design is polished and ready.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <button
                    onClick={() => toggleTask("designTasks", "logo")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {designTasks.logo ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Logo is finalized</span>
                  </button>

                  <button
                    onClick={() => toggleTask("designTasks", "colors")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {designTasks.colors ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Color scheme is consistent</span>
                  </button>

                  <button
                    onClick={() => toggleTask("designTasks", "typography")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {designTasks.typography ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Typography is consistent</span>
                  </button>

                  <button
                    onClick={() => toggleTask("designTasks", "responsive")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {designTasks.responsive ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Design is responsive on all devices</span>
                  </button>

                  <button
                    onClick={() => toggleTask("designTasks", "favicon")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {designTasks.favicon ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Favicon is created and implemented</span>
                  </button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="technical" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Technical Checklist</CardTitle>
                <CardDescription>Ensure your site is technically sound.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <button
                    onClick={() => toggleTask("technicalTasks", "performance")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {technicalTasks.performance ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Performance optimization is complete</span>
                  </button>

                  <button
                    onClick={() => toggleTask("technicalTasks", "seo")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {technicalTasks.seo ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>SEO optimization is complete</span>
                  </button>

                  <button
                    onClick={() => toggleTask("technicalTasks", "analytics")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {technicalTasks.analytics ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Analytics is set up</span>
                  </button>

                  <button
                    onClick={() => toggleTask("technicalTasks", "backups")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {technicalTasks.backups ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Backup strategy is in place (manual)</span>
                  </button>

                  <button
                    onClick={() => toggleTask("technicalTasks", "security")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {technicalTasks.security ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Security measures are implemented</span>
                  </button>
                </div>

                <div className="pt-4">
                  <h3 className="text-sm font-medium mb-2">Deployment Resources</h3>
                  <div className="space-y-2">
                    <Button asChild variant="outline" className="w-full justify-start">
                      <Link href="/readme" target="_blank">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View Deployment Guide
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <ExportSite />
          </TabsContent>

          <TabsContent value="legal" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Legal Checklist</CardTitle>
                <CardDescription>Ensure your site meets legal requirements.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <button
                    onClick={() => toggleTask("legalTasks", "privacy")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {legalTasks.privacy ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Privacy policy is published</span>
                  </button>

                  <button
                    onClick={() => toggleTask("legalTasks", "terms")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {legalTasks.terms ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Terms of service is published</span>
                  </button>

                  <button
                    onClick={() => toggleTask("legalTasks", "cookies")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {legalTasks.cookies ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Cookie consent banner is implemented</span>
                  </button>

                  <button
                    onClick={() => toggleTask("legalTasks", "gdpr")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {legalTasks.gdpr ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>GDPR compliance is ensured</span>
                  </button>

                  <button
                    onClick={() => toggleTask("legalTasks", "accessibility")}
                    className="flex items-center space-x-2 w-full text-left p-2 hover:bg-gray-50 rounded-md transition-colors"
                  >
                    {legalTasks.accessibility ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-gray-300" />
                    )}
                    <span>Accessibility standards are met</span>
                  </button>
                </div>

                <div className="pt-4">
                  <h3 className="text-sm font-medium mb-2">Legal Resources</h3>
                  <div className="space-y-2">
                    <Button asChild variant="outline" className="w-full justify-start">
                      <Link href="/privacy" target="_blank">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View Privacy Policy
                      </Link>
                    </Button>
                    <Button asChild variant="outline" className="w-full justify-start">
                      <Link href="/terms" target="_blank">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View Terms of Service
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  )
}
