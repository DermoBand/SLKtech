import PublicLayout from "@/components/public-layout"
import { PageHeader } from "@/components/page-header"
import { NewsGrid } from "@/components/news-grid"

export default function NewsPage() {
  return (
    <PublicLayout>
      <PageHeader
        title="Latest Tech News"
        description="Stay updated with the latest news and developments in the tech world."
      />
      <NewsGrid />
    </PublicLayout>
  )
}
