"use client"

import { useState } from "react"
import PublicLayout from "@/components/public-layout"
import { MotionDiv } from "@/components/animations/motion-div"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { AnimatedButton } from "@/components/ui/button-animations"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { ArticleCard } from "@/components/article-card"
import { Button } from "@/components/ui/button"
import { User, Bell, Shield, LogOut, Bookmark, Save } from "lucide-react"

// Mock saved articles
const savedArticles = [
  {
    id: "1",
    title: "The Future of Foldable Smartphones: What to Expect in 2025",
    excerpt:
      "Explore the next generation of foldable technology and how it's reshaping the smartphone industry with innovative designs and improved durability.",
    category: "Smartphones",
    image: "/placeholder.svg?height=400&width=600",
    author: {
      name: "John Smith",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    date: "April 5, 2025",
    readTime: "5 min read",
    commentCount: 24,
  },
  {
    id: "2",
    title: "AI-Powered Wearables: The Next Evolution in Health Monitoring",
    excerpt:
      "How artificial intelligence is transforming wearable devices into powerful health companions that can predict and prevent health issues.",
    category: "Wearables",
    image: "/placeholder.svg?height=400&width=600",
    author: {
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    date: "April 3, 2025",
    readTime: "4 min read",
    commentCount: 18,
  },
]

export default function ProfilePage() {
  const [profileData, setProfileData] = useState({
    name: "Alex Morgan",
    email: "alex.morgan@example.com",
    bio: "Tech enthusiast and avid reader. Always looking for the latest gadgets and innovations.",
    avatar: "/placeholder.svg?height=100&width=100",
    notifications: {
      email: true,
      articles: true,
      comments: false,
      marketing: false,
    },
    privacy: {
      publicProfile: true,
      showActivity: true,
      allowComments: true,
    },
  })

  const handleProfileChange = (field: string, value: string) => {
    setProfileData({
      ...profileData,
      [field]: value,
    })
  }

  const handleNotificationChange = (field: string, value: boolean) => {
    setProfileData({
      ...profileData,
      notifications: {
        ...profileData.notifications,
        [field]: value,
      },
    })
  }

  const handlePrivacyChange = (field: string, value: boolean) => {
    setProfileData({
      ...profileData,
      privacy: {
        ...profileData.privacy,
        [field]: value,
      },
    })
  }

  const handleSaveProfile = () => {
    // In a real app, this would save to a database or API
    alert("Profile saved successfully!")
  }

  return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-8">
        <MotionDiv animation="fadeInUp" className="mb-8">
          <h1 className="text-3xl font-bold">Your Profile</h1>
          <p className="text-gray-600">Manage your account settings and preferences</p>
        </MotionDiv>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <Avatar className="h-24 w-24 mb-4">
                    <AvatarImage src={profileData.avatar} alt={profileData.name} />
                    <AvatarFallback>{profileData.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <h2 className="text-xl font-bold">{profileData.name}</h2>
                  <p className="text-gray-500 text-sm mb-4">{profileData.email}</p>
                  <p className="text-gray-700 text-sm mb-6">{profileData.bio}</p>
                  <AnimatedButton variant="outline" className="w-full mb-2">
                    Edit Profile
                  </AnimatedButton>
                  <AnimatedButton variant="outline" className="w-full text-red-500 hover:text-red-600">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </AnimatedButton>
                </div>

                <Separator className="my-6" />

                <nav className="space-y-2">
                  <a href="#profile" className="flex items-center p-2 rounded-md hover:bg-gray-100 transition-colors">
                    <User className="h-4 w-4 mr-3 text-gray-500" />
                    <span>Profile Information</span>
                  </a>
                  <a
                    href="#notifications"
                    className="flex items-center p-2 rounded-md hover:bg-gray-100 transition-colors"
                  >
                    <Bell className="h-4 w-4 mr-3 text-gray-500" />
                    <span>Notifications</span>
                  </a>
                  <a href="#privacy" className="flex items-center p-2 rounded-md hover:bg-gray-100 transition-colors">
                    <Shield className="h-4 w-4 mr-3 text-gray-500" />
                    <span>Privacy & Security</span>
                  </a>
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="profile">
              <TabsList className="mb-6">
                <TabsTrigger value="profile">Profile</TabsTrigger>
                <TabsTrigger value="saved">Saved Articles</TabsTrigger>
                <TabsTrigger value="comments">Your Comments</TabsTrigger>
              </TabsList>

              <TabsContent value="profile" className="space-y-6">
                <Card id="profile">
                  <CardHeader>
                    <CardTitle>Profile Information</CardTitle>
                    <CardDescription>Update your personal information</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={profileData.name}
                          onChange={(e) => handleProfileChange("name", e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        <Input
                          id="email"
                          type="email"
                          value={profileData.email}
                          onChange={(e) => handleProfileChange("email", e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        value={profileData.bio}
                        onChange={(e) => handleProfileChange("bio", e.target.value)}
                        rows={4}
                      />
                      <p className="text-xs text-gray-500">
                        Brief description about yourself that will be displayed on your public profile.
                      </p>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="avatar">Profile Picture</Label>
                      <div className="flex items-center gap-4">
                        <Avatar className="h-16 w-16">
                          <AvatarImage src={profileData.avatar} alt={profileData.name} />
                          <AvatarFallback>{profileData.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <AnimatedButton variant="outline" size="sm">
                          Change Picture
                        </AnimatedButton>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <AnimatedButton onClick={handleSaveProfile}>
                      <Save className="h-4 w-4 mr-2" />
                      Save Changes
                    </AnimatedButton>
                  </CardFooter>
                </Card>

                <Card id="notifications">
                  <CardHeader>
                    <CardTitle>Notification Preferences</CardTitle>
                    <CardDescription>Manage how you receive notifications</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="email-notifications">Email Notifications</Label>
                        <p className="text-sm text-gray-500">Receive email notifications</p>
                      </div>
                      <Switch
                        id="email-notifications"
                        checked={profileData.notifications.email}
                        onCheckedChange={(checked) => handleNotificationChange("email", checked)}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="article-notifications">New Articles</Label>
                        <p className="text-sm text-gray-500">Get notified about new articles in your interests</p>
                      </div>
                      <Switch
                        id="article-notifications"
                        checked={profileData.notifications.articles}
                        onCheckedChange={(checked) => handleNotificationChange("articles", checked)}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="comment-notifications">Comment Replies</Label>
                        <p className="text-sm text-gray-500">Get notified when someone replies to your comments</p>
                      </div>
                      <Switch
                        id="comment-notifications"
                        checked={profileData.notifications.comments}
                        onCheckedChange={(checked) => handleNotificationChange("comments", checked)}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="marketing-notifications">Marketing</Label>
                        <p className="text-sm text-gray-500">Receive marketing emails and promotions</p>
                      </div>
                      <Switch
                        id="marketing-notifications"
                        checked={profileData.notifications.marketing}
                        onCheckedChange={(checked) => handleNotificationChange("marketing", checked)}
                      />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <AnimatedButton onClick={handleSaveProfile}>
                      <Save className="h-4 w-4 mr-2" />
                      Save Preferences
                    </AnimatedButton>
                  </CardFooter>
                </Card>

                <Card id="privacy">
                  <CardHeader>
                    <CardTitle>Privacy & Security</CardTitle>
                    <CardDescription>Manage your privacy settings and account security</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="public-profile">Public Profile</Label>
                        <p className="text-sm text-gray-500">Make your profile visible to other users</p>
                      </div>
                      <Switch
                        id="public-profile"
                        checked={profileData.privacy.publicProfile}
                        onCheckedChange={(checked) => handlePrivacyChange("publicProfile", checked)}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="show-activity">Show Activity</Label>
                        <p className="text-sm text-gray-500">Show your comments and likes to other users</p>
                      </div>
                      <Switch
                        id="show-activity"
                        checked={profileData.privacy.showActivity}
                        onCheckedChange={(checked) => handlePrivacyChange("showActivity", checked)}
                      />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label htmlFor="allow-comments">Allow Comments</Label>
                        <p className="text-sm text-gray-500">Allow others to comment on your profile</p>
                      </div>
                      <Switch
                        id="allow-comments"
                        checked={profileData.privacy.allowComments}
                        onCheckedChange={(checked) => handlePrivacyChange("allowComments", checked)}
                      />
                    </div>
                    <Separator />
                    <div className="space-y-2 pt-4">
                      <Label htmlFor="password">Change Password</Label>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Input id="current-password" type="password" placeholder="Current Password" />
                        <Input id="new-password" type="password" placeholder="New Password" />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Password must be at least 8 characters and include a number and special character.
                      </p>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <AnimatedButton onClick={handleSaveProfile}>
                      <Save className="h-4 w-4 mr-2" />
                      Save Security Settings
                    </AnimatedButton>
                  </CardFooter>
                </Card>
              </TabsContent>

              <TabsContent value="saved" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Saved Articles</CardTitle>
                    <CardDescription>Articles you've bookmarked for later</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {savedArticles.map((article, index) => (
                        <ArticleCard key={article.id} {...article} index={index} />
                      ))}
                    </div>
                    {savedArticles.length === 0 && (
                      <div className="text-center py-12">
                        <Bookmark className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                        <h3 className="text-xl font-bold mb-2">No saved articles</h3>
                        <p className="text-gray-600 mb-6">
                          You haven't saved any articles yet. Browse our articles and click the bookmark icon to save
                          them for later.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="comments" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Your Comments</CardTitle>
                    <CardDescription>Comments you've made on articles</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="p-4 border rounded-lg">
                        <div className="flex justify-between mb-2">
                          <h4 className="font-medium">The Future of Foldable Smartphones</h4>
                          <span className="text-sm text-gray-500">2 days ago</span>
                        </div>
                        <p className="text-gray-700 mb-3">
                          I've been using a foldable phone for about 6 months now, and while I love the concept,
                          durability is definitely still an issue. Looking forward to the improvements mentioned here!
                        </p>
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-gray-500">12 likes</span>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="sm" className="text-xs">
                              Edit
                            </Button>
                            <Button variant="ghost" size="sm" className="text-xs text-red-500">
                              Delete
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div className="p-4 border rounded-lg">
                        <div className="flex justify-between mb-2">
                          <h4 className="font-medium">AI-Powered Wearables: The Next Evolution</h4>
                          <span className="text-sm text-gray-500">1 week ago</span>
                        </div>
                        <p className="text-gray-700 mb-3">
                          Great article! I'm particularly interested in how these AI wearables handle privacy concerns.
                          Would love to see a follow-up piece on data security in health wearables.
                        </p>
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-gray-500">8 likes</span>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="sm" className="text-xs">
                              Edit
                            </Button>
                            <Button variant="ghost" size="sm" className="text-xs text-red-500">
                              Delete
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </PublicLayout>
  )
}
