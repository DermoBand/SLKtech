import PublicLayout from "@/components/public-layout"
import { PageHeader } from "@/components/page-header"
import { Card, CardContent } from "@/components/ui/card"
import { MotionDiv } from "@/components/animations/motion-div"

export default function PrivacyPage() {
  return (
    <PublicLayout>
      <PageHeader title="Privacy Policy" description="Learn how we collect, use, and protect your information" />

      <div className="container mx-auto px-4 py-8">
        <MotionDiv animation="fadeInUp" className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-6 prose prose-gray max-w-none">
              <h2>Privacy Policy</h2>

              <p>Last updated: April 10, 2023</p>

              <p>
                This Privacy Policy describes how SLKtech ("we", "us", or "our") collects, uses, and discloses your
                personal information when you visit our website at slktech.com (the "Site").
              </p>

              <h3>Information We Collect</h3>

              <p>
                We collect minimal information at this time. When you visit the Site, we may collect basic analytics
                data such as your IP address and pages visited to help us improve our service.
              </p>

              <h3>How We Use Your Information</h3>

              <p>We use the limited information that we collect to:</p>

              <ul>
                <li>Provide and maintain our website</li>
                <li>Improve our website based on usage patterns</li>
                <li>Understand how visitors use our website</li>
              </ul>

              <h3>Cookies</h3>

              <p>
                We use essential cookies to ensure the basic functionality of our website. You can disable cookies in
                your browser settings if you prefer.
              </p>

              <h3>Changes to This Privacy Policy</h3>

              <p>
                We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new
                Privacy Policy on this page and updating the "Last updated" date.
              </p>

              <h3>Contact Us</h3>

              <p>If you have any questions about this Privacy Policy, please contact us at privacy@slktech.com.</p>
            </CardContent>
          </Card>
        </MotionDiv>
      </div>
    </PublicLayout>
  )
}
