import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { AdScript } from "@/components/ad-script"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "SLKtech - Latest Tech Gadgets & News",
  description: "Your source for the latest tech gadgets, devices, and news",
  keywords: "tech, gadgets, smartphones, laptops, wearables, reviews, technology news",
  authors: [{ name: "SLKtech Team" }],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://slktech.com",
    title: "SLKtech - Latest Tech Gadgets & News",
    description: "Your source for the latest tech gadgets, devices, and news",
    siteName: "SLKtech",
  },
  twitter: {
    card: "summary_large_image",
    title: "SLKtech - Latest Tech Gadgets & News",
    description: "Your source for the latest tech gadgets, devices, and news",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body className={`${inter.className} antialiased overflow-x-hidden`}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} disableTransitionOnChange>
          {children}
        </ThemeProvider>
        <AdScript />
      </body>
    </html>
  )
}


import './globals.css'