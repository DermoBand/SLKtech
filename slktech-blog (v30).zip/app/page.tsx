import PublicLayout from "@/components/public-layout"
import { Hero } from "@/components/hero"
import { FeaturedArticles } from "@/components/featured-articles"
import { LatestNews } from "@/components/latest-news"
import { TrendingGadgets } from "@/components/trending-gadgets"
import { Newsletter } from "@/components/newsletter"

export default function HomePage() {
  return (
    <PublicLayout>
      <Hero />
      <FeaturedArticles />
      <LatestNews />
      <TrendingGadgets />
      <Newsletter />
    </PublicLayout>
  )
}
