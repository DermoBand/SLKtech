import PublicLayout from "@/components/public-layout"
import { PageHeader } from "@/components/page-header"
import { Card, CardContent } from "@/components/ui/card"
import { MotionDiv } from "@/components/animations/motion-div"

export default function ReadmePage() {
  return (
    <PublicLayout>
      <PageHeader title="Deployment Guide" description="How to deploy SLKtech to your hosting provider" />

      <div className="container mx-auto px-4 py-8">
        <MotionDiv animation="fadeInUp" className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-6 prose prose-gray max-w-none">
              <h2>SLKtech Deployment Guide</h2>

              <p>
                This guide will help you deploy the SLKtech website to your preferred hosting provider. Follow these
                steps to get your site up and running quickly.
              </p>

              <h3>Prerequisites</h3>

              <ul>
                <li>Node.js 18.x or higher</li>
                <li>npm or yarn package manager</li>
                <li>Git (optional, but recommended)</li>
                <li>A hosting provider account (Vercel, Netlify, etc.)</li>
              </ul>

              <h3>Option 1: Deploy to Vercel (Recommended)</h3>

              <ol>
                <li>
                  <p>Export your site from the admin dashboard</p>
                  <p className="text-sm text-gray-600">
                    Go to Admin &gt; Launch Checklist and click "Export Site" to download your site files.
                  </p>
                </li>
                <li>
                  <p>Create a new repository on GitHub</p>
                  <p className="text-sm text-gray-600">Upload your exported files to a new GitHub repository.</p>
                </li>
                <li>
                  <p>Connect your GitHub repository to Vercel</p>
                  <p className="text-sm text-gray-600">
                    Sign in to Vercel, click "Add New Project", and select your GitHub repository.
                  </p>
                </li>
                <li>
                  <p>Configure your project settings</p>
                  <p className="text-sm text-gray-600">
                    Use the default settings provided by Vercel for Next.js projects.
                  </p>
                </li>
                <li>
                  <p>Deploy your site</p>
                  <p className="text-sm text-gray-600">Click "Deploy" and wait for the deployment to complete.</p>
                </li>
              </ol>

              <h3>Option 2: Manual Deployment</h3>

              <ol>
                <li>
                  <p>Export your site from the admin dashboard</p>
                  <p className="text-sm text-gray-600">
                    Go to Admin &gt; Launch Checklist and click "Export Site" to download your site files.
                  </p>
                </li>
                <li>
                  <p>Extract the downloaded ZIP file</p>
                </li>
                <li>
                  <p>Install dependencies</p>
                  <pre>
                    <code>npm install</code>
                  </pre>
                </li>
                <li>
                  <p>Build the project</p>
                  <pre>
                    <code>npm run build</code>
                  </pre>
                </li>
                <li>
                  <p>Start the server</p>
                  <pre>
                    <code>npm start</code>
                  </pre>
                </li>
              </ol>

              <h3>Custom Domain Setup</h3>

              <p>
                After deploying your site, you may want to set up a custom domain. Most hosting providers offer
                straightforward ways to connect your domain:
              </p>

              <ol>
                <li>
                  <p>Purchase a domain from a domain registrar (e.g., Namecheap, GoDaddy)</p>
                </li>
                <li>
                  <p>Add the domain to your hosting provider's dashboard</p>
                </li>
                <li>
                  <p>Configure DNS settings as instructed by your hosting provider</p>
                </li>
                <li>
                  <p>Wait for DNS propagation (can take up to 48 hours)</p>
                </li>
              </ol>

              <h3>Need Help?</h3>

              <p>
                If you encounter any issues during deployment, please contact our support team at support@slktech.com.
              </p>
            </CardContent>
          </Card>
        </MotionDiv>
      </div>
    </PublicLayout>
  )
}
