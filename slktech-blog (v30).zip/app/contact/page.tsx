import PublicLayout from "@/components/public-layout"
import { PageHeader } from "@/components/page-header"
import { ContactForm } from "@/components/contact-form"

export default function ContactPage() {
  return (
    <PublicLayout>
      <PageHeader
        title="Contact Us"
        description="Get in touch with our team for inquiries, feedback, or collaboration opportunities."
      />
      <ContactForm />
    </PublicLayout>
  )
}
