"use client"

import PublicLayout from "@/components/public-layout"
import { MotionDiv } from "@/components/animations/motion-div"
import { MotionImage } from "@/components/animations/motion-image"
import { Badge } from "@/components/ui/badge"
import { ProductShowcase } from "@/components/product-showcase"
import { Calendar, Clock, MessageSquare } from "lucide-react"

// Sample product data
const sonyHeadphones = {
  id: "sony-wh-1000xm5",
  slug: "sony-wh-1000xm5",
  title: "Sony WH-1000XM5",
  description: "Premium noise-cancelling headphones with exceptional sound quality.",
  price: 349.99,
  oldPrice: 399.99,
  rating: 4.8,
  reviewCount: 1245,
  image: "/placeholder.svg?height=600&width=600",
  category: "Headphones",
  brand: "Sony",
  inStock: true,
  isNew: true,
}

export default function ProductReviewArticle() {
  return (
    <PublicLayout>
      {/* Hero Section */}
      <div className="relative h-[50vh] md:h-[60vh] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/10 z-10" />
        <MotionImage
          src="/placeholder.svg?height=1200&width=1600"
          alt="Sony WH-1000XM5 Review"
          fill
          className="object-cover"
          priority
          animation="fadeIn"
        />

        <div className="relative z-20 h-full flex items-end">
          <div className="container mx-auto px-4 pb-8 md:pb-16">
            <MotionDiv animation="fadeInUp" className="max-w-4xl">
              <Badge className="mb-4 bg-primary hover:bg-primary/90">Product Review</Badge>
              <h1 className="text-2xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
                Sony WH-1000XM5 Review: The Best Noise-Cancelling Headphones of 2023
              </h1>
              <div className="flex flex-wrap items-center text-gray-200 gap-4">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  April 15, 2023
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2" />8 min read
                </div>
                <div className="flex items-center">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  24 Comments
                </div>
              </div>
            </MotionDiv>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <MotionDiv animation="fadeInUp" className="prose max-w-none">
            <p className="lead">
              Sony has long been a leader in the noise-cancelling headphone market, and with the WH-1000XM5, they've
              raised the bar yet again. These premium headphones offer exceptional sound quality, industry-leading noise
              cancellation, and a comfortable design that makes them perfect for long listening sessions.
            </p>

            <h2>Design and Comfort</h2>
            <p>
              The WH-1000XM5 features a sleek, minimalist design that's a departure from its predecessors. The headband
              is thinner and the ear cups are slightly larger, providing better comfort for extended wear. The synthetic
              leather ear pads are soft and plush, creating an excellent seal around your ears without applying too much
              pressure.
            </p>
            <p>
              At 250 grams, these headphones are lightweight enough to wear all day, and the improved weight
              distribution means you'll barely notice them after a few minutes. The build quality is excellent, with
              premium materials that feel durable and well-constructed.
            </p>

            {/* Embedded Product Showcase */}
            <ProductShowcase product={sonyHeadphones} />

            <h2>Sound Quality</h2>
            <p>
              Sony has equipped the WH-1000XM5 with new 30mm drivers that deliver exceptional audio performance. The
              sound signature is well-balanced, with clear highs, detailed mids, and punchy bass that doesn't overwhelm.
              Whether you're listening to classical music, jazz, rock, or hip-hop, these headphones handle every genre
              with finesse.
            </p>
            <p>
              The soundstage is impressively wide for closed-back headphones, giving you a sense of space and separation
              between instruments. Detail retrieval is excellent, allowing you to hear subtle nuances in your favorite
              tracks that you might have missed with lesser headphones.
            </p>

            <h2>Noise Cancellation</h2>
            <p>
              This is where the WH-1000XM5 truly shines. Sony has implemented a new 8-microphone system with two
              processors that deliver the best noise cancellation we've ever tested. Low-frequency rumbles like airplane
              engines and bus noise are almost completely eliminated, while mid-range sounds like voices and keyboard
              clicks are significantly reduced.
            </p>
            <p>
              The adaptive noise cancellation automatically adjusts based on your environment, and you can customize the
              level of noise cancellation through Sony's Headphones Connect app. There's also an excellent ambient sound
              mode that lets you hear your surroundings when needed.
            </p>

            <h2>Battery Life and Connectivity</h2>
            <p>
              The WH-1000XM5 offers up to 30 hours of battery life with noise cancellation enabled, which is impressive
              for headphones in this class. A quick 3-minute charge provides up to 3 hours of playback, making these
              headphones perfect for travelers who need to top up quickly between flights.
            </p>
            <p>
              Bluetooth 5.2 connectivity ensures a stable connection, and the headphones support multiple codecs
              including SBC, AAC, and LDAC for high-resolution audio. Multipoint connectivity allows you to connect to
              two devices simultaneously, making it easy to switch between your phone and laptop.
            </p>

            <h2>Features and Controls</h2>
            <p>
              Sony has implemented a mix of touch controls and physical buttons on the WH-1000XM5. The right ear cup
              features touch-sensitive controls for playback, volume, and calls, while physical buttons handle power and
              noise cancellation modes. The controls are intuitive and responsive, though they can be a bit finicky in
              cold weather.
            </p>
            <p>
              The Headphones Connect app offers extensive customization options, including a 5-band equalizer, 360
              Reality Audio setup, and DSEE Extreme upscaling for compressed audio. You can also customize the function
              of the Custom button and set up location-based noise cancellation profiles.
            </p>

            <h2>Verdict</h2>
            <p>
              The Sony WH-1000XM5 are the best noise-cancelling headphones you can buy in 2023. They offer exceptional
              sound quality, unmatched noise cancellation, comfortable design, and impressive battery life. While they
              come with a premium price tag, they justify it with their performance and features.
            </p>
            <p>
              If you're a frequent traveler, work in noisy environments, or simply appreciate high-quality audio, the
              WH-1000XM5 are an excellent investment that will enhance your listening experience for years to come.
            </p>

            <div className="not-prose mt-8 bg-gray-100 p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Sony WH-1000XM5: Pros and Cons</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold text-green-600 mb-2">Pros</h4>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <span className="text-green-600 mr-2">✓</span> Industry-leading noise cancellation
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-600 mr-2">✓</span> Excellent sound quality with balanced profile
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-600 mr-2">✓</span> Comfortable for extended wear
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-600 mr-2">✓</span> Impressive 30-hour battery life
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-600 mr-2">✓</span> Useful multipoint connectivity
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold text-red-600 mb-2">Cons</h4>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <span className="text-red-600 mr-2">✗</span> Premium price point
                    </li>
                    <li className="flex items-start">
                      <span className="text-red-600 mr-2">✗</span> No aptX codec support
                    </li>
                    <li className="flex items-start">
                      <span className="text-red-600 mr-2">✗</span> Touch controls can be finicky in cold weather
                    </li>
                    <li className="flex items-start">
                      <span className="text-red-600 mr-2">✗</span> Larger case than previous model
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="not-prose mt-8">
              <h3 className="text-xl font-bold mb-4">Final Rating</h3>
              <div className="flex items-center">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <svg
                      key={i}
                      className={`w-8 h-8 ${i < 5 ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                    </svg>
                  ))}
                </div>
                <span className="ml-2 text-xl font-bold">5.0/5.0</span>
              </div>
              <p className="mt-2 text-lg">
                <strong>Verdict:</strong> Highly Recommended
              </p>
            </div>
          </MotionDiv>
        </div>
      </div>
    </PublicLayout>
  )
}
