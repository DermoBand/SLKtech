import PublicLayout from "@/components/public-layout"
import { PageHeader } from "@/components/page-header"
import { Card, CardContent } from "@/components/ui/card"
import { MotionDiv } from "@/components/animations/motion-div"

export default function TermsPage() {
  return (
    <PublicLayout>
      <PageHeader title="Terms of Service" description="Please read these terms carefully before using our website" />

      <div className="container mx-auto px-4 py-8">
        <MotionDiv animation="fadeInUp" className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="p-6 prose prose-gray max-w-none">
              <h2>Terms of Service</h2>

              <p>Last updated: April 10, 2023</p>

              <p>
                Please read these Terms of Service ("Terms") carefully before using the slktech.com website operated by
                SLKtech ("us", "we", or "our").
              </p>

              <p>
                Your access to and use of the Service is conditioned on your acceptance of and compliance with these
                Terms. These Terms apply to all visitors, users, and others who access or use the Service.
              </p>

              <h3>Content</h3>

              <p>
                Our Service provides technology news, reviews, and information. All content on this site is for
                informational purposes only.
              </p>

              <h3>Links To Other Web Sites</h3>

              <p>
                Our Service may contain links to third-party websites or services that are not owned or controlled by
                SLKtech. We have no control over, and assume no responsibility for, the content, privacy policies, or
                practices of any third-party websites or services.
              </p>

              <h3>Changes</h3>

              <p>We reserve the right to modify or replace these Terms at any time at our sole discretion.</p>

              <h3>Contact Us</h3>

              <p>If you have any questions about these Terms, please contact us at terms@slktech.com.</p>
            </CardContent>
          </Card>
        </MotionDiv>
      </div>
    </PublicLayout>
  )
}
