"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import PublicLayout from "@/components/public-layout"
import { MotionDiv } from "@/components/animations/motion-div"
import { ArticleCard } from "@/components/article-card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowRight, Filter } from "lucide-react"

// Mock categories data
const categories = [
  {
    slug: "smartphones",
    name: "Smartphones",
    description: "The latest news and reviews about smartphones and mobile technology.",
    image: "/placeholder.svg?height=400&width=1200",
  },
  {
    slug: "laptops",
    name: "Laptops",
    description: "Everything about laptops, notebooks, and portable computing devices.",
    image: "/placeholder.svg?height=400&width=1200",
  },
  {
    slug: "wearables",
    name: "Wearables",
    description: "Smartwatches, fitness trackers, and other wearable technology.",
    image: "/placeholder.svg?height=400&width=1200",
  },
  {
    slug: "accessories",
    name: "Accessories",
    description: "Tech accessories for all your devices, from cases to chargers.",
    image: "/placeholder.svg?height=400&width=1200",
  },
]

// Mock articles data
const allArticles = [
  {
    id: "1",
    title: "The Future of Foldable Smartphones: What to Expect in 2025",
    excerpt:
      "Explore the next generation of foldable technology and how it's reshaping the smartphone industry with innovative designs and improved durability.",
    category: "smartphones",
    image: "/placeholder.svg?height=400&width=600",
    author: {
      name: "John Smith",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    date: "April 5, 2025",
    readTime: "5 min read",
    commentCount: 24,
    featured: true,
  },
  {
    id: "2",
    title: "AI-Powered Wearables: The Next Evolution in Health Monitoring",
    excerpt:
      "How artificial intelligence is transforming wearable devices into powerful health companions that can predict and prevent health issues.",
    category: "wearables",
    image: "/placeholder.svg?height=400&width=600",
    author: {
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    date: "April 3, 2025",
    readTime: "4 min read",
    commentCount: 18,
  },
  {
    id: "3",
    title: "Quantum Computing: Breaking Down the Latest Breakthroughs",
    excerpt:
      "Understanding the recent advancements in quantum computing and what they mean for the future of technology and computational power.",
    category: "computing",
    image: "/placeholder.svg?height=400&width=600",
    author: {
      name: "Michael Chen",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    date: "April 1, 2025",
    readTime: "7 min read",
    commentCount: 32,
  },
  {
    id: "4",
    title: "The Best Budget Gaming Laptops of 2025",
    excerpt:
      "Our comprehensive guide to the most powerful and affordable gaming laptops that won't break the bank but still deliver impressive performance.",
    category: "laptops",
    image: "/placeholder.svg?height=400&width=600",
    author: {
      name: "Emily Wilson",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    date: "March 28, 2025",
    readTime: "6 min read",
    commentCount: 15,
  },
  {
    id: "5",
    title: "Smart Home Gadgets That Actually Improve Your Life",
    excerpt:
      "From intelligent thermostats to AI-powered security systems, these are the smart home devices that provide genuine value and convenience.",
    category: "smart-home",
    image: "/placeholder.svg?height=400&width=600",
    author: {
      name: "David Park",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    date: "March 25, 2025",
    readTime: "5 min read",
    commentCount: 27,
  },
  {
    id: "6",
    title: "iPhone 16 Pro: Everything We Know So Far",
    excerpt:
      "A comprehensive look at all the rumors, leaks, and confirmed features of Apple's upcoming flagship smartphone.",
    category: "smartphones",
    image: "/placeholder.svg?height=400&width=600",
    author: {
      name: "Lisa Chen",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    date: "March 22, 2025",
    readTime: "8 min read",
    commentCount: 42,
  },
  {
    id: "7",
    title: "The Rise of Ultra-Portable Laptops: Power in a Small Package",
    excerpt:
      "How manufacturers are packing more power into increasingly smaller laptops without sacrificing performance or battery life.",
    category: "laptops",
    image: "/placeholder.svg?height=400&width=600",
    author: {
      name: "Robert Johnson",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    date: "March 20, 2025",
    readTime: "5 min read",
    commentCount: 19,
  },
  {
    id: "8",
    title: "Fitness Trackers vs. Smartwatches: Which Is Right for You?",
    excerpt:
      "A detailed comparison of fitness trackers and smartwatches to help you decide which wearable technology best suits your needs and lifestyle.",
    category: "wearables",
    image: "/placeholder.svg?height=400&width=600",
    author: {
      name: "Jennifer Lee",
      avatar: "/placeholder.svg?height=50&width=50",
    },
    date: "March 18, 2025",
    readTime: "6 min read",
    commentCount: 23,
  },
]

export default function CategoryPage() {
  const params = useParams()
  const slug = params.slug as string
  const [category, setCategory] = useState<(typeof categories)[0] | null>(null)
  const [articles, setArticles] = useState<typeof allArticles>([])
  const [isLoading, setIsLoading] = useState(true)
  const [sortBy, setSortBy] = useState("newest")
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => {
    // Simulate API fetch
    setIsLoading(true)
    setTimeout(() => {
      const foundCategory = categories.find((c) => c.slug === slug)
      if (foundCategory) {
        setCategory(foundCategory)
        setArticles(allArticles.filter((a) => a.category === slug))
      }
      setIsLoading(false)
    }, 500)
  }, [slug])

  const sortArticles = (articles: typeof allArticles) => {
    switch (sortBy) {
      case "newest":
        return [...articles].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      case "oldest":
        return [...articles].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      case "popular":
        return [...articles].sort((a, b) => b.commentCount - a.commentCount)
      default:
        return articles
    }
  }

  const sortedArticles = sortArticles(articles)

  if (isLoading) {
    return (
      <div className="flex flex-col min-h-screen">
        <main className="flex-1 pt-14">
          <div className="animate-pulse">
            <div className="h-64 bg-gray-200"></div>
            <div className="container mx-auto px-4 py-8">
              <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-8"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="h-80 bg-gray-200 rounded"></div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    )
  }

  if (!category) {
    return (
      <PublicLayout>
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold mb-4">Category Not Found</h1>
          <p className="mb-8">The category you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link href="/">Return to Home</Link>
          </Button>
        </div>
      </PublicLayout>
    )
  }

  return (
    <PublicLayout>
      {/* Category Hero */}
      <div className="relative h-64 md:h-80 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/10 z-10" />
        <img src={category.image || "/placeholder.svg"} alt={category.name} className="w-full h-full object-cover" />

        <div className="relative z-20 h-full flex items-end">
          <div className="container mx-auto px-4 pb-8 md:pb-16">
            <MotionDiv animation="fadeInUp" className="max-w-3xl">
              <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">{category.name}</h1>
              <p className="text-gray-200 text-lg">{category.description}</p>
            </MotionDiv>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filters and Sorting */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
          <h2 className="text-2xl font-bold">
            {articles.length} {articles.length === 1 ? "Article" : "Articles"}
          </h2>

          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2"
            >
              <Filter className="h-4 w-4" />
              Filters
            </Button>

            <div className="w-full sm:w-auto">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="popular">Most Popular</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <MotionDiv
            animation="fadeInDown"
            className="mb-8 p-4 border rounded-lg bg-gray-50 grid grid-cols-1 sm:grid-cols-3 gap-4"
          >
            <div>
              <label className="text-sm font-medium mb-1 block">Author</label>
              <select className="w-full rounded-md border border-gray-300 p-2 text-sm">
                <option value="">All Authors</option>
                <option value="john-smith">John Smith</option>
                <option value="sarah-johnson">Sarah Johnson</option>
                <option value="michael-chen">Michael Chen</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Date Range</label>
              <select className="w-full rounded-md border border-gray-300 p-2 text-sm">
                <option value="">Any Time</option>
                <option value="day">Past 24 Hours</option>
                <option value="week">Past Week</option>
                <option value="month">Past Month</option>
                <option value="year">Past Year</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">Tags</label>
              <select className="w-full rounded-md border border-gray-300 p-2 text-sm">
                <option value="">All Tags</option>
                <option value="reviews">Reviews</option>
                <option value="guides">Guides</option>
                <option value="news">News</option>
              </select>
            </div>
          </MotionDiv>
        )}

        {/* Articles Grid */}
        {sortedArticles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {sortedArticles.map((article, index) => (
              <ArticleCard key={article.id} {...article} index={index} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <h3 className="text-xl font-bold mb-2">No articles found</h3>
            <p className="text-gray-600 mb-6">There are no articles in this category yet.</p>
            <Button asChild>
              <Link href="/">Browse Other Categories</Link>
            </Button>
          </div>
        )}

        {/* Load More */}
        {sortedArticles.length > 0 && (
          <MotionDiv animation="fadeInUp" className="flex justify-center mt-12">
            <Button className="flex items-center gap-2">
              Load More
              <ArrowRight className="h-4 w-4" />
            </Button>
          </MotionDiv>
        )}
      </div>
    </PublicLayout>
  )
}
