import Link from "next/link"
import { Button } from "@/components/ui/button"
import { MotionDiv } from "@/components/animations/motion-div"
import { Home } from "lucide-react"

export default function NotFound() {
  return (
    <div className="container mx-auto px-4 py-16 flex flex-col items-center justify-center min-h-[70vh] text-center">
      <MotionDiv animation="fadeInDown" className="mb-6">
        <h1 className="text-9xl font-bold gradient-text">404</h1>
      </MotionDiv>

      <MotionDiv animation="fadeInUp" delay={0.2} className="max-w-md space-y-4">
        <h2 className="text-2xl font-bold">Page Not Found</h2>
        <p className="text-gray-600">
          The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
        </p>

        <Button asChild className="mt-4">
          <Link href="/">
            <Home className="mr-2 h-4 w-4" />
            Back to Home
          </Link>
        </Button>
      </MotionDiv>
    </div>
  )
}
