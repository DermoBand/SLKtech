"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import PublicLayout from "@/components/public-layout"
import { MotionDiv } from "@/components/animations/motion-div"
import { MotionImage } from "@/components/animations/motion-image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, ArrowRight } from "lucide-react"

// Mock categories
const categories = [
  {
    id: "smartphones",
    name: "Smartphones",
    description: "Latest mobile devices with cutting-edge technology",
    image: "/placeholder.svg?height=400&width=400",
    count: 24,
  },
  {
    id: "laptops",
    name: "Laptops",
    description: "Powerful computers for work and play",
    image: "/placeholder.svg?height=400&width=400",
    count: 18,
  },
  {
    id: "headphones",
    name: "Headphones",
    description: "Immersive audio experiences for every situation",
    image: "/placeholder.svg?height=400&width=400",
    count: 12,
  },
  {
    id: "wearables",
    name: "Wearables",
    description: "Smart devices that track and enhance your lifestyle",
    image: "/placeholder.svg?height=400&width=400",
    count: 15,
  },
  {
    id: "cameras",
    name: "Cameras",
    description: "Capture moments with exceptional clarity",
    image: "/placeholder.svg?height=400&width=400",
    count: 9,
  },
  {
    id: "drones",
    name: "Drones",
    description: "Aerial photography and videography made easy",
    image: "/placeholder.svg?height=400&width=400",
    count: 6,
  },
  {
    id: "gaming",
    name: "Gaming",
    description: "Next-level gaming experiences and accessories",
    image: "/placeholder.svg?height=400&width=400",
    count: 21,
  },
  {
    id: "audio",
    name: "Audio",
    description: "Premium sound systems and speakers",
    image: "/placeholder.svg?height=400&width=400",
    count: 14,
  },
]

// Mock featured products
const featuredProducts = [
  {
    id: "sony-wh-1000xm5",
    slug: "sony-wh-1000xm5",
    title: "Sony WH-1000XM5",
    description:
      "Premium noise-cancelling headphones with exceptional sound quality and industry-leading noise cancellation technology.",
    category: "headphones",
    categoryName: "Headphones",
    brand: "Sony",
    image: "/placeholder.svg?height=300&width=300",
    price: 349.99,
    oldPrice: 399.99,
    rating: 4.8,
    reviewCount: 1245,
    isNew: true,
  },
  {
    id: "apple-watch-series-8",
    slug: "apple-watch-series-8",
    title: "Apple Watch Series 8",
    description: "Advanced health features and always-on display in a sleek design.",
    category: "wearables",
    categoryName: "Wearables",
    brand: "Apple",
    image: "/placeholder.svg?height=300&width=300",
    price: 399.99,
    oldPrice: 429.99,
    rating: 4.7,
    reviewCount: 982,
    isNew: true,
  },
  {
    id: "samsung-galaxy-z-fold-4",
    slug: "samsung-galaxy-z-fold-4",
    title: "Samsung Galaxy Z Fold 4",
    description: "Foldable smartphone with a large internal display for productivity.",
    category: "smartphones",
    categoryName: "Smartphones",
    brand: "Samsung",
    image: "/placeholder.svg?height=300&width=300",
    price: 1799.99,
    oldPrice: 1899.99,
    rating: 4.6,
    reviewCount: 756,
    isNew: false,
  },
  {
    id: "dji-mini-3-pro",
    slug: "dji-mini-3-pro",
    title: "DJI Mini 3 Pro",
    description: "Compact drone with professional-grade camera and obstacle avoidance.",
    category: "drones",
    categoryName: "Drones",
    brand: "DJI",
    image: "/placeholder.svg?height=300&width=300",
    price: 759.99,
    oldPrice: 799.99,
    rating: 4.9,
    reviewCount: 432,
    isNew: false,
  },
]

// Mock new arrivals
const newArrivals = [
  {
    id: "macbook-pro-14",
    slug: "macbook-pro-14",
    title: "MacBook Pro 14-inch",
    description: "Powerful laptop with M2 Pro chip and stunning Liquid Retina XDR display.",
    category: "laptops",
    categoryName: "Laptops",
    brand: "Apple",
    image: "/placeholder.svg?height=300&width=300",
    price: 1999.99,
    oldPrice: 2199.99,
    rating: 4.9,
    reviewCount: 543,
  },
  {
    id: "sony-a7iv",
    slug: "sony-a7iv",
    title: "Sony Alpha A7 IV",
    description: "Full-frame mirrorless camera with advanced autofocus and 4K video capabilities.",
    category: "cameras",
    categoryName: "Cameras",
    brand: "Sony",
    image: "/placeholder.svg?height=300&width=300",
    price: 2499.99,
    oldPrice: 2699.99,
    rating: 4.8,
    reviewCount: 321,
  },
  {
    id: "bose-quietcomfort-earbuds-ii",
    slug: "bose-quietcomfort-earbuds-ii",
    title: "Bose QuietComfort Earbuds II",
    description: "Wireless earbuds with personalized noise cancellation and immersive sound.",
    category: "audio",
    categoryName: "Audio",
    brand: "Bose",
    image: "/placeholder.svg?height=300&width=300",
    price: 299.99,
    oldPrice: 329.99,
    rating: 4.6,
    reviewCount: 654,
  },
  {
    id: "google-pixel-7-pro",
    slug: "google-pixel-7-pro",
    title: "Google Pixel 7 Pro",
    description: "Flagship smartphone with advanced camera system and Google AI features.",
    category: "smartphones",
    categoryName: "Smartphones",
    brand: "Google",
    image: "/placeholder.svg?height=300&width=300",
    price: 899.99,
    oldPrice: 999.99,
    rating: 4.5,
    reviewCount: 789,
  },
]

// Mock best sellers
const bestSellers = [
  {
    id: "airpods-pro-2",
    slug: "airpods-pro-2",
    title: "Apple AirPods Pro 2",
    description: "Next-generation AirPods with active noise cancellation and spatial audio.",
    category: "audio",
    categoryName: "Audio",
    brand: "Apple",
    image: "/placeholder.svg?height=300&width=300",
    price: 249.99,
    oldPrice: 279.99,
    rating: 4.8,
    reviewCount: 1876,
  },
  {
    id: "samsung-galaxy-s23-ultra",
    slug: "samsung-galaxy-s23-ultra",
    title: "Samsung Galaxy S23 Ultra",
    description: "Flagship smartphone with 200MP camera and S Pen functionality.",
    category: "smartphones",
    categoryName: "Smartphones",
    brand: "Samsung",
    image: "/placeholder.svg?height=300&width=300",
    price: 1199.99,
    oldPrice: 1299.99,
    rating: 4.7,
    reviewCount: 1243,
  },
  {
    id: "sony-playstation-5",
    slug: "sony-playstation-5",
    title: "Sony PlayStation 5",
    description: "Next-generation gaming console with ultra-high-speed SSD and 3D audio.",
    category: "gaming",
    categoryName: "Gaming",
    brand: "Sony",
    image: "/placeholder.svg?height=300&width=300",
    price: 499.99,
    oldPrice: null,
    rating: 4.9,
    reviewCount: 2154,
  },
  {
    id: "lg-c2-oled-tv",
    slug: "lg-c2-oled-tv",
    title: "LG C2 OLED TV",
    description: "4K OLED TV with stunning picture quality and gaming features.",
    category: "audio",
    categoryName: "Audio",
    brand: "LG",
    image: "/placeholder.svg?height=300&width=300",
    price: 1499.99,
    oldPrice: 1799.99,
    rating: 4.8,
    reviewCount: 987,
  },
]

export default function GadgetsPage() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 500)
    return () => clearTimeout(timer)
  }, [])

  if (isLoading) {
    return (
      <PublicLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="h-12 bg-gray-200 rounded w-1/3 mb-8"></div>
            <div className="h-64 bg-gray-200 rounded mb-12"></div>
            <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, index) => (
                <div key={index} className="h-80 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </PublicLayout>
    )
  }

  return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <MotionDiv animation="fadeInUp" className="mb-16">
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-primary/80 to-primary">
            <div className="absolute inset-0 bg-[url('/placeholder.svg')] opacity-10 mix-blend-overlay"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-8 md:p-12">
              <div className="flex flex-col justify-center text-white">
                <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">Discover the Latest Tech Gadgets</h1>
                <p className="text-lg mb-8 opacity-90">
                  Explore our curated collection of cutting-edge technology, from smartphones to smart home devices.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button size="lg" asChild className="bg-white text-primary hover:bg-white/90">
                    <Link href="#categories">Browse Categories</Link>
                  </Button>
                  <Button size="lg" variant="outline" asChild className="text-white border-white hover:bg-white/10">
                    <Link href="#featured">Featured Products</Link>
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <MotionImage
                  src="/placeholder.svg?height=400&width=400"
                  alt="Latest Tech Gadgets"
                  width={400}
                  height={400}
                  className="max-w-full h-auto"
                  animation="float"
                />
              </div>
            </div>
          </div>
        </MotionDiv>

        {/* Categories Section */}
        <section id="categories" className="mb-16">
          <MotionDiv animation="fadeInUp" className="mb-8">
            <h2 className="text-3xl font-bold">Browse Categories</h2>
            <p className="text-gray-600">Find the perfect gadget by category</p>
          </MotionDiv>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category, index) => (
              <MotionDiv key={category.id} animation="fadeInUp" delay={index * 0.1}>
                <Link
                  href={`/gadgets/category/${category.id}`}
                  className="group block h-full border rounded-lg overflow-hidden hover:shadow-lg transition-all duration-300"
                >
                  <div className="aspect-square relative overflow-hidden bg-gray-100">
                    <img
                      src={category.image || "/placeholder.svg"}
                      alt={category.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                      <div className="text-white">
                        <h3 className="text-xl font-bold mb-1">{category.name}</h3>
                        <p className="text-sm opacity-90 mb-2">{category.count} products</p>
                        <span className="inline-flex items-center text-sm font-medium">
                          Browse Category{" "}
                          <ArrowRight className="ml-1 w-4 h-4 transition-transform group-hover:translate-x-1" />
                        </span>
                      </div>
                    </div>
                  </div>
                </Link>
              </MotionDiv>
            ))}
          </div>
        </section>

        {/* Products Tabs Section */}
        <section id="featured" className="mb-16">
          <MotionDiv animation="fadeInUp" className="mb-8">
            <h2 className="text-3xl font-bold">Our Products</h2>
            <p className="text-gray-600">Discover the best tech gadgets for your needs</p>
          </MotionDiv>

          <Tabs defaultValue="featured" className="w-full">
            <TabsList className="w-full max-w-md mx-auto mb-8 justify-center">
              <TabsTrigger value="featured" className="text-base">
                Featured
              </TabsTrigger>
              <TabsTrigger value="new-arrivals" className="text-base">
                New Arrivals
              </TabsTrigger>
              <TabsTrigger value="best-sellers" className="text-base">
                Best Sellers
              </TabsTrigger>
            </TabsList>

            {/* Featured Products */}
            <TabsContent value="featured" className="mt-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {featuredProducts.map((product, index) => (
                  <MotionDiv
                    key={product.id}
                    animation="fadeInUp"
                    delay={index * 0.1}
                    className="border rounded-lg overflow-hidden bg-white hover:shadow-lg transition-all duration-300"
                  >
                    <Link href={`/gadgets/${product.slug}`} className="block">
                      <div className="relative">
                        <div className="aspect-square p-4">
                          <img
                            src={product.image || "/placeholder.svg"}
                            alt={product.title}
                            className="w-full h-full object-contain"
                          />
                        </div>
                        {product.isNew && (
                          <Badge className="absolute top-3 left-3 bg-green-600 hover:bg-green-700">New</Badge>
                        )}
                      </div>
                      <div className="p-4">
                        <div className="flex items-center mb-1">
                          <Badge variant="outline" className="text-xs">
                            {product.brand}
                          </Badge>
                          <span className="mx-2 text-xs text-gray-400">•</span>
                          <span className="text-xs text-gray-500">{product.categoryName}</span>
                        </div>
                        <h3 className="font-medium mb-1 line-clamp-2 group-hover:text-primary transition-colors">
                          {product.title}
                        </h3>
                        <div className="flex items-center mb-2">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3 h-3 ${
                                  i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="ml-1 text-xs text-gray-500">({product.reviewCount})</span>
                        </div>
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{product.description}</p>
                        <div className="flex items-baseline">
                          <span className="text-lg font-bold text-primary">${product.price.toFixed(2)}</span>
                          {product.oldPrice && (
                            <span className="ml-2 text-sm text-gray-500 line-through">
                              ${product.oldPrice.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>
                    </Link>
                  </MotionDiv>
                ))}
              </div>
              <div className="text-center mt-8">
                <Button asChild>
                  <Link href="/gadgets/category/all">View All Products</Link>
                </Button>
              </div>
            </TabsContent>

            {/* New Arrivals */}
            <TabsContent value="new-arrivals" className="mt-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {newArrivals.map((product, index) => (
                  <MotionDiv
                    key={product.id}
                    animation="fadeInUp"
                    delay={index * 0.1}
                    className="border rounded-lg overflow-hidden bg-white hover:shadow-lg transition-all duration-300"
                  >
                    <Link href={`/gadgets/${product.slug}`} className="block">
                      <div className="aspect-square p-4">
                        <img
                          src={product.image || "/placeholder.svg"}
                          alt={product.title}
                          className="w-full h-full object-contain"
                        />
                      </div>
                      <div className="p-4">
                        <div className="flex items-center mb-1">
                          <Badge variant="outline" className="text-xs">
                            {product.brand}
                          </Badge>
                          <span className="mx-2 text-xs text-gray-400">•</span>
                          <span className="text-xs text-gray-500">{product.categoryName}</span>
                        </div>
                        <h3 className="font-medium mb-1 line-clamp-2 group-hover:text-primary transition-colors">
                          {product.title}
                        </h3>
                        <div className="flex items-center mb-2">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3 h-3 ${
                                  i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="ml-1 text-xs text-gray-500">({product.reviewCount})</span>
                        </div>
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{product.description}</p>
                        <div className="flex items-baseline">
                          <span className="text-lg font-bold text-primary">${product.price.toFixed(2)}</span>
                          {product.oldPrice && (
                            <span className="ml-2 text-sm text-gray-500 line-through">
                              ${product.oldPrice.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>
                    </Link>
                  </MotionDiv>
                ))}
              </div>
              <div className="text-center mt-8">
                <Button asChild>
                  <Link href="/gadgets/category/all?filter=new">View All New Arrivals</Link>
                </Button>
              </div>
            </TabsContent>

            {/* Best Sellers */}
            <TabsContent value="best-sellers" className="mt-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {bestSellers.map((product, index) => (
                  <MotionDiv
                    key={product.id}
                    animation="fadeInUp"
                    delay={index * 0.1}
                    className="border rounded-lg overflow-hidden bg-white hover:shadow-lg transition-all duration-300"
                  >
                    <Link href={`/gadgets/${product.slug}`} className="block">
                      <div className="aspect-square p-4">
                        <img
                          src={product.image || "/placeholder.svg"}
                          alt={product.title}
                          className="w-full h-full object-contain"
                        />
                      </div>
                      <div className="p-4">
                        <div className="flex items-center mb-1">
                          <Badge variant="outline" className="text-xs">
                            {product.brand}
                          </Badge>
                          <span className="mx-2 text-xs text-gray-400">•</span>
                          <span className="text-xs text-gray-500">{product.categoryName}</span>
                        </div>
                        <h3 className="font-medium mb-1 line-clamp-2 group-hover:text-primary transition-colors">
                          {product.title}
                        </h3>
                        <div className="flex items-center mb-2">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3 h-3 ${
                                  i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="ml-1 text-xs text-gray-500">({product.reviewCount})</span>
                        </div>
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{product.description}</p>
                        <div className="flex items-baseline">
                          <span className="text-lg font-bold text-primary">${product.price.toFixed(2)}</span>
                          {product.oldPrice && (
                            <span className="ml-2 text-sm text-gray-500 line-through">
                              ${product.oldPrice.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>
                    </Link>
                  </MotionDiv>
                ))}
              </div>
              <div className="text-center mt-8">
                <Button asChild>
                  <Link href="/gadgets/category/all?filter=bestsellers">View All Best Sellers</Link>
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </section>

        {/* Call to Action */}
        <MotionDiv animation="fadeInUp" className="mb-16">
          <div className="rounded-2xl bg-gradient-to-r from-primary/80 to-primary p-8 md:p-12 text-white text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Upgrade Your Tech?</h2>
            <p className="text-lg mb-8 max-w-2xl mx-auto">
              Explore our full range of gadgets and find the perfect tech to enhance your lifestyle.
            </p>
            <Button size="lg" asChild className="bg-white text-primary hover:bg-white/90">
              <Link href="/gadgets/category/all">Shop All Products</Link>
            </Button>
          </div>
        </MotionDiv>
      </div>
    </PublicLayout>
  )
}
