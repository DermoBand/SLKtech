"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import PublicLayout from "@/components/public-layout"
import { MotionDiv } from "@/components/animations/motion-div"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Star, SlidersHorizontal, X } from "lucide-react"
import { motion } from "framer-motion"

// Mock categories
const categories = [
  { id: "smartphones", name: "Smartphones", count: 24 },
  { id: "laptops", name: "Laptops", count: 18 },
  { id: "headphones", name: "Headphones", count: 12 },
  { id: "wearables", name: "Wearables", count: 15 },
  { id: "cameras", name: "Cameras", count: 9 },
  { id: "drones", name: "Drones", count: 6 },
  { id: "gaming", name: "Gaming", count: 21 },
  { id: "audio", name: "Audio", count: 14 },
]

// Mock brands
const brands = [
  { id: "apple", name: "Apple", count: 12 },
  { id: "samsung", name: "Samsung", count: 15 },
  { id: "sony", name: "Sony", count: 10 },
  { id: "google", name: "Google", count: 8 },
  { id: "microsoft", name: "Microsoft", count: 6 },
  { id: "lg", name: "LG", count: 9 },
  { id: "dji", name: "DJI", count: 4 },
  { id: "bose", name: "Bose", count: 7 },
]

// Mock gadgets
const allGadgets = [
  {
    id: "sony-wh-1000xm5",
    slug: "sony-wh-1000xm5",
    title: "Sony WH-1000XM5",
    description:
      "Premium noise-cancelling headphones with exceptional sound quality and industry-leading noise cancellation technology.",
    category: "headphones",
    categoryName: "Headphones",
    brand: "sony",
    brandName: "Sony",
    image: "/placeholder.svg?height=300&width=300",
    price: 349.99,
    oldPrice: 399.99,
    rating: 4.8,
    reviewCount: 1245,
    inStock: true,
    isNew: true,
    isFeatured: true,
  },
  {
    id: "apple-watch-series-8",
    slug: "apple-watch-series-8",
    title: "Apple Watch Series 8",
    description: "Advanced health features and always-on display in a sleek design.",
    category: "wearables",
    categoryName: "Wearables",
    brand: "apple",
    brandName: "Apple",
    image: "/placeholder.svg?height=300&width=300",
    price: 399.99,
    oldPrice: 429.99,
    rating: 4.7,
    reviewCount: 982,
    inStock: true,
    isNew: true,
    isFeatured: true,
  },
  {
    id: "samsung-galaxy-z-fold-4",
    slug: "samsung-galaxy-z-fold-4",
    title: "Samsung Galaxy Z Fold 4",
    description: "Foldable smartphone with a large internal display for productivity.",
    category: "smartphones",
    categoryName: "Smartphones",
    brand: "samsung",
    brandName: "Samsung",
    image: "/placeholder.svg?height=300&width=300",
    price: 1799.99,
    oldPrice: 1899.99,
    rating: 4.6,
    reviewCount: 756,
    inStock: true,
    isNew: false,
    isFeatured: true,
  },
  {
    id: "dji-mini-3-pro",
    slug: "dji-mini-3-pro",
    title: "DJI Mini 3 Pro",
    description: "Compact drone with professional-grade camera and obstacle avoidance.",
    category: "drones",
    categoryName: "Drones",
    brand: "dji",
    brandName: "DJI",
    image: "/placeholder.svg?height=300&width=300",
    price: 759.99,
    oldPrice: 799.99,
    rating: 4.9,
    reviewCount: 432,
    inStock: true,
    isNew: false,
    isFeatured: true,
  },
  {
    id: "macbook-pro-14",
    slug: "macbook-pro-14",
    title: "MacBook Pro 14-inch",
    description: "Powerful laptop with M2 Pro chip and stunning Liquid Retina XDR display.",
    category: "laptops",
    categoryName: "Laptops",
    brand: "apple",
    brandName: "Apple",
    image: "/placeholder.svg?height=300&width=300",
    price: 1999.99,
    oldPrice: 2199.99,
    rating: 4.9,
    reviewCount: 543,
    inStock: true,
    isNew: true,
    isFeatured: false,
  },
  {
    id: "sony-a7iv",
    slug: "sony-a7iv",
    title: "Sony Alpha A7 IV",
    description: "Full-frame mirrorless camera with advanced autofocus and 4K video capabilities.",
    category: "cameras",
    categoryName: "Cameras",
    brand: "sony",
    brandName: "Sony",
    image: "/placeholder.svg?height=300&width=300",
    price: 2499.99,
    oldPrice: 2699.99,
    rating: 4.8,
    reviewCount: 321,
    inStock: true,
    isNew: false,
    isFeatured: false,
  },
  {
    id: "xbox-series-x",
    slug: "xbox-series-x",
    title: "Xbox Series X",
    description: "Next-generation gaming console with 4K gaming and lightning-fast load times.",
    category: "gaming",
    categoryName: "Gaming",
    brand: "microsoft",
    brandName: "Microsoft",
    image: "/placeholder.svg?height=300&width=300",
    price: 499.99,
    oldPrice: null,
    rating: 4.7,
    reviewCount: 876,
    inStock: false,
    isNew: false,
    isFeatured: false,
  },
  {
    id: "bose-quietcomfort-earbuds-ii",
    slug: "bose-quietcomfort-earbuds-ii",
    title: "Bose QuietComfort Earbuds II",
    description: "Wireless earbuds with personalized noise cancellation and immersive sound.",
    category: "audio",
    categoryName: "Audio",
    brand: "bose",
    brandName: "Bose",
    image: "/placeholder.svg?height=300&width=300",
    price: 299.99,
    oldPrice: 329.99,
    rating: 4.6,
    reviewCount: 654,
    inStock: true,
    isNew: true,
    isFeatured: false,
  },
  {
    id: "google-pixel-7-pro",
    slug: "google-pixel-7-pro",
    title: "Google Pixel 7 Pro",
    description: "Flagship smartphone with advanced camera system and Google AI features.",
    category: "smartphones",
    categoryName: "Smartphones",
    brand: "google",
    brandName: "Google",
    image: "/placeholder.svg?height=300&width=300",
    price: 899.99,
    oldPrice: 999.99,
    rating: 4.5,
    reviewCount: 789,
    inStock: true,
    isNew: false,
    isFeatured: false,
  },
  {
    id: "lg-c2-oled-tv",
    slug: "lg-c2-oled-tv",
    title: "LG C2 OLED TV",
    description: "4K OLED TV with stunning picture quality and gaming features.",
    category: "audio",
    categoryName: "Audio",
    brand: "lg",
    brandName: "LG",
    image: "/placeholder.svg?height=300&width=300",
    price: 1499.99,
    oldPrice: 1799.99,
    rating: 4.8,
    reviewCount: 432,
    inStock: true,
    isNew: false,
    isFeatured: false,
  },
  {
    id: "samsung-galaxy-tab-s8-ultra",
    slug: "samsung-galaxy-tab-s8-ultra",
    title: "Samsung Galaxy Tab S8 Ultra",
    description: "Premium Android tablet with large display and S Pen support.",
    category: "tablets",
    categoryName: "Tablets",
    brand: "samsung",
    brandName: "Samsung",
    image: "/placeholder.svg?height=300&width=300",
    price: 1099.99,
    oldPrice: 1199.99,
    rating: 4.6,
    reviewCount: 345,
    inStock: true,
    isNew: false,
    isFeatured: false,
  },
  {
    id: "sony-playstation-5",
    slug: "sony-playstation-5",
    title: "Sony PlayStation 5",
    description: "Next-generation gaming console with ultra-high-speed SSD and 3D audio.",
    category: "gaming",
    categoryName: "Gaming",
    brand: "sony",
    brandName: "Sony",
    image: "/placeholder.svg?height=300&width=300",
    price: 499.99,
    oldPrice: null,
    rating: 4.9,
    reviewCount: 1243,
    inStock: false,
    isNew: false,
    isFeatured: false,
  },
]

export default function GadgetCategoryPage() {
  const params = useParams()
  const categorySlug = params.slug as string

  const [isLoading, setIsLoading] = useState(true)
  const [gadgets, setGadgets] = useState<typeof allGadgets>([])
  const [filteredGadgets, setFilteredGadgets] = useState<typeof allGadgets>([])
  const [categoryInfo, setCategoryInfo] = useState<(typeof categories)[0] | null>(null)

  const [showFilters, setShowFilters] = useState(false)
  const [selectedBrands, setSelectedBrands] = useState<string[]>([])
  const [priceRange, setPriceRange] = useState([0, 2500])
  const [sortOption, setSortOption] = useState("featured")
  const [inStockOnly, setInStockOnly] = useState(false)
  const [newArrivalsOnly, setNewArrivalsOnly] = useState(false)

  useEffect(() => {
    // Simulate API fetch
    setIsLoading(true)
    setTimeout(() => {
      const category = categories.find((c) => c.id === categorySlug)
      setCategoryInfo(category || null)

      const categoryGadgets = allGadgets.filter((g) => g.category === categorySlug)
      setGadgets(categoryGadgets)
      setFilteredGadgets(categoryGadgets)
      setIsLoading(false)
    }, 500)
  }, [categorySlug])

  useEffect(() => {
    let result = [...gadgets]

    // Apply brand filter
    if (selectedBrands.length > 0) {
      result = result.filter((gadget) => selectedBrands.includes(gadget.brand))
    }

    // Apply price filter
    result = result.filter((gadget) => gadget.price >= priceRange[0] && gadget.price <= priceRange[1])

    // Apply in-stock filter
    if (inStockOnly) {
      result = result.filter((gadget) => gadget.inStock)
    }

    // Apply new arrivals filter
    if (newArrivalsOnly) {
      result = result.filter((gadget) => gadget.isNew)
    }

    // Apply sorting
    switch (sortOption) {
      case "price-low":
        result.sort((a, b) => a.price - b.price)
        break
      case "price-high":
        result.sort((a, b) => b.price - a.price)
        break
      case "rating":
        result.sort((a, b) => b.rating - a.rating)
        break
      case "newest":
        result.sort((a, b) => (a.isNew === b.isNew ? 0 : a.isNew ? -1 : 1))
        break
      case "featured":
      default:
        result.sort((a, b) => (a.isFeatured === b.isFeatured ? 0 : a.isFeatured ? -1 : 1))
        break
    }

    setFilteredGadgets(result)
  }, [gadgets, selectedBrands, priceRange, sortOption, inStockOnly, newArrivalsOnly])

  const toggleBrand = (brandId: string) => {
    setSelectedBrands((prev) => (prev.includes(brandId) ? prev.filter((id) => id !== brandId) : [...prev, brandId]))
  }

  const resetFilters = () => {
    setSelectedBrands([])
    setPriceRange([0, 2500])
    setSortOption("featured")
    setInStockOnly(false)
    setNewArrivalsOnly(false)
  }

  if (isLoading) {
    return (
      <PublicLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="h-96 bg-gray-200 rounded hidden md:block"></div>
              <div className="md:col-span-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, index) => (
                  <div key={index} className="h-80 bg-gray-200 rounded"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </PublicLayout>
    )
  }

  if (!categoryInfo) {
    return (
      <PublicLayout>
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold mb-4">Category Not Found</h1>
          <p className="mb-8">The category you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link href="/gadgets">Browse All Gadgets</Link>
          </Button>
        </div>
      </PublicLayout>
    )
  }

  return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <MotionDiv animation="fadeInDown" className="mb-6">
          <nav className="flex items-center text-sm text-gray-500">
            <Link href="/" className="hover:text-primary transition-colors">
              Home
            </Link>
            <span className="mx-2">/</span>
            <Link href="/gadgets" className="hover:text-primary transition-colors">
              Gadgets
            </Link>
            <span className="mx-2">/</span>
            <span className="text-gray-900 font-medium">{categoryInfo.name}</span>
          </nav>
        </MotionDiv>

        {/* Page Header */}
        <MotionDiv animation="fadeInUp" className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold">{categoryInfo.name}</h1>
              <p className="text-gray-600 mt-1">
                Showing {filteredGadgets.length} of {categoryInfo.count} products
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex items-center">
                <label htmlFor="sort" className="text-sm mr-2 whitespace-nowrap">
                  Sort by:
                </label>
                <select
                  id="sort"
                  value={sortOption}
                  onChange={(e) => setSortOption(e.target.value)}
                  className="border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="featured">Featured</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="rating">Highest Rated</option>
                  <option value="newest">Newest</option>
                </select>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="md:hidden flex items-center gap-2"
                onClick={() => setShowFilters(true)}
              >
                <SlidersHorizontal className="w-4 h-4" />
                Filters
              </Button>
            </div>
          </div>
        </MotionDiv>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Filters - Desktop */}
          <MotionDiv animation="fadeInLeft" className="hidden md:block space-y-6">
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold">Filters</h2>
                <Button variant="ghost" size="sm" onClick={resetFilters} className="h-8 text-xs">
                  Reset All
                </Button>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h3 className="font-medium mb-3">Price Range</h3>
                <Slider
                  defaultValue={[0, 2500]}
                  max={2500}
                  step={50}
                  value={priceRange}
                  onValueChange={setPriceRange}
                  className="mb-2"
                />
                <div className="flex items-center justify-between text-sm">
                  <span>${priceRange[0]}</span>
                  <span>${priceRange[1]}</span>
                </div>
              </div>

              {/* Brands */}
              <div className="mb-6">
                <h3 className="font-medium mb-3">Brands</h3>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {brands.map((brand) => (
                    <div key={brand.id} className="flex items-center">
                      <Checkbox
                        id={`brand-${brand.id}`}
                        checked={selectedBrands.includes(brand.id)}
                        onCheckedChange={() => toggleBrand(brand.id)}
                      />
                      <label
                        htmlFor={`brand-${brand.id}`}
                        className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        {brand.name} ({brand.count})
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Availability */}
              <div className="mb-6">
                <h3 className="font-medium mb-3">Availability</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Checkbox
                      id="in-stock"
                      checked={inStockOnly}
                      onCheckedChange={(checked) => setInStockOnly(checked as boolean)}
                    />
                    <label
                      htmlFor="in-stock"
                      className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      In Stock Only
                    </label>
                  </div>
                </div>
              </div>

              {/* New Arrivals */}
              <div>
                <h3 className="font-medium mb-3">New Arrivals</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Checkbox
                      id="new-arrivals"
                      checked={newArrivalsOnly}
                      onCheckedChange={(checked) => setNewArrivalsOnly(checked as boolean)}
                    />
                    <label
                      htmlFor="new-arrivals"
                      className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      New Arrivals Only
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Other Categories */}
            <div className="border rounded-lg p-4">
              <h2 className="font-bold mb-4">Other Categories</h2>
              <ul className="space-y-2">
                {categories
                  .filter((c) => c.id !== categorySlug)
                  .map((category) => (
                    <li key={category.id}>
                      <Link
                        href={`/gadgets/category/${category.id}`}
                        className="text-sm hover:text-primary transition-colors"
                      >
                        {category.name} ({category.count})
                      </Link>
                    </li>
                  ))}
              </ul>
            </div>
          </MotionDiv>

          {/* Filters - Mobile */}
          {showFilters && (
            <div className="fixed inset-0 bg-black/50 z-50 md:hidden" onClick={() => setShowFilters(false)}>
              <motion.div
                className="absolute right-0 top-0 h-full w-80 max-w-full bg-white p-4 overflow-y-auto"
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="font-bold text-lg">Filters</h2>
                  <button onClick={() => setShowFilters(false)}>
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Mobile Filters Content */}
                <div className="space-y-6">
                  {/* Price Range */}
                  <div className="mb-6">
                    <h3 className="font-medium mb-3">Price Range</h3>
                    <Slider
                      defaultValue={[0, 2500]}
                      max={2500}
                      step={50}
                      value={priceRange}
                      onValueChange={setPriceRange}
                      className="mb-2"
                    />
                    <div className="flex items-center justify-between text-sm">
                      <span>${priceRange[0]}</span>
                      <span>${priceRange[1]}</span>
                    </div>
                  </div>

                  {/* Brands */}
                  <div className="mb-6">
                    <h3 className="font-medium mb-3">Brands</h3>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {brands.map((brand) => (
                        <div key={brand.id} className="flex items-center">
                          <Checkbox
                            id={`mobile-brand-${brand.id}`}
                            checked={selectedBrands.includes(brand.id)}
                            onCheckedChange={() => toggleBrand(brand.id)}
                          />
                          <label
                            htmlFor={`mobile-brand-${brand.id}`}
                            className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {brand.name} ({brand.count})
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Availability */}
                  <div className="mb-6">
                    <h3 className="font-medium mb-3">Availability</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <Checkbox
                          id="mobile-in-stock"
                          checked={inStockOnly}
                          onCheckedChange={(checked) => setInStockOnly(checked as boolean)}
                        />
                        <label
                          htmlFor="mobile-in-stock"
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          In Stock Only
                        </label>
                      </div>
                    </div>
                  </div>

                  {/* New Arrivals */}
                  <div className="mb-6">
                    <h3 className="font-medium mb-3">New Arrivals</h3>
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <Checkbox
                          id="mobile-new-arrivals"
                          checked={newArrivalsOnly}
                          onCheckedChange={(checked) => setNewArrivalsOnly(checked as boolean)}
                        />
                        <label
                          htmlFor="mobile-new-arrivals"
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          New Arrivals Only
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button className="flex-1" onClick={() => setShowFilters(false)}>
                      Apply Filters
                    </Button>
                    <Button variant="outline" className="flex-1" onClick={resetFilters}>
                      Reset All
                    </Button>
                  </div>
                </div>
              </motion.div>
            </div>
          )}

          {/* Product Grid */}
          <div className="md:col-span-3">
            {filteredGadgets.length === 0 ? (
              <div className="text-center py-12 border rounded-lg">
                <h3 className="text-xl font-bold mb-2">No products found</h3>
                <p className="text-gray-600 mb-6">Try adjusting your filters or browse other categories.</p>
                <Button onClick={resetFilters}>Reset Filters</Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredGadgets.map((gadget, index) => (
                  <MotionDiv
                    key={gadget.id}
                    animation="fadeInUp"
                    delay={index * 0.05}
                    className="border rounded-lg overflow-hidden bg-white hover:shadow-lg transition-all duration-300"
                  >
                    <Link href={`/gadgets/${gadget.slug}`} className="block">
                      <div className="relative">
                        <div className="aspect-square p-4">
                          <img
                            src={gadget.image || "/placeholder.svg"}
                            alt={gadget.title}
                            className="w-full h-full object-contain"
                          />
                        </div>
                        {gadget.isNew && (
                          <Badge className="absolute top-3 left-3 bg-green-600 hover:bg-green-700">New</Badge>
                        )}
                        {!gadget.inStock && (
                          <div className="absolute inset-0 bg-black/5 flex items-center justify-center">
                            <Badge variant="outline" className="bg-white">
                              Out of Stock
                            </Badge>
                          </div>
                        )}
                      </div>
                      <div className="p-4">
                        <div className="flex items-center mb-1">
                          <Badge variant="outline" className="text-xs">
                            {gadget.brandName}
                          </Badge>
                        </div>
                        <h3 className="font-medium mb-1 line-clamp-2 hover:text-primary transition-colors">
                          {gadget.title}
                        </h3>
                        <div className="flex items-center mb-2">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3 h-3 ${
                                  i < Math.floor(gadget.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="ml-1 text-xs text-gray-500">({gadget.reviewCount})</span>
                        </div>
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{gadget.description}</p>
                        <div className="flex items-baseline">
                          <span className="text-lg font-bold text-primary">${gadget.price.toFixed(2)}</span>
                          {gadget.oldPrice && (
                            <span className="ml-2 text-sm text-gray-500 line-through">
                              ${gadget.oldPrice.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>
                    </Link>
                  </MotionDiv>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </PublicLayout>
  )
}
