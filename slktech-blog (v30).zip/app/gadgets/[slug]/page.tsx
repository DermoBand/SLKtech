"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import PublicLayout from "@/components/public-layout"
import { MotionDiv } from "@/components/animations/motion-div"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Star, ShoppingCart, Heart, Share2, ArrowLeft } from "lucide-react"

// Sample product data
const sampleProducts = [
  {
    id: "sony-wh-1000xm5",
    slug: "sony-wh-1000xm5",
    title: "Sony WH-1000XM5",
    description:
      "Premium noise-cancelling headphones with exceptional sound quality and industry-leading noise cancellation technology.",
    longDescription: `
      <p>The Sony WH-1000XM5 headphones redefine noise cancellation and audio quality with their industry-leading technology. These premium headphones feature multiple microphones and a dedicated processor to deliver unprecedented noise cancellation performance.</p>
      <p>With a sleek, lightweight design and ultra-soft leather earpads, the WH-1000XM5 provides exceptional comfort for extended listening sessions. The 30-hour battery life ensures your music keeps playing throughout the day, while quick charging gives you 5 hours of playback from just 10 minutes of charging.</p>
      <p>The headphones support high-resolution audio, including LDAC codec, for an immersive listening experience. Advanced features like Adaptive Sound Control automatically adjust settings based on your location and activities, while Speak-to-Chat pauses music when you start speaking.</p>
    `,
    category: "headphones",
    categoryName: "Headphones",
    brand: "Sony",
    image: "/placeholder.svg?height=500&width=500",
    gallery: [
      "/placeholder.svg?height=500&width=500",
      "/placeholder.svg?height=500&width=500",
      "/placeholder.svg?height=500&width=500",
    ],
    price: 349.99,
    oldPrice: 399.99,
    rating: 4.8,
    reviewCount: 1245,
    inStock: true,
    isNew: true,
    features: [
      "Industry-leading noise cancellation",
      "Up to 30-hour battery life",
      "Crystal clear hands-free calling",
      "Multi-point connection",
      "Adaptive Sound Control",
      "Speak-to-Chat functionality",
      "High-Resolution Audio support",
      "LDAC codec support",
    ],
    specifications: {
      "Driver Unit": "30mm, dome type (CCAW Voice coil)",
      "Frequency Response": "4Hz-40,000Hz",
      "Battery Life": "Up to 30 hours (NC ON), Up to 40 hours (NC OFF)",
      "Charging Time": "Approx. 3.5 hours",
      "Quick Charging": "5 hours playback from 10 minutes charge",
      "Bluetooth Version": "5.2",
      "Supported Audio Formats": "SBC, AAC, LDAC",
      Weight: "250g",
    },
  },
  {
    id: "apple-watch-series-8",
    slug: "apple-watch-series-8",
    title: "Apple Watch Series 8",
    description: "Advanced health features and always-on display in a sleek design.",
    longDescription: `
      <p>The Apple Watch Series 8 represents the most advanced health and fitness companion. With its always-on Retina display, you can easily check your metrics without raising your wrist.</p>
      <p>Series 8 introduces temperature sensing capabilities, providing insights into women's health and general wellbeing. The enhanced workout app gives you more data about your training sessions, while sleep stages tracking helps you understand your sleep patterns.</p>
      <p>Safety features include Crash Detection, which can detect severe car crashes and automatically connect you with emergency services. The watch is also swim-proof and crack-resistant, making it durable for everyday wear.</p>
    `,
    category: "wearables",
    categoryName: "Wearables",
    brand: "Apple",
    image: "/placeholder.svg?height=500&width=500",
    gallery: [
      "/placeholder.svg?height=500&width=500",
      "/placeholder.svg?height=500&width=500",
      "/placeholder.svg?height=500&width=500",
    ],
    price: 399.99,
    oldPrice: 429.99,
    rating: 4.7,
    reviewCount: 982,
    inStock: true,
    isNew: true,
    features: [
      "Temperature sensing",
      "Crash Detection",
      "Enhanced Workout app",
      "Advanced sleep tracking with sleep stages",
      "Always-On Retina display",
      "Water resistant to 50 meters",
      "ECG app and blood oxygen sensor",
      "Family Setup capability",
    ],
    specifications: {
      "Case Size": "41mm or 45mm",
      Display: "Always-On Retina LTPO OLED display",
      Processor: "S8 SiP with 64-bit dual-core processor",
      Storage: "32GB",
      "Battery Life": "Up to 18 hours",
      "Water Resistance": "50 meters",
      Sensors: "Temperature, Blood Oxygen, ECG, Heart Rate, Accelerometer, Gyroscope, Altimeter",
      Connectivity: "LTE and UMTS, Wi-Fi, Bluetooth 5.0",
    },
  },
]

export default function GadgetDetailPage() {
  const params = useParams()
  const slug = params.slug as string

  const [product, setProduct] = useState<(typeof sampleProducts)[0] | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [activeImage, setActiveImage] = useState("")
  const [activeTab, setActiveTab] = useState("description")
  const [quantity, setQuantity] = useState(1)

  useEffect(() => {
    // Simulate API fetch
    setIsLoading(true)
    setTimeout(() => {
      const foundProduct = sampleProducts.find((p) => p.slug === slug) || sampleProducts[0]
      setProduct(foundProduct)
      setActiveImage(foundProduct.image)
      setIsLoading(false)
    }, 500)
  }, [slug])

  const handleQuantityChange = (value: number) => {
    if (value >= 1 && value <= 10) {
      setQuantity(value)
    }
  }

  if (isLoading) {
    return (
      <PublicLayout>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-1/4 mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="h-96 bg-gray-200 rounded"></div>
              <div className="space-y-4">
                <div className="h-8 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                <div className="h-4 bg-gray-200 rounded w-full"></div>
                <div className="h-4 bg-gray-200 rounded w-full"></div>
                <div className="h-8 bg-gray-200 rounded w-1/3"></div>
                <div className="h-10 bg-gray-200 rounded w-full"></div>
              </div>
            </div>
          </div>
        </div>
      </PublicLayout>
    )
  }

  if (!product) {
    return (
      <PublicLayout>
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold mb-4">Product Not Found</h1>
          <p className="mb-8">The product you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link href="/gadgets">Browse All Gadgets</Link>
          </Button>
        </div>
      </PublicLayout>
    )
  }

  return (
    <PublicLayout>
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <MotionDiv animation="fadeInDown" className="mb-6">
          <nav className="flex items-center text-sm text-gray-500">
            <Link href="/" className="hover:text-primary transition-colors">
              Home
            </Link>
            <span className="mx-2">/</span>
            <Link href="/gadgets" className="hover:text-primary transition-colors">
              Gadgets
            </Link>
            <span className="mx-2">/</span>
            <Link href={`/gadgets/category/${product.category}`} className="hover:text-primary transition-colors">
              {product.categoryName}
            </Link>
            <span className="mx-2">/</span>
            <span className="text-gray-900 font-medium">{product.title}</span>
          </nav>
        </MotionDiv>

        {/* Product Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Product Images */}
          <MotionDiv animation="fadeInLeft" className="space-y-4">
            <div className="border rounded-lg overflow-hidden bg-white p-4">
              <img
                src={activeImage || "/placeholder.svg"}
                alt={product.title}
                className="w-full h-auto object-contain aspect-square"
              />
            </div>
            <div className="grid grid-cols-4 gap-2">
              <button
                className={`border rounded-md overflow-hidden p-2 ${
                  activeImage === product.image ? "ring-2 ring-primary" : ""
                }`}
                onClick={() => setActiveImage(product.image)}
              >
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.title}
                  className="w-full h-auto object-contain aspect-square"
                />
              </button>
              {product.gallery?.map((img, index) => (
                <button
                  key={index}
                  className={`border rounded-md overflow-hidden p-2 ${
                    activeImage === img ? "ring-2 ring-primary" : ""
                  }`}
                  onClick={() => setActiveImage(img)}
                >
                  <img
                    src={img || "/placeholder.svg"}
                    alt={`${product.title} - ${index + 1}`}
                    className="w-full h-auto object-contain aspect-square"
                  />
                </button>
              ))}
            </div>
          </MotionDiv>

          {/* Product Info */}
          <MotionDiv animation="fadeInRight" className="space-y-6">
            <div>
              <div className="flex items-center mb-2">
                <Badge variant="outline" className="mr-2">
                  {product.brand}
                </Badge>
                <Badge className="bg-primary/10 text-primary hover:bg-primary/20">{product.categoryName}</Badge>
                {product.isNew && <Badge className="ml-2 bg-green-600 hover:bg-green-700">New</Badge>}
              </div>
              <h1 className="text-3xl font-bold mb-2">{product.title}</h1>
              <div className="flex items-center mb-4">
                <div className="flex mr-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-500">({product.reviewCount} reviews)</span>
              </div>
              <p className="text-gray-700 mb-4">{product.description}</p>
            </div>

            <div className="flex items-baseline mb-6">
              <span className="text-3xl font-bold text-primary">${product.price.toFixed(2)}</span>
              {product.oldPrice && (
                <>
                  <span className="ml-3 text-lg text-gray-500 line-through">${product.oldPrice.toFixed(2)}</span>
                  <span className="ml-3 bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded">
                    Save ${(product.oldPrice - product.price).toFixed(2)}
                  </span>
                </>
              )}
            </div>

            {/* Features */}
            <div>
              <h3 className="font-medium mb-2">Key Features:</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1">
                {product.features?.map((feature, index) => (
                  <li key={index} className="flex items-start text-sm">
                    <span className="text-green-500 mr-2">✓</span>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            {/* Add to Cart */}
            <div className="pt-4 border-t">
              <div className="flex items-center mb-4">
                <span className="mr-4">Quantity:</span>
                <div className="flex items-center border rounded-md">
                  <button
                    className="px-3 py-1 border-r"
                    onClick={() => handleQuantityChange(quantity - 1)}
                    disabled={quantity <= 1}
                  >
                    -
                  </button>
                  <span className="px-4 py-1">{quantity}</span>
                  <button
                    className="px-3 py-1 border-l"
                    onClick={() => handleQuantityChange(quantity + 1)}
                    disabled={quantity >= 10}
                  >
                    +
                  </button>
                </div>
                <span className="ml-4 text-sm text-gray-500">
                  {product.inStock ? (
                    <span className="text-green-600">In Stock</span>
                  ) : (
                    <span className="text-red-600">Out of Stock</span>
                  )}
                </span>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <Button className="flex-1 gap-2" size="lg" disabled={!product.inStock}>
                  <ShoppingCart className="w-5 h-5" />
                  Add to Cart
                </Button>
                <Button variant="outline" size="lg" className="flex-1 gap-2">
                  <Heart className="w-5 h-5" />
                  Add to Wishlist
                </Button>
                <Button variant="ghost" size="icon" className="hidden sm:flex">
                  <Share2 className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </MotionDiv>
        </div>

        {/* Product Details Tabs */}
        <MotionDiv animation="fadeInUp" className="mb-12">
          <Tabs defaultValue="description" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full max-w-md mx-auto mb-8 justify-center">
              <TabsTrigger value="description" className="text-base">
                Description
              </TabsTrigger>
              <TabsTrigger value="specifications" className="text-base">
                Specifications
              </TabsTrigger>
              <TabsTrigger value="reviews" className="text-base">
                Reviews
              </TabsTrigger>
            </TabsList>

            <TabsContent value="description" className="mt-0">
              <div className="bg-white p-6 rounded-lg border">
                <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: product.longDescription }} />
              </div>
            </TabsContent>

            <TabsContent value="specifications" className="mt-0">
              <div className="bg-white p-6 rounded-lg border">
                <h3 className="text-xl font-bold mb-4">Technical Specifications</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(product.specifications || {}).map(([key, value]) => (
                    <div key={key} className="border-b pb-2">
                      <span className="font-medium">{key}:</span> {value}
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="reviews" className="mt-0">
              <div className="bg-white p-6 rounded-lg border">
                <div className="flex flex-col md:flex-row gap-8">
                  <div className="md:w-1/3">
                    <div className="text-center mb-4">
                      <div className="text-5xl font-bold text-primary mb-2">{product.rating}</div>
                      <div className="flex justify-center mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-5 h-5 ${
                              i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <div className="text-sm text-gray-500">Based on {product.reviewCount} reviews</div>
                    </div>
                  </div>
                  <div className="md:w-2/3">
                    <h3 className="text-xl font-bold mb-4">Customer Reviews</h3>
                    <p className="text-gray-500 italic">Reviews will appear here.</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </MotionDiv>

        {/* Related Products */}
        <MotionDiv animation="fadeInUp" className="mb-8">
          <h2 className="text-2xl font-bold mb-6">Related Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {sampleProducts
              .filter((p) => p.slug !== product.slug)
              .map((relatedProduct) => (
                <div
                  key={relatedProduct.id}
                  className="border rounded-lg overflow-hidden bg-white hover:shadow-lg transition-all duration-300"
                >
                  <Link href={`/gadgets/${relatedProduct.slug}`} className="block">
                    <div className="aspect-square p-4">
                      <img
                        src={relatedProduct.image || "/placeholder.svg"}
                        alt={relatedProduct.title}
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center mb-1">
                        <Badge variant="outline" className="text-xs">
                          {relatedProduct.brand}
                        </Badge>
                      </div>
                      <h3 className="font-medium mb-1 line-clamp-2 hover:text-primary transition-colors">
                        {relatedProduct.title}
                      </h3>
                      <div className="flex items-center mb-2">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${
                                i < Math.floor(relatedProduct.rating)
                                  ? "text-yellow-400 fill-yellow-400"
                                  : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="ml-1 text-xs text-gray-500">({relatedProduct.reviewCount})</span>
                      </div>
                      <div className="flex items-baseline">
                        <span className="text-lg font-bold text-primary">${relatedProduct.price.toFixed(2)}</span>
                        {relatedProduct.oldPrice && (
                          <span className="ml-2 text-sm text-gray-500 line-through">
                            ${relatedProduct.oldPrice.toFixed(2)}
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                </div>
              ))}
          </div>
        </MotionDiv>

        {/* Back to Products */}
        <div className="text-center">
          <Button variant="outline" asChild>
            <Link href="/gadgets" className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Back to All Gadgets
            </Link>
          </Button>
        </div>
      </div>
    </PublicLayout>
  )
}
