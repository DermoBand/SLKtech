"use client"

import { useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { MotionDiv } from "@/components/animations/motion-div"
import { RefreshCcw, Home } from "lucide-react"

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error(error)
  }, [error])

  return (
    <div className="container mx-auto px-4 py-16 flex flex-col items-center justify-center min-h-[70vh] text-center">
      <MotionDiv animation="fadeInDown" className="mb-6">
        <h1 className="text-6xl font-bold gradient-text">Oops!</h1>
      </MotionDiv>

      <MotionDiv animation="fadeInUp" delay={0.2} className="max-w-md space-y-4">
        <h2 className="text-2xl font-bold">Something went wrong</h2>
        <p className="text-gray-600">We apologize for the inconvenience. An unexpected error has occurred.</p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-6">
          <Button onClick={reset}>
            <RefreshCcw className="mr-2 h-4 w-4" />
            Try Again
          </Button>

          <Button variant="outline" asChild>
            <Link href="/">
              <Home className="mr-2 h-4 w-4" />
              Back to Home
            </Link>
          </Button>
        </div>
      </MotionDiv>
    </div>
  )
}
