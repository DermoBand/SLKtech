import PublicLayout from "@/components/public-layout"
import { PageHeader } from "@/components/page-header"
import { AboutContent } from "@/components/about-content"

export default function AboutPage() {
  return (
    <PublicLayout>
      <PageHeader title="About SLKtech" description="Learn more about our tech blog and our mission." />
      <AboutContent />
    </PublicLayout>
  )
}
